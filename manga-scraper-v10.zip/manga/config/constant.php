<?php
return [
    'url' => [
        'backend'       => 'https://manga-admin.dev',
        'api_image'     => 'https://cdnimage.dev/',
        'kiryuu'        => 'https://kiryuu.id',
        'komikstation'  => 'https://komikstation.co',
        'komiktap'      => 'https://92.87.6.124'
    ],
];
