<!-- SUB HEADER -->
<div id="sub-header" class="home-sub-header">
    <div class="container">
        <div class="sh-left">
            <div class="float-left">
                <?php $random = App\Models\Manga::with('chapters')->inRandomOrder()->first(); ?>
                <?php if($random): ?>    
                <a href="<?php echo e(route('detail', $random['slug'])); ?>" class="sh-item">
                    <i class="fas fa-glasses mr-2"></i>
                    Read Random
                </a>
                <div class="spacing"></div>
                <?php endif; ?>
                <a href="https://zoro.to" target="_blank" class="sh-item">
                    <i class="fas fa-play-circle mr-2"></i>
                    Anime Online
                </a>
            </div>
            <div class="clearfix"></div>
        </div>
        <div class="sh-right">
            <div class="float-left">
                <div class="sh-item mr-3">
                    <strong>Follow us :</strong>
                </div>
                <a target="_blank" href="#" class="sh-item mr-3">
                    <i class="fab fa-reddit-alien mr-2"></i>
                    Reddit
                </a>
                <a target="_blank" href="#" class="sh-item mr-3">
                    <i class="fab fa-twitter mr-2"></i>
                    Twitter
                </a>
                <a target="_blank" href="#" class="sh-item">
                    <i class="fab fa-discord mr-2"></i>
                    Discord
                </a>
                <div class="clearfix"></div>
            </div>
            <div class="clearfix"></div>
        </div>
        <div class="clearfix"></div>
    </div>
</div>
<!-- SUB HEADER -->

<!-- MAIN HEADER -->
<div id="header" <?php echo e(Route::is('homepage') ? 'class=home-header' : ''); ?> style="<?php echo e(Route::is('homepage') ? '' : 'background: #7b36ce !important'); ?>">
    <div class="container">
        <div id="mobile_menu">
            <i class="fa fa-bars"></i>
        </div>
        <div id="mobile_search">
            <i class="fa fa-search"></i>
        </div>
        <a href="<?php echo e(route('homepage')); ?>" id="logo">
            <img src="/<?php echo e($web['logo']); ?>" alt="logo" />
            <div class="clearfix"></div>
        </a>
        <div id="header_menu">
            <ul class="nav header_menu-list">
                <li class="nav-item">
                    <a href="<?php echo e(route('homepage')); ?>" title="Homepage">
                        Home
                    </a>
                </li>
                <li class="nav-item">
                    <a href="/manga/text-mode" title="Manga List">
                        Manga List
                    </a>
                </li>
                <li class="nav-item">
                    <a href="<?php echo e(route('az-list')); ?>" title="A-Z List">
                        A-Z List
                    </a>
                </li>
            </ul>
            <div class="clearfix"></div>
        </div>

        <?php if(Auth::check()): ?>
        <div id="header_right" class="user-logged">
            <div id="search">
                <div class="search-content">
                    <form action="/search" method="get">
                        <input type="text" name="keyword" class="form-control search-input pl-3" placeholder="Search Manga..." />
                        <button type="submit" class="search-icon">
                            <i class="fas fa-search"></i>
                        </button>
                    </form>
                </div>
            </div>

            <div id="login-state" style="float: left;">
                <div class="hr-notifications">
                    <div class="hrn-icon" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                        <i class="fas fa-bell"></i>
                    </div>
                    <div class="dropdown-menu dropdown-menu-noti new-noti-list" aria-labelledby="noti-list">
                        <div class="nnl-mark">
                            <a class="ma-btn notify-seen-all" data-position="header">
                                <i class="fas fa-check mr-2"></i>
                                Mark all as read
                            </a>
                        </div>
                        <div style="display: block; padding: 25px 15px; text-align: center; font-size: 14px;">
                            <div class="block mb-2">
                                <i class="fas fa-box-open" style="font-size: 20px;"></i>
                            </div>
                            No Notifications
                        </div>
                        
                        <a class="nnl-item nnl-more" href="/user/notifications">
                            <div class="text-center">
                                View all
                            </div>
                        </a>
                    </div>
                </div>
                <div id="user-slot">
                    <div class="header_right-user logged">
                        <div class="dropdown">
                            <div class="btn-avatar" data-toggle="dropdown" aria-expanded="false">
                                <img 
                                    src="https://ui-avatars.com/api/?name=<?php echo e(auth()->user()->name); ?>"
                                    alt="<?php echo e(auth()->user()->name); ?>"
                                >
                            </div>
                            <div id="user_menu" class="dropdown-menu dropdown-menu-model">
                                <a class="dropdown-item" href="<?php echo e(route('profile')); ?>">
                                    <i class="fas fa-user mr-2"></i>
                                    Profile
                                </a>
                                <a class="dropdown-item" href="/user/reading-list">
                                    <i class="fas fa-bookmark mr-2"></i>
                                    Bookmark
                                </a>
                                <a class="dropdown-item" href="/user/notifications">
                                    <i class="fas fa-bell mr-2"></i>
                                    Notifications
                                </a>
                                <a class="dropdown-item di-bottom" href="<?php echo e(route('logout')); ?>" onclick="event.preventDefault(); document.getElementById('logout-form').submit();">
                                    Logout
                                    <i class="fas fa-arrow-right ml-2 mr-1"></i>
                                </a>
                                <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" class="d-none">
                                    <?php echo csrf_field(); ?>
                                </form>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="clearfix"></div>
                <script>
                    $.get('/ajax/notification/latest', function (res) {
                        $('.hr-notifications').html(res.html);
                    })
                </script>
            </div>
            <div class="clearfix"></div>
        </div>
        <?php else: ?>
        <div id="header_right">
            <div id="search">
                <div class="search-content">
                    <form action="/search" method="get">
                        <input type="text" name="keyword" class="form-control search-input pl-3" placeholder="Search Manga..." />
                        <button type="submit" class="search-icon">
                            <i class="fas fa-search"></i>
                        </button>
                    </form>
                </div>
            </div>
            <div id="login-state" style="float: left;">
                <div id="user-slot">
                    <div class="header_right-user">
                        <a href="<?php echo e(route('sign-in')); ?>" class="btn-user btn btn-login">
                            <i class="fas fa-user-circle mr-2"></i>
                            Member
                        </a>
                    </div>
                </div>
            </div>
            <div class="clearfix"></div>
        </div>
        <?php endif; ?>
        <div class="clearfix"></div>
    </div>
</div>
<div class="modal fade premodal premodal-login" id="modal-auth">
    <div class="modal-dialog modal-dialog-centered" role="document">
        <div class="modal-content">
            <div class="tab-content">
                <?php echo $__env->make('pages.user.login', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                <?php echo $__env->make('pages.user.forgot_password', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                <?php echo $__env->make('pages.user.register', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            </div>
        </div>
    </div>
</div>
<!-- MAIN HEADER --><?php /**PATH C:\laragon\www\manga-scraper\resources\views/includes/navbar.blade.php ENDPATH**/ ?>