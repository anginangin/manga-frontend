
<?php $__env->startSection('content'); ?>
<!-- SLIDER -->
<div class="deslide-wrap">
    <div class="container">
        <div id="slider">
            <div class="swiper-wrapper">
                <?php $__currentLoopData = $slider; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $slider): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="swiper-slide">
                    <div class="deslide-item">
                        <a href="#" class="deslide-cover">
                            <img class="manga-poster-img"
                                src="<?php echo e(str_replace('https://','https://i2.wp.com/',substr($slider['poster'],23,-3))); ?>"
                                alt="<?php echo e($slider['title']); ?>" /></a>
                        <div class="deslide-poster">
                            <a href="#" class="manga-poster">
                                <img src="<?php echo e(str_replace('https://','https://i2.wp.com/',substr($slider['poster'],23,-3))); ?>"
                                    class="manga-poster-img" alt="<?php echo e($slider['title']); ?>" />
                            </a>
                        </div>
                        <div class="deslide-item-content">
                            

                            <div class="desi-head-title">
                                <a title="<?php echo e($slider['title']); ?>" href="https://mangareader.to/hunter-x-hunter-51"><?php echo e($slider['title']); ?></a>
                            </div>
                            <div class="sc-detail">
                                <div class="scd-item mb-3">
                                    <?php echo e($slider['description']); ?>

                                </div>
                                
                                <div class="clearfix"></div>
                            </div>
                            <div class="desi-buttons">
                                <a href="https://mangareader.to/read/hunter-x-hunter-51"
                                    class="btn btn-slide-read mr-2">Read Now</a>
                                <a href="https://mangareader.to/hunter-x-hunter-51" class="btn btn-slide-info">View
                                    Info</a>
                            </div>
                        </div>
                        <div class="clearfix"></div>
                    </div>
                </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
            <div class="swiper-pagination"></div>
            <div class="swiper-navigation">
                <div class="swiper-button swiper-button-next">
                    <i class="fas fa-angle-right"></i>
                </div>
                <div class="swiper-button swiper-button-prev">
                    <i class="fas fa-angle-left"></i>
                </div>
            </div>
            <div class="clearfix"></div>
        </div>
    </div>
</div>
<!-- SLIDER -->

<div id="text-home">
    <div class="container">
        <!--Begin: text home-->
        <div class="text-home">
            <div class="text-home-main">
                MangaReader is a Free website to download and read manga online. We have a big library of over
                600,000 manga chapters in all genres that are available to read or download for FREE without
                registration. The manga is updated daily to make sure no one will ever miss the latest chapter on
                their favorite manga. If you like the website, please bookmark it and help us to spread the words.
                Thank you!
            </div>
            <div class="social-home-block">
                <div class="shb-icon"></div>
                <div class="shb-left"><strong>Share Mangareader</strong> to your friends</div>
                <div class="addthis_inline_share_toolbox" data-url="https://mangareader.to/home"
                    data-title="MangaReader - Read Manga website"
                    data-description="Best website to Read Manga online. We have the biggest library of over 200,000 manga available for Free download. Read Manga now!"
                    style="clear: both;">
                    <div id="atstbx"
                        class="at-resp-share-element at-style-responsive addthis-smartlayers addthis-animated at4-show at-mobile"
                        aria-labelledby="at-61a0b134-7f99-45d0-a9a9-2206e3556bbf" role="region"><span
                            id="at-61a0b134-7f99-45d0-a9a9-2206e3556bbf" class="at4-visually-hidden">AddThis Sharing
                            Buttons</span>
                        <div class="at-share-btn-elements"><a role="button" tabindex="0"
                                class="at-icon-wrapper at-share-btn at-svc-facebook"
                                style="background-color: rgb(59, 89, 152); border-radius: 8px;"><span
                                    class="at4-visually-hidden">Share to Facebook</span><span class="at-icon-wrapper"
                                    style="line-height: 32px; height: 32px; width: 32px;"><svg
                                        xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink"
                                        viewBox="0 0 32 32" version="1.1" role="img" aria-labelledby="at-svg-facebook-1"
                                        class="at-icon at-icon-facebook"
                                        style="fill: rgb(255, 255, 255); width: 32px; height: 32px;">
                                        <title id="at-svg-facebook-1">Facebook</title>
                                        <g>
                                            <path
                                                d="M22 5.16c-.406-.054-1.806-.16-3.43-.16-3.4 0-5.733 1.825-5.733 5.17v2.882H9v3.913h3.837V27h4.604V16.965h3.823l.587-3.913h-4.41v-2.5c0-1.123.347-1.903 2.198-1.903H22V5.16z"
                                                fill-rule="evenodd"></path>
                                        </g>
                                    </svg></span><span class="at-label"
                                    style="font-size: 11.4px; line-height: 32px; height: 32px; color: rgb(255, 255, 255);">Facebook</span></a><a
                                role="button" tabindex="0" class="at-icon-wrapper at-share-btn at-svc-twitter"
                                style="background-color: rgb(29, 161, 242); border-radius: 8px;"><span
                                    class="at4-visually-hidden">Share to Twitter</span><span class="at-icon-wrapper"
                                    style="line-height: 32px; height: 32px; width: 32px;"><svg
                                        xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink"
                                        viewBox="0 0 32 32" version="1.1" role="img" aria-labelledby="at-svg-twitter-2"
                                        class="at-icon at-icon-twitter"
                                        style="fill: rgb(255, 255, 255); width: 32px; height: 32px;">
                                        <title id="at-svg-twitter-2">Twitter</title>
                                        <g>
                                            <path
                                                d="M27.996 10.116c-.81.36-1.68.602-2.592.71a4.526 4.526 0 0 0 1.984-2.496 9.037 9.037 0 0 1-2.866 1.095 4.513 4.513 0 0 0-7.69 4.116 12.81 12.81 0 0 1-9.3-4.715 4.49 4.49 0 0 0-.612 2.27 4.51 4.51 0 0 0 2.008 3.755 4.495 4.495 0 0 1-2.044-.564v.057a4.515 4.515 0 0 0 3.62 4.425 4.52 4.52 0 0 1-2.04.077 4.517 4.517 0 0 0 4.217 3.134 9.055 9.055 0 0 1-5.604 1.93A9.18 9.18 0 0 1 6 23.85a12.773 12.773 0 0 0 6.918 2.027c8.3 0 12.84-6.876 12.84-12.84 0-.195-.005-.39-.014-.583a9.172 9.172 0 0 0 2.252-2.336"
                                                fill-rule="evenodd"></path>
                                        </g>
                                    </svg></span><span class="at-label"
                                    style="font-size: 11.4px; line-height: 32px; height: 32px; color: rgb(255, 255, 255);">Twitter</span></a><a
                                role="button" tabindex="0" class="at-icon-wrapper at-share-btn at-svc-reddit"
                                style="background-color: rgb(255, 87, 0); border-radius: 8px;"><span
                                    class="at4-visually-hidden">Share to Reddit</span><span class="at-icon-wrapper"
                                    style="line-height: 32px; height: 32px; width: 32px;"><svg
                                        xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink"
                                        viewBox="0 0 32 32" version="1.1" role="img" aria-labelledby="at-svg-reddit-3"
                                        class="at-icon at-icon-reddit"
                                        style="fill: rgb(255, 255, 255); width: 32px; height: 32px;">
                                        <title id="at-svg-reddit-3">Reddit</title>
                                        <g>
                                            <path
                                                d="M27 15.5a2.452 2.452 0 0 1-1.338 2.21c.098.38.147.777.147 1.19 0 1.283-.437 2.47-1.308 3.563-.872 1.092-2.06 1.955-3.567 2.588-1.506.634-3.143.95-4.91.95-1.768 0-3.403-.316-4.905-.95-1.502-.632-2.69-1.495-3.56-2.587-.872-1.092-1.308-2.28-1.308-3.562 0-.388.045-.777.135-1.166a2.47 2.47 0 0 1-1.006-.912c-.253-.4-.38-.842-.38-1.322 0-.678.237-1.26.712-1.744a2.334 2.334 0 0 1 1.73-.726c.697 0 1.29.26 1.78.782 1.785-1.258 3.893-1.928 6.324-2.01l1.424-6.467a.42.42 0 0 1 .184-.26.4.4 0 0 1 .32-.063l4.53 1.006c.147-.306.368-.553.662-.74a1.78 1.78 0 0 1 .97-.278c.508 0 .94.18 1.302.54.36.36.54.796.54 1.31 0 .512-.18.95-.54 1.315-.36.364-.794.546-1.302.546-.507 0-.94-.18-1.295-.54a1.793 1.793 0 0 1-.533-1.308l-4.1-.92-1.277 5.86c2.455.074 4.58.736 6.37 1.985a2.315 2.315 0 0 1 1.757-.757c.68 0 1.256.242 1.73.726.476.484.713 1.066.713 1.744zm-16.868 2.47c0 .513.178.95.534 1.315.356.365.787.547 1.295.547.508 0 .942-.182 1.302-.547.36-.364.54-.802.54-1.315 0-.513-.18-.95-.54-1.31-.36-.36-.794-.54-1.3-.54-.5 0-.93.183-1.29.547a1.79 1.79 0 0 0-.54 1.303zm9.944 4.406c.09-.09.135-.2.135-.323a.444.444 0 0 0-.44-.447c-.124 0-.23.042-.32.124-.336.348-.83.605-1.486.77a7.99 7.99 0 0 1-1.964.248 7.99 7.99 0 0 1-1.964-.248c-.655-.165-1.15-.422-1.486-.77a.456.456 0 0 0-.32-.124.414.414 0 0 0-.306.124.41.41 0 0 0-.135.317.45.45 0 0 0 .134.33c.352.355.837.636 1.455.843.617.207 1.118.33 1.503.366a11.6 11.6 0 0 0 1.117.056c.36 0 .733-.02 1.117-.056.385-.037.886-.16 1.504-.366.62-.207 1.104-.488 1.456-.844zm-.037-2.544c.507 0 .938-.182 1.294-.547.356-.364.534-.802.534-1.315 0-.505-.18-.94-.54-1.303a1.75 1.75 0 0 0-1.29-.546c-.506 0-.94.18-1.3.54-.36.36-.54.797-.54 1.31s.18.95.54 1.315c.36.365.794.547 1.3.547z"
                                                fill-rule="evenodd"></path>
                                        </g>
                                    </svg></span><span class="at-label"
                                    style="font-size: 11.4px; line-height: 32px; height: 32px; color: rgb(255, 255, 255);">Reddit</span></a><a
                                role="button" tabindex="0" class="at-icon-wrapper at-share-btn at-svc-telegram"
                                style="background-color: rgb(0, 136, 204); border-radius: 8px;"><span
                                    class="at4-visually-hidden">Share to Telegram</span><span class="at-icon-wrapper"
                                    style="line-height: 32px; height: 32px; width: 32px;"><svg
                                        xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink"
                                        viewBox="0 0 32 32" version="1.1" role="img" aria-labelledby="at-svg-telegram-4"
                                        class="at-icon at-icon-telegram"
                                        style="fill: rgb(255, 255, 255); width: 32px; height: 32px;">
                                        <title id="at-svg-telegram-4">Telegram</title>
                                        <g>
                                            <g fill-rule="evenodd"></g>
                                            <path
                                                d="M15.02 20.814l9.31-12.48L9.554 17.24l1.92 6.42c.225.63.114.88.767.88l.344-5.22 2.436 1.494z"
                                                opacity=".6"></path>
                                            <path
                                                d="M12.24 24.54c.504 0 .727-.234 1.008-.51l2.687-2.655-3.35-2.054-.344 5.22z"
                                                opacity=".3"></path>
                                            <path
                                                d="M12.583 19.322l8.12 6.095c.926.52 1.595.25 1.826-.874l3.304-15.825c.338-1.378-.517-2.003-1.403-1.594L5.024 14.727c-1.325.54-1.317 1.29-.24 1.625l4.98 1.58 11.53-7.39c.543-.336 1.043-.156.633.214">
                                            </path>
                                        </g>
                                    </svg></span><span class="at-label"
                                    style="font-size: 11.4px; line-height: 32px; height: 32px; color: rgb(255, 255, 255);">Telegram</span></a><a
                                role="button" tabindex="0" class="at-icon-wrapper at-share-btn at-svc-compact"
                                style="background-color: rgb(255, 101, 80); border-radius: 8px;"><span
                                    class="at4-visually-hidden">Share to More</span><span class="at-icon-wrapper"
                                    style="line-height: 32px; height: 32px; width: 32px;"><svg
                                        xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink"
                                        viewBox="0 0 32 32" version="1.1" role="img" aria-labelledby="at-svg-addthis-5"
                                        class="at-icon at-icon-addthis"
                                        style="fill: rgb(255, 255, 255); width: 32px; height: 32px;">
                                        <title id="at-svg-addthis-5">AddThis</title>
                                        <g>
                                            <path d="M18 14V8h-4v6H8v4h6v6h4v-6h6v-4h-6z" fill-rule="evenodd"></path>
                                        </g>
                                    </svg></span><span class="at-label"
                                    style="font-size: 11.4px; line-height: 32px; height: 32px; color: rgb(255, 255, 255);">More</span><span
                                    class="at4-share-count-container"
                                    style="font-size: 11.4px; line-height: 32px; color: rgb(255, 255, 255);">3.5K</span></a>
                        </div>
                    </div>
                </div>
                <div class="clearfix"></div>
            </div>
        </div>
        <!--/End: text home-->
    </div>
</div>

<!-- TRENDING -->
<div id="manga-trending">
    <div class="container">
        <section class="block_area block_area_trending mb-0">
            <div class="block_area-header">
                <div class="bah-heading">
                    <h2 class="cat-heading">Trending</h2>
                </div>
                <div class="clearfix"></div>
            </div>
            <div class="block_area-content">
                <div class="trending-list" id="trending-home" style="display: none">
                    <div class="swiper-container">
                        <div class="swiper-wrapper">
                            <?php $count = 0; ?>
                            <?php $__currentLoopData = $popular; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $trending): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php if($count == 10) break; ?>
                            <div class="swiper-slide">
                                <div class="item">
                                    <div class="manga-poster">
                                        <a class="link-mask" href="https://mangareader.to/one-piece-3"></a>
                                        <div class="mp-desc">
                                            <p class="alias-name mb-2">
                                                <strong><?php echo e($trending['judul']); ?></strong>
                                            </p>
                                            <p><i class="fas fa-star mr-2"></i><?php echo e($trending['rating']); ?></p>
                                            <p>
                                                <a href="https://mangareader.to/read/one-piece-3/en/chapter-1065"><i
                                                        class="far fa-file-alt mr-2"></i><strong><?php echo e($trending['chapter']); ?></strong></a>
                                            </p>

                                            <div class="mpd-buttons">
                                                <a href="https://mangareader.to/read/one-piece-3"
                                                    class="btn btn-primary btn-sm btn-block"><i
                                                        class="fas fa-glasses mr-2"></i>Read Now</a>
                                                <a href="https://mangareader.to/one-piece-3"
                                                    class="btn btn-light btn-sm btn-block"><i
                                                        class="fas fa-info-circle mr-2"></i>Info</a>
                                            </div>
                                        </div>
                                        <img src="<?php echo e(str_replace('https://','https://i2.wp.com/',$trending['image'])); ?>"
                                            class="manga-poster-img lazyload" alt="<?php echo e($trending['judul']); ?>" />
                                    </div>

                                    <div class="number">
                                        <span><?php echo e($count+1); ?></span>
                                        <div class="anime-name"><?php echo e($trending['judul']); ?></div>
                                    </div>

                                    <div class="clearfix"></div>
                                </div>
                            </div>
                            <?php $count++; ?>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
                        <div class="clearfix"></div>
                    </div>
                    <div class="trending-navi">
                        <div class="navi-next">
                            <i class="fas fa-angle-right"></i>
                        </div>
                        <div class="navi-prev"><i class="fas fa-angle-left"></i></div>
                    </div>
                </div>
            </div>
        </section>
    </div>
</div>
<!-- TRENDING -->

<!-- CATEGORY -->
<div class="category_block category_block-home">
    <div class="container">
        <div class="c_b-wrap">
            <div class="c_b-list">
                <div class="cbl-row">
                    <div class="item item-focus focus-01">
                        <a href="https://mangareader.to/latest-updated" title=""><i class="mr-1">⚡</i> Latest
                            Updated</a>
                    </div>
                    <div class="item item-focus focus-02">
                        <a href="https://mangareader.to/new-release" title=""><i class="mr-1">✌</i> New
                            Release</a>
                    </div>
                    <div class="item item-focus focus-04">
                        <a href="https://mangareader.to/most-viewed" title=""><i class="mr-1">🔥</i> Most
                            Viewed</a>
                    </div>
                    <div class="item item-focus focus-05">
                        <a href="https://mangareader.to/completed" title=""><i class="mr-1">✅</i> Completed</a>
                    </div>
                </div>
                <div class="cbl-row">
                    <?php $__currentLoopData = $genre; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $genre): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="item">
                        <a href="#" title="<?php echo e($genre['genre']); ?>"><?php echo e($genre['genre']); ?></a>
                    </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                    <div class="item item-more">
                        <a class="im-toggle">+ More</a>
                    </div>
                </div>
                <div class="clearfix"></div>
            </div>
        </div>
    </div>
</div>
<!-- CATEGORY -->

<div id="manga-continue"></div>

<!-- RECOMMENDED -->

<!-- RECOMMENDED -->

<div id="main-wrapper">
    <div class="container">
        <div id="mw-2col">
            <!-- LATEST UPDATES -->
            <div id="main-content">
                <section class="block_area block_area_home">
                    <div class="block_area-header block_area-header-tabs">
                        <div class="float-left bah-heading">
                            <h2 class="cat-heading">Latest Updates</h2>
                        </div>
                        <div class="bah-tab">
                            <ul class="nav nav-tabs pre-tabs pre-tabs-min">
                                <li class="nav-item">
                                    <a data-toggle="tab" href="#latest-chap" class="nav-link active">Chapter</a>
                                </li>
                                <li class="nav-item">
                                    <a data-toggle="tab" href="#latest-vol" class="nav-link">Volume</a>
                                </li>
                            </ul>
                        </div>
                        <div class="clearfix"></div>
                    </div>
                    <div class="tab-content">
                        <div id="latest-chap" class="tab-pane active show">
                            <div class="manga_list-sbs">
                                <div class="mls-wrap">
                                    <div class="item item-spc">
                                        <a class="manga-poster"
                                            href="https://mangareader.to/my-apprentices-are-all-female-devils-61172">
                                            <span class="tick tick-item tick-lang">EN</span>

                                            <img src="https://img.mreadercdn.com/_r/300x400/100/f9/f4/f9f4dea3af0d0b2e5733760541eda0f6/f9f4dea3af0d0b2e5733760541eda0f6.jpg"
                                                class="manga-poster-img lazyload"
                                                alt="My Apprentices are all Female Devils" />
                                        </a>
                                        <div class="manga-detail">
                                            <h3 class="manga-name">
                                                <a href="https://mangareader.to/my-apprentices-are-all-female-devils-61172"
                                                    title="My Apprentices are all Female Devils">My Apprentices
                                                    are all Female Devils</a>
                                            </h3>
                                            <div class="fd-infor">
                                                <span class="fdi-item fdi-cate">
                                                    <a href="https://mangareader.to/genre/action">Action</a>,

                                                    <a href="https://mangareader.to/genre/adventure">Adventure</a>,

                                                    <a href="https://mangareader.to/genre/comedy">Comedy</a>
                                                </span>

                                                <div class="clearfix"></div>
                                            </div>

                                            <div class="fd-list">
                                                <div class="fdl-item">
                                                    <div class="chapter">
                                                        <a
                                                            href="https://mangareader.to/read/my-apprentices-are-all-female-devils-61172/en/chapter-165">
                                                            <i class="far fa-file-alt mr-2"></i>Chap 165
                                                            [EN]
                                                        </a>
                                                    </div>
                                                    <div class="release-time"></div>
                                                    <div class="clearfix"></div>
                                                </div>

                                                <div class="fdl-item">
                                                    <div class="chapter">
                                                        <a
                                                            href="https://mangareader.to/read/my-apprentices-are-all-female-devils-61172/en/chapter-164">
                                                            <i class="far fa-file-alt mr-2"></i>Chap 164
                                                            [EN]
                                                        </a>
                                                    </div>
                                                    <div class="release-time"></div>
                                                    <div class="clearfix"></div>
                                                </div>

                                                <div class="fdl-item">
                                                    <div class="chapter">
                                                        <a
                                                            href="https://mangareader.to/read/my-apprentices-are-all-female-devils-61172/en/chapter-163">
                                                            <i class="far fa-file-alt mr-2"></i>Chap 163
                                                            [EN]
                                                        </a>
                                                    </div>
                                                    <div class="release-time"></div>
                                                    <div class="clearfix"></div>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="clearfix"></div>
                                    </div>
                                    <div class="clearfix"></div>
                                </div>
                            </div>
                        </div>
                        <div id="latest-vol" class="tab-pane">
                            <div class="manga_list-sbs">
                                <div class="mls-wrap">
                                    <div class="item item-spc">
                                        <a class="manga-poster" href="https://mangareader.to/spy-x-family-86">
                                            <span class="tick tick-item tick-lang">EN/FR/JA</span>

                                            <img src="https://img.mreadercdn.com/_r/300x400/100/0c/64/0c64e3287e85df82f6add8b09ff38714/0c64e3287e85df82f6add8b09ff38714.jpg"
                                                class="manga-poster-img lazyload" alt="Spy x Family" />
                                        </a>
                                        <div class="manga-detail">
                                            <h3 class="manga-name">
                                                <a href="https://mangareader.to/spy-x-family-86"
                                                    title="Spy x Family">Spy x Family</a>
                                            </h3>
                                            <div class="fd-infor">
                                                <span class="fdi-item fdi-cate">
                                                    <a href="https://mangareader.to/genre/action">Action</a>,

                                                    <a href="https://mangareader.to/genre/comedy">Comedy</a>,

                                                    <a href="https://mangareader.to/genre/shounen">Shounen</a>
                                                </span>

                                                <div class="clearfix"></div>
                                            </div>

                                            <div class="fd-list">
                                                <div class="fdl-item">
                                                    <div class="chapter">
                                                        <a
                                                            href="https://mangareader.to/read/spy-x-family-86/en/volume-10">
                                                            <i class="far fa-file-alt mr-2"></i>

                                                            Vol 10 [EN]
                                                        </a>
                                                    </div>
                                                    <div class="release-time"></div>
                                                    <div class="clearfix"></div>
                                                </div>

                                                <div class="fdl-item">
                                                    <div class="chapter">
                                                        <a
                                                            href="https://mangareader.to/read/spy-x-family-86/en/volume-9">
                                                            <i class="far fa-file-alt mr-2"></i>

                                                            Vol 9 [EN]
                                                        </a>
                                                    </div>
                                                    <div class="release-time"></div>
                                                    <div class="clearfix"></div>
                                                </div>

                                                <div class="fdl-item">
                                                    <div class="chapter">
                                                        <a
                                                            href="https://mangareader.to/read/spy-x-family-86/en/volume-8">
                                                            <i class="far fa-file-alt mr-2"></i>

                                                            Vol 8 [EN]
                                                        </a>
                                                    </div>
                                                    <div class="release-time"></div>
                                                    <div class="clearfix"></div>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="clearfix"></div>
                                    </div>
                                    <div class="clearfix"></div>
                                </div>
                            </div>
                        </div>
                    </div>
                </section>
                <div class="clearfix"></div>
            </div>
            <!-- LATEST UPDATES -->

            <!-- MOST VIEWED -->
            <div id="main-sidebar">
                <section class="block_area block_area_sidebar block_area-realtime">
                    <div class="block_area-header">
                        <div class="float-left bah-heading">
                            <h2 class="cat-heading">Serial Populer</h2>
                        </div>
                        <div class="clearfix"></div>
                    </div>
                    <div class="block_area-content">
                        <div class="cbox cbox-list cbox-realtime">
                            <div class="cbox-content">
                                <ul class="nav nav-pills nav-fill nav-tabs anw-tabs">
                                    <li class="nav-item">
                                        <a data-toggle="tab" href="#chart-today" class="nav-link active">Mingguan</a>
                                    </li>
                                    <li class="nav-item">
                                        <a data-toggle="tab" href="#chart-week" class="nav-link">Bulanan</a>
                                    </li>
                                    <li class="nav-item">
                                        <a data-toggle="tab" href="#chart-month" class="nav-link">Semua</a>
                                    </li>
                                </ul>
                                <div class="tab-content">
                                    <div id="chart-today" class="tab-pane show active">
                                        <div class="featured-block-ul featured-block-chart">
                                            <ul class="ulclear">
                                                <?php $count = 0 ?>
                                                <?php $__currentLoopData = $popular_weekly; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pw): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <li class="item-top">
                                                    <div class="ranking-number">
                                                        <span><?php echo e($count+1); ?></span>
                                                    </div>
                                                    <a href="#" class="manga-poster">
                                                        <img src="<?php echo e(str_replace('https://', 'https://i2.wp.com/', $pw['poster'])); ?>"
                                                            class="manga-poster-img lazyload"
                                                            alt="<?php echo e($pw['title']); ?>" />
                                                    </a>
                                                    <div class="manga-detail">
                                                        <h3 class="manga-name">
                                                            <a href="#" title="<?php echo e($pw['title']); ?>"><?php echo e($pw['title']); ?></a>
                                                        </h3>
                                                        <div class="fd-infor">
                                                            <span class="fdi-item fdi-cate">
                                                                <?php echo e(str_replace('Genres: ','',$pw['genre'])); ?>

                                                            </span>
                                                            <div class="d-block">
                                                                <i class="fas fa-star mr-2"></i>Rating : <?php echo e($pw['rating']); ?>

                                                            </div>
                                                            <div class="clearfix"></div>
                                                        </div>
                                                    </div>
                                                    <div class="clearfix"></div>
                                                </li>
                                                <?php
                                                $count++
                                                ?>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </ul>
                                            <div class="clearfix"></div>
                                        </div>
                                    </div>
                                    <div id="chart-week" class="tab-pane">
                                        <div class="featured-block-ul featured-block-chart">
                                            <ul class="ulclear">
                                                <?php $count = 0 ?>
                                                <?php $__currentLoopData = $popular_monthly; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pm): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <li class="item-top">
                                                    <div class="ranking-number">
                                                        <span><?php echo e($count+1); ?></span>
                                                    </div>
                                                    <a href="#" class="manga-poster">
                                                        <img src="<?php echo e(str_replace('https://', 'https://i2.wp.com/', $pm['poster'])); ?>"
                                                            class="manga-poster-img lazyload"
                                                            alt="<?php echo e($pm['title']); ?>" />
                                                    </a>
                                                    <div class="manga-detail">
                                                        <h3 class="manga-name">
                                                            <a href="#" title="<?php echo e($pm['title']); ?>"><?php echo e($pm['title']); ?></a>
                                                        </h3>
                                                        <div class="fd-infor">
                                                            <span class="fdi-item fdi-cate">
                                                                <?php echo e(str_replace('Genres: ','',$pm['genre'])); ?>

                                                            </span>
                                                            <div class="d-block">
                                                                <i class="fas fa-star mr-2"></i>Rating : <?php echo e($pm['rating']); ?>

                                                            </div>
                                                            <div class="clearfix"></div>
                                                        </div>
                                                    </div>
                                                    <div class="clearfix"></div>
                                                </li>
                                                <?php
                                                $count++
                                                ?>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </ul>
                                            <div class="clearfix"></div>
                                        </div>
                                    </div>
                                    <div id="chart-month" class="tab-pane">
                                        <div class="featured-block-ul featured-block-chart">
                                            <ul class="ulclear">
                                                <?php $count = 0 ?>
                                                <?php $__currentLoopData = $popular_alltime; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pa): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <li class="item-top">
                                                    <div class="ranking-number">
                                                        <span><?php echo e($count+1); ?></span>
                                                    </div>
                                                    <a href="#" class="manga-poster">
                                                        <img src="<?php echo e(str_replace('https://', 'https://i2.wp.com/', $pa['poster'])); ?>"
                                                            class="manga-poster-img lazyload"
                                                            alt="<?php echo e($pa['title']); ?>" />
                                                    </a>
                                                    <div class="manga-detail">
                                                        <h3 class="manga-name">
                                                            <a href="#" title="<?php echo e($pa['title']); ?>"><?php echo e($pa['title']); ?></a>
                                                        </h3>
                                                        <div class="fd-infor">
                                                            <span class="fdi-item fdi-cate">
                                                                <?php echo e(str_replace('Genres: ','',$pa['genre'])); ?>

                                                            </span>
                                                            <div class="d-block">
                                                                <i class="fas fa-star mr-2"></i>Rating : <?php echo e($pa['rating']); ?>

                                                            </div>
                                                            <div class="clearfix"></div>
                                                        </div>
                                                    </div>
                                                    <div class="clearfix"></div>
                                                </li>
                                                <?php
                                                $count++
                                                ?>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </ul>
                                            <div class="clearfix"></div>
                                        </div>
                                    </div>
                                </div>
                                <div class="clearfix"></div>
                            </div>
                        </div>
                    </div>
                </section>
                <div class="clearfix"></div>
                <section class="block_area block_area_sidebar block_area-realtime">
                    <div class="block_area-header">
                        <div class="float-left bah-heading">
                            <h2 class="cat-heading">Serial Baru</h2>
                        </div>
                        <div class="clearfix"></div>
                    </div>
                    <div class="block_area-content">
                        <div class="cbox cbox-list cbox-realtime">
                            <div class="cbox-content">
                                <div id="chart-today" class="tab-pane show active">
                                    <div class="featured-block-ul featured-block-chart">
                                        <ul class="ulclear">
                                            <?php $__currentLoopData = array_slice($serial_baru, 15,20); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sb): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <li class="item-top">
                                                <a href="#" class="manga-poster">
                                                    <img src="<?php echo e(str_replace('https://', 'https://i2.wp.com/', $sb['poster'])); ?>"
                                                        class="manga-poster-img lazyload" alt="<?php echo e($sb['title']); ?>" />
                                                </a>
                                                <div class="manga-detail">
                                                    <h3 class="manga-name">
                                                        <a href="#" title="<?php echo e($sb['title']); ?>"><?php echo e($sb['title']); ?></a>
                                                    </h3>
                                                    <div class="fd-infor">
                                                        <span class="fdi-item fdi-cate">
                                                            <strong>Genres:</strong> <?php echo e($sb['genre']); ?>

                                                        </span>
                                                        <div class="d-block">
                                                            <?php echo e($sb['released']); ?>

                                                        </div>
                                                        <div class="clearfix"></div>
                                                    </div>
                                                </div>
                                                <div class="clearfix"></div>
                                            </li>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </ul>
                                        <div class="clearfix"></div>
                                    </div>
                                </div>
                                <div class="clearfix"></div>
                            </div>
                        </div>
                    </div>
                </section>
            </div>
            <!-- MOST VIEWED -->

            <div class="clearfix"></div>

            <!-- COMPLETED -->
            <section class="block_area block_area_featured">
                <div class="block_area-header">
                    <div class="bah-heading">
                        <h2 class="cat-heading">Completed</h2>
                    </div>
                    <div class="clearfix"></div>
                </div>
                <div class="block_area-content">
                    <div class="featured-list" id="featured-04" style="display: none">
                        <div class="swiper-container">
                            <div class="swiper-wrapper">
                                <div class="swiper-slide">
                                    <div class="mg-item-basic">
                                        <div class="manga-poster">
                                            <a class="link-mask" href="https://mangareader.to/shark-girl-8009"></a>

                                            <span class="tick tick-item tick-lang">EN/JA</span>

                                            <div class="mp-desc">
                                                <p class="alias-name mb-2">
                                                    <strong>Shark Girl</strong>
                                                </p>
                                                <p><i class="fas fa-star mr-2"></i>6.9</p>
                                                <p><i class="fas fa-globe mr-2"></i>EN/JA</p>

                                                <p>
                                                    <a href="https://mangareader.to/read/shark-girl-8009/en/chapter-31"><i
                                                            class="far fa-file-alt mr-2"></i><strong>Chap 31
                                                            [EN]</strong></a>
                                                </p>

                                                <p>
                                                    <a href="https://mangareader.to/read/shark-girl-8009/en/volume-3"><i
                                                            class="far fa-file-alt mr-2"></i><strong>Vol 3
                                                            [EN]</strong></a>
                                                </p>

                                                <div class="mpd-buttons">
                                                    <a href="https://mangareader.to/read/shark-girl-8009"
                                                        class="btn btn-primary btn-sm btn-block"><i
                                                            class="fas fa-glasses mr-2"></i>Read
                                                        Now</a>
                                                    <a href="https://mangareader.to/shark-girl-8009"
                                                        class="btn btn-light btn-sm btn-block"><i
                                                            class="fas fa-info-circle mr-2"></i>Info</a>
                                                </div>
                                            </div>
                                            <img src="https://img.mreadercdn.com/_r/300x400/100/c5/10/c5101a86ab27356cf362306b17763339/c5101a86ab27356cf362306b17763339.jpg"
                                                class="manga-poster-img lazyload" alt="Shark Girl" />
                                        </div>

                                        <div class="manga-detail">
                                            <h3 class="manga-name">
                                                <a href="https://mangareader.to/shark-girl-8009"
                                                    title="Shark Girl">Shark Girl</a>
                                            </h3>
                                            <div class="fd-infor">
                                                <a href="https://mangareader.to/genre/action">Action</a>,

                                                <a href="https://mangareader.to/genre/comedy">Comedy</a>

                                                <div class="clearfix"></div>
                                            </div>
                                        </div>

                                        <div class="clearfix"></div>
                                    </div>
                                </div>
                            </div>
                            <div class="clearfix"></div>
                        </div>
                        <div class="featured-navi">
                            <div class="navi-next">
                                <i class="fas fa-angle-right"></i>
                            </div>
                            <div class="navi-prev">
                                <i class="fas fa-angle-left"></i>
                            </div>
                        </div>
                    </div>
                </div>
            </section>
            <!-- COMPLETED -->

            <div class="clearfix"></div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\laravel-scraper\resources\views/homepage.blade.php ENDPATH**/ ?>