
<?php $__env->startSection('content'); ?>
<div class="prebreadcrumb">
    <div class="container">
        <nav aria-label="breadcrumb">
            <ol class="breadcrumb">
                <li class="breadcrumb-item">
                    <a href="/">Home</a>
                </li>
                <li class="breadcrumb-item active">
                    A-Z List
                </li>
            </ol>
        </nav>
    </div>
</div>
<div id="main-wrapper" class="page-layout page-category">
    <div class="container">
        <div id="mw-2col">
            <div id="main-content">
                <section class="block_area block_area_category">
                    <div class="block_area-header">
                        <div class="bah-heading float-left">
                            <h2 class="cat-heading">
                                A-Z List
                            </h2>
                        </div>
                        <div class="clearfix"></div>
                    </div>
                    <div class="category_block">
                        <div class="c_b-wrap">
                            <div class="c_b-list active alphabet-list">
                                <div class="cbl-row">
                                    <div class="item"><a href="/az-list">All</a></div>
                                    <div class="item"><a href="/az-list/other">#</a></div>
                                    <div class="item"><a href="/az-list/0-9">0-9</a></div>
                                    <div class="item"><a href="/az-list/A">A</a></div>
                                    <div class="item"><a href="/az-list/B">B</a></div>
                                    <div class="item"><a href="/az-list/C">C</a></div>
                                    <div class="item"><a href="/az-list/D">D</a></div>
                                    <div class="item"><a href="/az-list/E">E</a></div>
                                    <div class="item"><a href="/az-list/F">F</a></div>
                                    <div class="item"><a href="/az-list/G">G</a></div>
                                    <div class="item"><a href="/az-list/H">H</a></div>
                                    <div class="item"><a href="/az-list/I">I</a></div>
                                    <div class="item"><a href="/az-list/J">J</a></div>
                                    <div class="item"><a href="/az-list/K">K</a></div>
                                    <div class="item"><a href="/az-list/L">L</a></div>
                                    <div class="item"><a href="/az-list/M">M</a></div>
                                    <div class="item"><a href="/az-list/N">N</a></div>
                                    <div class="item"><a href="/az-list/O">O</a></div>
                                    <div class="item"><a href="/az-list/P">P</a></div>
                                    <div class="item"><a href="/az-list/Q">Q</a></div>
                                    <div class="item"><a href="/az-list/R">R</a></div>
                                    <div class="item"><a href="/az-list/S">S</a></div>
                                    <div class="item"><a href="/az-list/T">T</a></div>
                                    <div class="item"><a href="/az-list/U">U</a></div>
                                    <div class="item"><a href="/az-list/V">V</a></div>
                                    <div class="item"><a href="/az-list/W">W</a></div>
                                    <div class="item"><a href="/az-list/X">X</a></div>
                                    <div class="item"><a href="/az-list/Y">Y</a></div>
                                    <div class="item"><a href="/az-list/Z">Z</a></div>
                                </div>
                                <div class="clearfix"></div>
                            </div>
                        </div>
                    </div>
                    <div class="manga_list-sbs">
                        <div class="mls-wrap">
                            <?php $__empty_1 = true; $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $azlist): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                            <div class="item item-spc">
                                <a class="manga-poster" href="<?php echo e(route('detail', $azlist['slug'])); ?>">
                                    <img 
                                        src="<?php echo e((!$azlist['thumbnail'])
                                            ? $azlist['poster']
                                            : config('constant.url.api_image').$azlist['thumbnail']); ?>"
                                        class="manga-poster-img lazyload" 
                                        alt="<?php echo e($azlist['title']); ?>"
                                    >
                                </a>
                                <div class="manga-detail">
                                    <h3 class="manga-name">
                                        <a href="<?php echo e(route('detail', $azlist['slug'])); ?>" title="<?php echo e($azlist['title']); ?>">
                                            <?php echo e($azlist['title']); ?>

                                        </a>
                                    </h3>
                                    <div class="fd-infor">
                                        <?php $arr = json_decode($azlist['genre']) ?>
                                        <?php $__currentLoopData = $arr; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $genre): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <a href="/genre/<?php echo e($genre->genre); ?>">
                                            <?php echo e($genre->genre); ?>

                                        </a>,
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </div>
                                    <div class="fd-list">
                                        <?php $i = 0 ?>
                                        <?php $__currentLoopData = $azlist['chapters']->sortByDesc('chapter'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $k => $chapter): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <div class="fdl-item">
                                            <div class="chapter">
                                                <a href="/read<?php echo e($chapter['path']); ?>" class="d-inline">
                                                    <i class="far fa-file-alt mr-2"></i>
                                                    Chapter <?php echo e($chapter['chapter']); ?>

                                                </a>
                                            </div>
                                            <div class="release-time"></div>
                                            <div class="clearfix"></div>
                                        </div>
                                        <?php if(++$i == 3): ?>
                                        <?php break; ?>
                                        <?php endif; ?>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </div>
                                </div>
                                <div class="clearfix"></div>
                            </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                            <div class="text-center">
                                Manga tidak ditemukan.
                            </div>
                            <?php endif; ?>
                            <div class="clearfix"></div>
                        </div>
                        <div class="pre-pagination mt-4">
                            <?php echo e($data->links()); ?>

                        </div>
                    </div>
                </section>
                <div class="clearfix"></div>
            </div>
            <?php echo $__env->make('includes.main_sidebar', [
                'daily_views' => $daily_views,
                'weekly_views' => $weekly_views,
                'monthly_views' => $monthly_views
            ], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <div class="clearfix"></div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.web', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\manga-scraper\resources\views/pages/az_list/az_list.blade.php ENDPATH**/ ?>