
<?php $__env->startSection('content'); ?>
<div class="prebreadcrumb">
    <div class="container">
        <nav aria-label="breadcrumb">
            <ol class="breadcrumb">
                <li class="breadcrumb-item"><a href="<?php echo e(route('homepage')); ?>">Home</a></li>
                <li class="breadcrumb-item active">Manga List</li>
            </ol>
        </nav>
    </div>
</div>
<div id="main-wrapper" class="page-layout page-category">
    <div class="container">
        <div id="mw-2col">
            <!--Begin: main-content-->
            <div id="main-content">
                <!--Begin: Section Manga list-->
                <section class="block_area block_area_category">
                    <div class="block_area-header">
                        <div class="bah-heading float-left">
                            <h2 class="cat-heading">Manga List</h2>
                        </div>
                        <div class="cate-sort float-right">
                            <div class="cs-item">
                                <a href="/manga/image-mode" class="btn btn-sm btn-sort">Image Mode</a>
                            </div>
                            <div class="clearfix"></div>
                        </div>
                        <div class="clearfix"></div>
                    </div>
                    <div class="category_block">
                        <div class="c_b-wrap">
                            <div class="c_b-list active alphabet-list">
                                <div class="cbl-row justify-content-center">
                                    <?php $__currentLoopData = $groups; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $letter => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php if(preg_match("/[a-z]/i", $letter) && $letter != 'other'): ?>
                                    <div class="item">
                                        <a href="#<?php echo e($letter); ?>" class="mb-2">
                                            <?php echo e($letter); ?>

                                        </a>
                                    </div>
                                    <?php endif; ?>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </div>
                                <div class="clearfix"></div>
                            </div>
                        </div>
                    </div>
                    <div class="manga_list-sbs">
                        <div class="mls-wrap px-2">
                            <?php $__empty_1 = true; $__currentLoopData = $groups; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $letter => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                            <ul class="list-group list-group-flush">
                                <li id="<?php echo e($letter); ?>" class="list-group-item active"
                                    style="background-color: #2f2f2f;border:none">
                                    <?php if($letter == [0-9]): ?>
                                    0-9
                                    <?php elseif($letter == 'other'): ?>
                                    #
                                    <?php else: ?>
                                    <?php echo e($letter); ?>

                                    <?php endif; ?>
                                </li>
                                <li class="list-group-item" style="background-color: transparent;color: #fff">
                                    <div class="container">
                                        <div class="row">
                                            <?php $__currentLoopData = $value; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <div class="col-12 col-md-6 mb-2" style="display: list-item">
                                                <a href="<?php echo e(route('detail', $data['slug'])); ?>">
                                                    <span class="text-white">
                                                        <?php echo e($data['title']); ?>

                                                    </span>
                                                </a>
                                            </div>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </div>
                                    </div>
                                </li>
                            </ul>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                            <div class="text-center">
                                Manga tidak ditemukan.
                            </div>
                            <?php endif; ?>
                            <div class="clearfix"></div>
                        </div>
                    </div>
                </section>
                <div class="clearfix"></div>
            </div>

            <div id="main-sidebar">
                <section class="block_area block_area_sidebar block_area-genres">
                    <div class="block_area-header">
                        <div class="bah-heading">
                            <h2 class="cat-heading">Genres</h2>
                        </div>
                        <div class="clearfix"></div>
                    </div>
                    <div class="block_area-content">
                        <div class="category_block mb-0">
                            <div class="c_b-wrap">
                                <div class="c_b-list active">
                                    <div class="cbl-row">
                                        <?php $__empty_1 = true; $__currentLoopData = $arr_unique; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $genre): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                        <div class="item">
                                            <a href="/genre/<?php echo e($genre); ?>" title="<?php echo e($genre); ?>">
                                                <?php echo e($genre); ?>

                                            </a>
                                        </div>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                        Genre tidak ditemukan.
                                        <?php endif; ?>
                                    </div>
                                    <div class="clearfix"></div>
                                </div>
                            </div>
                        </div>
                    </div>
                </section>
            </div>
            <div class="clearfix"></div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.web', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\manga\resources\views/pages/manga_list/text_mode.blade.php ENDPATH**/ ?>