<!-- FOOTER -->
<div id="footer">
    <div id="footer-about">
        <div class="container">
            <div class="footer-top">
                <div class="desc px-md-5 text-justify">
                    <?php $seo = App\Models\SEO::get() ?>
                    <?php $__currentLoopData = $seo; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $artikel): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php echo $artikel->artikel; ?>

                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
                <br><br><br>
                <a href="/" class="footer-logo">
                    <img src="/<?php echo e($web['logo']); ?>" alt="Logo">
                    <div class="clearfix"></div>
                </a>
            </div>

            <div class="footer-links">
                <ul class="ulclear">
                    <li>
                        <a href="#" title="Terms of service">Terms of service</a>
                    </li>
                    <li>
                        <a href="#" title="DMCA">DMCA</a>
                    </li>
                    <li>
                        <a href="#" title="Contact">Contact</a>
                    </li>
                    <li>
                        <a href="#" title="Sitemap">Sitemap</a>
                    </li>
                </ul>
                <div class="clearfix"></div>
            </div>
            <div class="about-text">
                Mangareader does not store any files on our server, we only linked to the media which is hosted on 3rd
                party services.
            </div>
            <p class="copyright">© XRManga</p>
        </div>
    </div>
</div>
<!-- FOOTER --><?php /**PATH C:\laragon\www\manga-scraper\resources\views/includes/footer.blade.php ENDPATH**/ ?>