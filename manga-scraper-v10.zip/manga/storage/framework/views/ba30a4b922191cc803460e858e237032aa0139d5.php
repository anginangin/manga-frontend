
<?php $__env->startSection('content'); ?>
<div id="main-wrapper">
    <div class="container">
        <div id="mw-2col">
            <div id="main-content">
                <section class="block_area block_area_fav">
                    <div class="block_area-header">
                        <div class="float-left bah-heading">
                            <h2 class="cat-heading">Bookmark</h2>
                        </div>
                        <div class="clearfix"></div>
                    </div>
                    <div class="manga_list-sbs" id="manga-bookmarked">
                        <div class="mls-wrap">
                            <?php $__currentLoopData = $bookmark; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $manga): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>    
                                <div class="item item-spc">
                                    <div class="dr-fav">
                                        <a data-toggle="dropdown" aria-haspopup="true" aria-expanded="false" class="btn btn-circle btn-light btn-fav">
                                            <i class="fas fa-ellipsis-v"></i>
                                        </a>
                                        <div class="dropdown-menu dropdown-menu-model" aria-labelledby="ssc-list">
                                            <form id="bookmark-form">
                                                <?php echo csrf_field(); ?>
                                                <input type="hidden" id="manga_id<?php echo e($manga['id']); ?>" name="manga_id" value="<?php echo e($manga['id']); ?>">
                                                <input type="hidden" id="user_id<?php echo e(auth()->user()->id); ?>" name="user_id" value="<?php echo e(auth()->user()->id); ?>">
                                                <button type="button" class="btn btn-block btn-sm text-danger" id="removeBookmark<?php echo e($manga['id']); ?>">
                                                    Hapus
                                                </button>
                                            </form>
                                            <script>
                                                $(document).ready(function(){
                                                    $("#removeBookmark<?php echo e($manga['id']); ?>").click(function(e) {
                                                        e.preventDefault();
                                            
                                                        var manga_id = $("#manga_id<?php echo e($manga['id']); ?>").val();
                                                        var user_id = $("#user_id<?php echo e(auth()->user()->id); ?>").val();
                                                        let token = $("meta[name='csrf-token']").attr("content");
                                                    
                                                        $.ajax({
                                                            url: `/user/unbookmark`,
                                                            type: "POST",
                                                            cache: false,
                                                            data: {
                                                                manga_id: manga_id,
                                                                user_id: user_id,
                                                                _token: token
                                                            },
                                                            success:function(response){
                                                                toastr.options = {
                                                                "closeButton" : true,
                                                                "progressBar" : true,
                                                                "positionClass": "toast-bottom-right",
                                                                }
                                                                toastr.success(`${response.message}`);
                                                                $('#manga-bookmarked').load(document.URL + ' #manga-bookmarked');
                                                            },
                                                        });
                                                    });
                                                });
                                            </script>
                                        </div>
                                    </div>
                                    <a class="manga-poster" href="<?php echo e(route('detail', $manga['slug'])); ?>">
                                        <img src="<?php echo e((!$manga['thumbnail'])
                                            ? $manga['poster']
                                            : config('constant.url.api_image').$manga['thumbnail']); ?>" class="manga-poster-img lazyload" alt="<?php echo e($manga['title']); ?>" />
                                    </a>
                                    <div class="manga-detail">
                                        <h3 class="manga-name">
                                            <a href="<?php echo e(route('detail', $manga['slug'])); ?>" title="<?php echo e($manga['title']); ?>">
                                                <?php echo e($manga['title']); ?>

                                            </a>
                                        </h3>
                                        <div class="fd-infor">
                                            <span class="fdi-item fdi-cate">
                                                <?php $genres = json_decode($manga['genre']) ?>
                                                <?php $__currentLoopData = $genres; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $genre): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <a href="/genre/<?php echo e($genre->genre); ?>">
                                                    <?php echo e($genre->genre); ?>

                                                </a>,
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </span>
                                            <div class="clearfix"></div>
                                        </div>
                                        <div class="fd-list">
                                            <?php $i = 0 ?>
                                            <?php $__currentLoopData = $manga['chapters']->sortByDesc('chapter'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $k => $chapter): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <div class="fdl-item">
                                                <div class="chapter">
                                                    <a href="/read<?php echo e($chapter['path']); ?>" class="d-inline">
                                                        <i class="far fa-file-alt mr-2"></i>
                                                        Chapter <?php echo e($chapter['chapter']); ?>

                                                    </a>
                                                </div>
                                                <div class="release-time">
                                                    <span class="text-muted"></span>
                                                </div>
                                                <div class="clearfix"></div>
                                            </div>
                                            <?php if(++$i == 3): ?>
                                            <?php break; ?>
                                            <?php endif; ?>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </div>
                                    </div>
                                    <div class="clearfix"></div>
                                </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <div class="clearfix"></div>
                        </div>
                        <div class="pre-pagination mt-4">
                            <nav aria-label="Page navigation">
                            
                            </nav>
                        </div>
                    </div>
                </section>
                <div class="clearfix"></div>
            </div>
            <div id="main-sidebar">
                <section class="block_area block_area_sidebar block_area-profile">
                    <div class="block_area-header">
                        <div class="float-left bah-heading">
                            <h2 class="cat-heading">Profile Menu</h2>
                        </div>
                        <div class="clearfix"></div>
                    </div>
                    <div class="block_area-content">
                        <div class="menu-profiles">
                            <ul class="ulclear">
                                <li class="">
                                    <a href="/user/profile" class="mp-item">
                                        <i class="fas fa-user mr-3"></i>
                                        Profile
                                    </a>
                                </li>
                                <li class="active">
                                    <a href="/user/reading-list" class="mp-item">
                                        <i class="fas fa-bookmark mr-3"></i>
                                        Bookmark
                                    </a>
                                </li>
                                <li class="">
                                    <a href="/user/notifications" class="mp-item">
                                        <i class="fas fa-bell mr-3"></i>
                                        Notifications
                                    </a>
                                </li>
                            </ul>
                        </div>
                    </div>
                </section>
            </div>
            <div class="clearfix"></div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.web', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\manga-scraper\resources\views/pages/user/reading-list.blade.php ENDPATH**/ ?>