<div id="main-sidebar">
    <section class="block_area block_area_sidebar block_area-realtime">
        <div class="block_area-header">
            <?php $__currentLoopData = $bannerAtasMaPop; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $bannerAtasMaPop): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <a href="<?php echo e($bannerAtasMaPop->link); ?>" target="_blank">
                <img src="<?php echo e(config('constant.url.backend').'/banner/'.$bannerAtasMaPop->gambar); ?>" class="img-fluid mb-2">
            </a>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <div class="float-left bah-heading">
                <h2 class="cat-heading">
                    <?php echo e(App\Models\Title::select('most_view')->first()->most_view); ?>

                </h2>
            </div>
            <div class="clearfix"></div>
        </div>
        <div class="block_area-content">
            <div class="cbox cbox-list cbox-realtime">
                <div class="cbox-content">
                    <ul class="nav nav-pills nav-fill nav-tabs anw-tabs">
                        <li class="nav-item">
                            <a data-toggle="tab" href="#chart-today" class="nav-link active">
                                Harian
                            </a>
                        </li>
                        <li class="nav-item">
                            <a data-toggle="tab" href="#chart-week" class="nav-link">
                                Mingguan
                            </a>
                        </li>
                        <li class="nav-item">
                            <a data-toggle="tab" href="#chart-month" class="nav-link">
                                Bulanan
                            </a>
                        </li>
                    </ul>
                    <div class="tab-content">
                        <div id="chart-today" class="tab-pane show active">
                            <div class="featured-block-ul featured-block-chart">
                                <ul class="ulclear">
                                    <?php $__empty_1 = true; $__currentLoopData = $dailyViews; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $dailyViews): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                    <?php if($dailyViews->today_count != 0): ?>
                                    <li class="item-top">
                                        <div class="ranking-number">
                                            <span><?php echo e($loop->iteration); ?></span>
                                        </div>
                                        <a 
                                            href="<?php echo e(route('detail', str_replace('/manga/','',$dailyViews->slug))); ?>" 
                                            class="manga-poster"
                                        >
                                            <img 
                                                src="<?php echo e((!$dailyViews->thumbnail)
                                                    ? $dailyViews->poster
                                                    : config('constant.url.api_image').$dailyViews->thumbnail); ?>"
                                                class="manga-poster-img lazyload" 
                                                alt="<?php echo e($dailyViews->title); ?>" 
                                            />
                                        </a>
                                        <div class="manga-detail">
                                            <h3 class="manga-name">
                                                <a 
                                                    href="<?php echo e(route('detail', str_replace('/manga/','',$dailyViews->slug))); ?>" 
                                                    title="<?php echo e($dailyViews->title); ?>"
                                                >
                                                    <?php echo e($dailyViews->title); ?>

                                                </a>
                                            </h3>
                                            <div class="fd-infor">
                                                <span class="fdi-item fdi-cate">
                                                    <?php $genres = json_decode($dailyViews->genre) ?>
                                                    <?php $__currentLoopData = $genres; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $genre): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <a href="genre/<?php echo e($genre->genre); ?>">
                                                        <?php echo e($genre->genre); ?>

                                                        <?php if( !$loop->last): ?>
                                                        ,
                                                        <?php endif; ?>
                                                    </a>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                </span>
                                                <span class="fdi-item fdi-view">
                                                    <?php echo e(number_format($dailyViews->today_count)); ?>x
                                                    dilihat
                                                </span>
                                                <div class="d-block">
                                                    <small style="visibility: hidden">.</small>
                                                </div>
                                                <div class="clearfix"></div>
                                            </div>
                                        </div>
                                        <div class="clearfix"></div>
                                    </li>
                                    <?php endif; ?>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                    <div class="text-center">
                                        <br>
                                        Data tidak ditemukan.
                                    </div>
                                    <?php endif; ?>
                                </ul>
                                <div class="clearfix"></div>
                            </div>
                        </div>
                        <div id="chart-week" class="tab-pane">
                            <div class="featured-block-ul featured-block-chart">
                                <ul class="ulclear">
                                    <?php $__empty_1 = true; $__currentLoopData = $weeklyViews; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $weeklyViews): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                    <?php if($weeklyViews->this_week != 0): ?>
                                    <li class="item-top">
                                        <div class="ranking-number">
                                            <span><?php echo e($loop->iteration); ?></span>
                                        </div>
                                        <a 
                                            href="<?php echo e(route('detail', str_replace('/manga/','',$weeklyViews->slug))); ?>" 
                                            class="manga-poster"
                                        >
                                            <img 
                                                src="<?php echo e((!$weeklyViews->thumbnail)
                                                    ? $weeklyViews->poster
                                                    : config('constant.url.api_image') . $weeklyViews->thumbnail); ?>"
                                                class="manga-poster-img lazyload" 
                                                alt="<?php echo e($weeklyViews->title); ?>" 
                                            />
                                        </a>
                                        <div class="manga-detail">
                                            <h3 class="manga-name">
                                                <a 
                                                    href="<?php echo e(route('detail', str_replace('/manga/','',$weeklyViews->slug))); ?>" 
                                                    title="<?php echo e($weeklyViews->title); ?>"
                                                >
                                                    <?php echo e($weeklyViews->title); ?>

                                                </a>
                                            </h3>
                                            <div class="fd-infor">
                                                <span class="fdi-item fdi-cate">
                                                    <?php $genres = json_decode($weeklyViews->genre) ?>
                                                    <?php $__currentLoopData = $genres; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $genre): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <a href="genre/<?php echo e($genre->genre); ?>">
                                                        <?php echo e($genre->genre); ?>

                                                        <?php if( !$loop->last): ?>
                                                        ,
                                                        <?php endif; ?>
                                                    </a>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                </span>
                                                <span class="fdi-item fdi-view">
                                                    <?php echo e(number_format($weeklyViews->this_week)); ?>x
                                                    dilihat
                                                </span>
                                                <div class="d-block">
                                                    <small style="visibility: hidden">.</small>
                                                </div>
                                                <div class="clearfix"></div>
                                            </div>
                                        </div>
                                        <div class="clearfix"></div>
                                    </li>
                                    <?php endif; ?>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                    <div class="text-center">
                                        <br>
                                        Data tidak ditemukan.
                                    </div>
                                    <?php endif; ?>
                                </ul>
                                <div class="clearfix"></div>
                            </div>
                        </div>
                        <div id="chart-month" class="tab-pane">
                            <div class="featured-block-ul featured-block-chart">
                                <ul class="ulclear">
                                    <?php $count = 0 ?>
                                    <?php $__empty_1 = true; $__currentLoopData = $monthlyViews; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $monthlyViews): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                    <?php if($monthlyViews->this_month != 0): ?>
                                    <li class="item-top">
                                        <div class="ranking-number">
                                            <span><?php echo e($loop->iteration); ?></span>
                                        </div>
                                        <a 
                                            href="<?php echo e(route('detail', str_replace('/manga/','',$monthlyViews->slug))); ?>" 
                                            class="manga-poster"
                                        >
                                            <img 
                                                src="<?php echo e((!$monthlyViews->thumbnail)
                                                    ? $monthlyViews->poster
                                                    : config('constant.url.api_image') . $monthlyViews->thumbnail); ?>"
                                                class="manga-poster-img lazyload" 
                                                alt="<?php echo e($monthlyViews->title); ?>" 
                                            />
                                        </a>
                                        <div class="manga-detail">
                                            <h3 class="manga-name">
                                                <a 
                                                    href="<?php echo e(route('detail', str_replace('/manga/','',$monthlyViews->slug))); ?>" 
                                                    title="<?php echo e($monthlyViews->title); ?>"
                                                >
                                                    <?php echo e($monthlyViews->title); ?>

                                                </a>
                                            </h3>
                                            <div class="fd-infor">
                                                <span class="fdi-item fdi-cate">
                                                    <?php $genres = json_decode($monthlyViews->genre) ?>
                                                    <?php $__currentLoopData = $genres; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $genre): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <a href="genre/<?php echo e($genre->genre); ?>">
                                                        <?php echo e($genre->genre); ?>

                                                        <?php if( !$loop->last): ?>
                                                        ,
                                                        <?php endif; ?>
                                                    </a>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                </span>
                                                <span class="fdi-item fdi-view">
                                                    <?php echo e(number_format($monthlyViews->this_month)); ?>x
                                                    dilihat
                                                </span>
                                                <div class="d-block">
                                                    <small style="visibility: hidden">.</small>
                                                </div>
                                                <div class="clearfix"></div>
                                            </div>
                                        </div>
                                        <div class="clearfix"></div>
                                    </li>
                                    <?php endif; ?>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                    <div class="text-center">
                                        <br>
                                        Data tidak ditemukan.
                                    </div>
                                    <?php endif; ?>
                                </ul>
                                <div class="clearfix"></div>
                            </div>
                        </div>
                    </div>
                    <div class="clearfix"></div>
                </div>
            </div>
            <?php $__currentLoopData = $bannerBawahMaPop; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $bannerBawahMaPop): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <a href="<?php echo e($bannerBawahMaPop); ?>" target="_blank">
                <img src="<?php echo e(config('constant.url.backend').'/banner/'.$bannerBawahMaPop->gambar); ?>" class="img-fluid">
            </a>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </section>
    <div class="clearfix"></div>
</div><?php /**PATH C:\laragon\www\manga\resources\views/includes/main_sidebar.blade.php ENDPATH**/ ?>