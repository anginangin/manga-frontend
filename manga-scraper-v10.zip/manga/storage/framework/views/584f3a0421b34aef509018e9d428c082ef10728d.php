
<?php $__env->startSection('content'); ?>
<div id="main-wrapper">
    <div class="container">
        <div id="mw-2col">
            <div id="main-content">
                <!--Begin: Section Manga list-->
                <section class="block_area block_area_profile">
                    <div class="block_area-header">
                        <div class="bah-heading">
                            <h2 class="cat-heading">Notifications</h2>
                        </div>
                        <div class="clearfix"></div>
                    </div>
                    <div class="block_area-content">
                        <div class="inbox-list">
                            <div class="inbox-tabs">
                                <div class="float-right">
                                    <a data-position="page" class="btn btn-sm btn-blank notify-seen-all"
                                        style="font-size: 12px;"><i class="fas fa-check mr-1"></i> Mark <span
                                            class="d-none d-sm-inline">all as</span> read</a>
                                </div>
                                <div class="clearfix"></div>
                            </div>
                            <div class="inbox-item-list">

                            </div>
                        </div>
                        <div class="pre-pagination mt-4">
                            <nav aria-label="Page navigation">

                            </nav>
                        </div>
                    </div>
                </section>
                <!--End: Section Manga list-->
                <div class="clearfix"></div>
            </div>
            <!--Begin: main-sidebar-->
            <div id="main-sidebar">
                <section class="block_area block_area_sidebar block_area-profile">
                    <div class="block_area-header">
                        <div class="float-left bah-heading">
                            <h2 class="cat-heading">Profile Menu</h2>
                        </div>
                        <div class="clearfix"></div>
                    </div>
                    <div class="block_area-content">
                        <div class="menu-profiles">
                            <ul class="ulclear">
                                <li class=""><a href="/user/profile" class="mp-item"><i
                                            class="fas fa-user mr-3"></i>Profile</a></li>
                                <li class=""><a href="/user/reading-list" class="mp-item"><i
                                            class="fas fa-bookmark mr-3"></i>Bookmark</a></li>
                                <li class="active"><a href="/user/notifications" class="mp-item"><i
                                            class="fas fa-bell mr-3"></i>Notifications</a></li>
                            </ul>
                        </div>
                    </div>
                </section>
            </div>
            <!--/End: main-sidebar-->
            <div class="clearfix"></div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.web', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\manga-scraper\resources\views/pages/user/notifications.blade.php ENDPATH**/ ?>