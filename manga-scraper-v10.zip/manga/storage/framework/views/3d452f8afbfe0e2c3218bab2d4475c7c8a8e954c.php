<?php $markdown = app('Parsedown'); ?>
<?php
    // TODO: There should be a better place for this.
    $markdown->setSafeMode(true);
    $setTheme = \DB::table('web_setting')->join('theme_colors', 'theme_colors.id', '=', 'web_setting.theme_id')->first();
?>

<div id="comment-<?php echo e($comment->getKey()); ?>" class="media">
    <?php if($comment->commenter->avatar): ?>
        <img class="mr-3 rounded-circle" width="40" height="40" src="/avatar/<?php echo e($comment->commenter->avatar); ?>" alt="<?php echo e($comment->commenter->name ?? $comment->guest_name); ?> Avatar">
    <?php else: ?>
        <img class="mr-3 rounded-circle" width="40" height="40" src="https://ui-avatars.com/api/?name=<?php echo e($comment->commenter->name); ?>" alt="<?php echo e($comment->commenter->name ?? $comment->guest_name); ?> Avatar">
    <?php endif; ?>
    <div class="media-body">
        <h6 class="mt-0 mb-1"><?php echo e($comment->commenter->name ?? $comment->guest_name); ?> <small class="text-muted">- <?php echo e($comment->created_at->diffForHumans()); ?></small></h6>
        <div style="white-space: pre-wrap;"><?php echo $markdown->line($comment->comment); ?></div>

        <div>
            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('reply-to-comment', $comment)): ?>
                <button data-toggle="modal" data-target="#reply-modal-<?php echo e($comment->getKey()); ?>" class="btn btn-sm btn-link">
                    <small>
                        <i class="fas fa-reply"></i>
                        Balas
                    </small>
                </button>
            <?php endif; ?>
            
            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('delete-comment', $comment)): ?>
                <a href="<?php echo e(route('comments.destroy', $comment->getKey())); ?>" onclick="event.preventDefault();document.getElementById('comment-delete-form-<?php echo e($comment->getKey()); ?>').submit();" class="btn btn-sm btn-link text-danger">
                    <small>
                        <i class="fas fa-trash"></i>
                        Hapus
                    </small>
                </a>
                <form id="comment-delete-form-<?php echo e($comment->getKey()); ?>" action="<?php echo e(route('comments.destroy', $comment->getKey())); ?>" method="POST" style="display: none;">
                    <?php echo method_field('DELETE'); ?>
                    <?php echo csrf_field(); ?>
                </form>
            <?php endif; ?>
        </div>

        

        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('reply-to-comment', $comment)): ?>
            <div class="modal" id="reply-modal-<?php echo e($comment->getKey()); ?>" role="dialog">
                <div class="modal-dialog" role="document">
                    <div class="modal-content" style="background: <?php echo e($setTheme->secondary_base_color); ?> !important">
                        <form method="POST" action="<?php echo e(route('comments.reply', $comment->getKey())); ?>">
                            <?php echo csrf_field(); ?>
                            <div class="modal-header" style="border-bottom: none">
                                <h5 class="modal-title">Balas Komentar</h5>
                                <button type="button" class="close" data-dismiss="modal">
                                <span class="text-white">&times;</span>
                                </button>
                            </div>
                            <div class="modal-body">
                                <div class="form-group">
                                    <label for="message">Tulis Pesan</label>
                                    <textarea required class="form-control" name="message" rows="3" style="background: <?php echo e($setTheme->tertiary_base_color); ?>;
                                    color: <?php echo e($setTheme->text_color); ?>;"></textarea>
                                </div>
                            </div>
                            <div class="modal-footer" style="border-top: none">
                                <button type="button" class="btn btn-sm btn-outline-secondary text-uppercase" data-dismiss="modal">Batal</button>
                                <button type="submit" class="btn btn-sm text-uppercase text-dark" style="background: <?php echo e($setTheme->button_color); ?> !important">Kirim</button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        <?php endif; ?>

        <br />

        <?php
            if (!isset($indentationLevel)) {
                $indentationLevel = 1;
            } else {
                $indentationLevel++;
            }
        ?>

        
        <?php if($grouped_comments->has($comment->getKey()) && $indentationLevel <= $maxIndentationLevel): ?>
            
            <?php $__currentLoopData = $grouped_comments[$comment->getKey()]; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $child): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php echo $__env->make('comments::_comment', [
                    'comment' => $child,
                    'grouped_comments' => $grouped_comments
                ], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <?php endif; ?>

    </div>
</div>


<?php if($grouped_comments->has($comment->getKey()) && $indentationLevel > $maxIndentationLevel): ?>
    
    <?php $__currentLoopData = $grouped_comments[$comment->getKey()]; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $child): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <?php echo $__env->make('comments::_comment', [
            'comment' => $child,
            'grouped_comments' => $grouped_comments
        ], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php endif; ?><?php /**PATH C:\laragon\www\manga\resources\views/vendor/comments/_comment.blade.php ENDPATH**/ ?>