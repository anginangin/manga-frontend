<link rel="shortcut icon" href="https://i0.wp.com/mareceh.com/wp-content/uploads/2022/03/cropped-Ma_receh2-32x32.png" />
<link rel="apple-touch-icon" sizes="180x180" href="https://mangareader.to/images/apple-touch-icon.png" />

<link rel="mask-icon" href="https://mangareader.to/images/safari-pinned-tab.svg" color="#5f25a6" />
<link rel="stylesheet" href="/assets/css/bootstrap.min.css" />
<link rel="stylesheet" href="/assets/css/bootstrap.min.css.map" />
<link rel="stylesheet" href="/assets/css/bootstrap.css.map" />
<link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.3.1/css/all.css" />
<link rel="stylesheet" href="/assets/css/custom.css" /><?php /**PATH C:\laragon\www\laravel-scraper\resources\views/includes/style.blade.php ENDPATH**/ ?>