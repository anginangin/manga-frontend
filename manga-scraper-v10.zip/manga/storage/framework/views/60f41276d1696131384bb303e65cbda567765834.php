<link rel="shortcut icon" href="/<?php echo e($web['icon']); ?>" />
<link rel="apple-touch-icon" sizes="180x180" href="//<?php echo e($web['icon']); ?>" />
<link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.3.1/css/all.css" />
<link rel="stylesheet" href="/assets/css/bootstrap.min.css" />
<link rel="stylesheet" href="/assets/css/bootstrap.min.css.map" />
<link rel="stylesheet" href="/assets/css/bootstrap.css.map" />
<link rel="stylesheet" href="/assets/css/custom.css" /><?php /**PATH C:\laragon\www\manga-scraper\resources\views/includes/style.blade.php ENDPATH**/ ?>