<div id="main-sidebar">
    <section class="block_area block_area_sidebar block_area-realtime">
        <div class="block_area-header">
            <div class="float-left bah-heading">
                <h2 class="cat-heading">
                    Most Viewed
                </h2>
            </div>
            <div class="clearfix"></div>
        </div>
        <div class="block_area-content">
            <div class="cbox cbox-list cbox-realtime">
                <div class="cbox-content">
                    <ul class="nav nav-pills nav-fill nav-tabs anw-tabs">
                        <li class="nav-item">
                            <a data-toggle="tab" href="#chart-today" class="nav-link active">
                                Daily
                            </a>
                        </li>
                        <li class="nav-item">
                            <a data-toggle="tab" href="#chart-week" class="nav-link">
                                Weekly
                            </a>
                        </li>
                        <li class="nav-item">
                            <a data-toggle="tab" href="#chart-month" class="nav-link">
                                Monthly
                            </a>
                        </li>
                    </ul>
                    <div class="tab-content">
                        <div id="chart-today" class="tab-pane show active">
                            <div class="featured-block-ul featured-block-chart">
                                <ul class="ulclear">
                                    <?php $__empty_1 = true; $__currentLoopData = $daily_views; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $daily): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                    <?php if($daily->today_count != 0): ?>
                                    <li class="item-top">
                                        <div class="ranking-number">
                                            <span><?php echo e($loop->iteration); ?></span>
                                        </div>
                                        <a 
                                            href="<?php echo e(route('detail', str_replace('/manga/','',$daily->slug))); ?>" 
                                            class="manga-poster"
                                        >
                                            <img 
                                                src="<?php echo e((!$daily->thumbnail)
                                                    ? $daily->poster
                                                    : config('constant.url.api_image').$daily->thumbnail); ?>"
                                                class="manga-poster-img lazyload" 
                                                alt="<?php echo e($daily->title); ?>" 
                                            />
                                        </a>
                                        <div class="manga-detail">
                                            <h3 class="manga-name">
                                                <a 
                                                    href="<?php echo e(route('detail', str_replace('/manga/','',$daily->slug))); ?>" 
                                                    title="<?php echo e($daily->title); ?>"
                                                >
                                                    <?php echo e($daily->title); ?>

                                                </a>
                                            </h3>
                                            <div class="fd-infor">
                                                <span class="fdi-item fdi-cate">
                                                    <?php $genres = json_decode($daily->genre) ?>
                                                    <?php $__currentLoopData = $genres; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $genre): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <a href="genre/<?php echo e($genre->genre); ?>">
                                                        <?php echo e($genre->genre); ?>,
                                                    </a>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                </span>
                                                <span class="fdi-item fdi-view">
                                                    <?php echo e(number_format($daily->today_count)); ?>

                                                    views
                                                </span>
                                                <div class="d-block">
                                                    <small style="visibility: hidden">.</small>
                                                </div>
                                                <div class="clearfix"></div>
                                            </div>
                                        </div>
                                        <div class="clearfix"></div>
                                    </li>
                                    <?php endif; ?>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                    <div class="text-center">
                                        <br>
                                        Data tidak ditemukan.
                                    </div>
                                    <?php endif; ?>
                                </ul>
                                <div class="clearfix"></div>
                            </div>
                        </div>
                        <div id="chart-week" class="tab-pane">
                            <div class="featured-block-ul featured-block-chart">
                                <ul class="ulclear">
                                    <?php $count = 0 ?>
                                    <?php $__empty_1 = true; $__currentLoopData = $weekly_views; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $weekly): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                    <?php if($weekly->this_week != 0): ?>
                                    <li class="item-top">
                                        <div class="ranking-number">
                                            <span><?php echo e($count+1); ?></span>
                                        </div>
                                        <a 
                                            href="<?php echo e(route('detail', str_replace('/manga/','',$weekly->slug))); ?>" 
                                            class="manga-poster"
                                        >
                                            <img 
                                                src="<?php echo e((!$weekly->thumbnail)
                                                    ? $weekly->poster
                                                    : config('constant.url.api_image') . $weekly->thumbnail); ?>"
                                                class="manga-poster-img lazyload" 
                                                alt="<?php echo e($weekly->title); ?>" 
                                            />
                                        </a>
                                        <div class="manga-detail">
                                            <h3 class="manga-name">
                                                <a 
                                                    href="<?php echo e(route('detail', str_replace('/manga/','',$weekly->slug))); ?>" 
                                                    title="<?php echo e($weekly->title); ?>"
                                                >
                                                    <?php echo e($weekly->title); ?>

                                                </a>
                                            </h3>
                                            <div class="fd-infor">
                                                <span class="fdi-item fdi-cate">
                                                    <?php $genres = json_decode($weekly->genre) ?>
                                                    <?php $__currentLoopData = $genres; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $genre): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <a href="genre/<?php echo e($genre->genre); ?>">
                                                        <?php echo e($genre->genre); ?>,
                                                    </a>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                </span>
                                                <span class="fdi-item fdi-view">
                                                    <?php echo e(number_format($weekly->this_week)); ?>

                                                    views
                                                </span>
                                                <div class="d-block">
                                                    <small style="visibility: hidden">.</small>
                                                </div>
                                                <div class="clearfix"></div>
                                            </div>
                                        </div>
                                        <div class="clearfix"></div>
                                    </li>
                                    <?php endif; ?>
                                    <?php
                                    $count++
                                    ?>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                    <div class="text-center">
                                        <br>
                                        Data tidak ditemukan.
                                    </div>
                                    <?php endif; ?>
                                </ul>
                                <div class="clearfix"></div>
                            </div>
                        </div>
                        <div id="chart-month" class="tab-pane">
                            <div class="featured-block-ul featured-block-chart">
                                <ul class="ulclear">
                                    <?php $count = 0 ?>
                                    <?php $__empty_1 = true; $__currentLoopData = $monthly_views; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $monthly): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                    <?php if($monthly->this_month != 0): ?>
                                    <li class="item-top">
                                        <div class="ranking-number">
                                            <span><?php echo e($count+1); ?></span>
                                        </div>
                                        <a 
                                            href="<?php echo e(route('detail', str_replace('/manga/','',$monthly->slug))); ?>" 
                                            class="manga-poster"
                                        >
                                            <img 
                                                src="<?php echo e((!$monthly->thumbnail)
                                                    ? $monthly->poster
                                                    : config('constant.url.api_image') . $monthly->thumbnail); ?>"
                                                class="manga-poster-img lazyload" 
                                                alt="<?php echo e($monthly->title); ?>" 
                                            />
                                        </a>
                                        <div class="manga-detail">
                                            <h3 class="manga-name">
                                                <a 
                                                    href="<?php echo e(route('detail', str_replace('/manga/','',$monthly->slug))); ?>" 
                                                    title="<?php echo e($monthly->title); ?>"
                                                >
                                                    <?php echo e($monthly->title); ?>

                                                </a>
                                            </h3>
                                            <div class="fd-infor">
                                                <span class="fdi-item fdi-cate">
                                                    <?php $genres = json_decode($monthly->genre) ?>
                                                    <?php $__currentLoopData = $genres; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $genre): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <a href="genre/<?php echo e($genre->genre); ?>">
                                                        <?php echo e($genre->genre); ?>,
                                                    </a>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                </span>
                                                <span class="fdi-item fdi-view">
                                                    <?php echo e(number_format($monthly->this_month)); ?> 
                                                    views
                                                </span>
                                                <div class="d-block">
                                                    <small style="visibility: hidden">.</small>
                                                </div>
                                                <div class="clearfix"></div>
                                            </div>
                                        </div>
                                        <div class="clearfix"></div>
                                    </li>
                                    <?php endif; ?>
                                    <?php
                                    $count++
                                    ?>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                    <div class="text-center">
                                        <br>
                                        Data tidak ditemukan.
                                    </div>
                                    <?php endif; ?>
                                </ul>
                                <div class="clearfix"></div>
                            </div>
                        </div>
                    </div>
                    <div class="clearfix"></div>
                </div>
            </div>
        </div>
    </section>
    <div class="clearfix"></div>
</div><?php /**PATH C:\laragon\www\manga-scraper\resources\views/includes/main_sidebar.blade.php ENDPATH**/ ?>