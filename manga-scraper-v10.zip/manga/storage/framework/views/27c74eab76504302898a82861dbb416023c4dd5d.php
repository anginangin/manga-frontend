<!-- FOOTER -->
<div id="footer">
    <div id="footer-about">
        <div class="container">
            <div class="footer-top">
                <a href="https://mangareader.to/" class="footer-logo">
                    <img src="http://mareceh.com/wp-content/uploads/2022/03/Ma_receh.png" alt="Logo" />
                    <div class="clearfix"></div>
                </a>
            </div>

            <div class="footer-links">
                <ul class="ulclear">
                    <li>
                        <a href="https://mangareader.to/terms" title="Terms of service">Terms of service</a>
                    </li>
                    <li>
                        <a href="https://mangareader.to/dmca" title="DMCA">DMCA</a>
                    </li>
                    <li>
                        <a href="https://mangareader.to/contact" title="Contact">Contact</a>
                    </li>
                    <li>
                        <a href="https://mangareader.to/sitemap.xml" title="Sitemap">Sitemap</a>
                    </li>
                </ul>
                <div class="clearfix"></div>
            </div>
            <div class="about-text">
                Mangareader does not store any files on our server, we only linked
                to the media which is hosted on 3rd party services.
            </div>
            <p class="copyright">© Mangareader.to</p>
        </div>
    </div>
</div>
<!-- FOOTER --><?php /**PATH C:\laragon\www\laravel-scraper\resources\views/includes/footer.blade.php ENDPATH**/ ?>