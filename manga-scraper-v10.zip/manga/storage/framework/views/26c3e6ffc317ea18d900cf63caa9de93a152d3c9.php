
<?php $__env->startSection('content'); ?>
<div class="prebreadcrumb">
    <div class="container">
        <nav aria-label="breadcrumb">
            <ol class="breadcrumb">
                <li class="breadcrumb-item"><a href="<?php echo e(route('homepage')); ?>">Home</a></li>
                <li class="breadcrumb-item active">Manga List</li>
            </ol>
        </nav>
    </div>
</div>
<div id="main-wrapper" class="page-layout page-category">
    <div class="container">
        <div id="mw-2col">
            <!--Begin: main-content-->
            <div id="main-content">
                <!--Begin: Section Manga list-->
                <section class="block_area block_area_category mt-3">
                    <div class="block_area-header">
                        <div class="bah-heading float-left">
                            <h2 class="cat-heading">Manga List</h2>
                        </div>
                        <div class="cate-sort float-right">
                            <div class="cs-item">
                                <a href="/manga/image-mode" class="btn btn-sm btn-sort">Image Mode</a>
                                
                                
                            </div>
                            <div class="clearfix"></div>
                        </div>
                        <div class="clearfix"></div>
                    </div>
                    <div class="category_block">
                        <div class="c_b-wrap">
                            <div class="c_b-list active alphabet-list">
                                <div class="cbl-row justify-content-center">
                                    <div class="item mt-3">
                                        <?php $__currentLoopData = $groups; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $letter => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <?php if(preg_match("/[a-z]/i", $letter)): ?>
                                        <a href="#<?php echo e($letter); ?>" class="mb-2 mr-2">
                                            <?php echo e($letter); ?>

                                        </a>
                                        <?php endif; ?>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </div>
                                </div>
                                <div class="clearfix"></div>
                            </div>
                        </div>
                    </div>
                    <div class="manga_list-sbs">
                        <div class="mls-wrap px-2">
                            
                            <?php $__currentLoopData = $groups; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $letter => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <ul class="list-group list-group-flush">
                                <li id="<?php echo e($letter); ?>" class="list-group-item active"
                                    style="background-color: #7B36CE;">
                                    <?php if($letter == [0-9]): ?>
                                    #
                                    <?php elseif($letter == '"'): ?>
                                    �
                                    <?php else: ?>
                                    <?php echo e($letter); ?>

                                    <?php endif; ?>
                                    
                                </li>
                                <li class="list-group-item" style="background-color: transparent;color: #fff">
                                    <div class="container">
                                        <div class="row">
                                            <?php $__currentLoopData = $value; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <div class="col-12 col-md-6 mb-2" style="display: list-item">
                                                <a href="">
                                                    <span class="text-white">
                                                        <?php echo e(str_replace('Bahasa Indonesia','',$data['title'])); ?>

                                                    </span>
                                                </a>
                                            </div>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </div>
                                    </div>
                                </li>
                            </ul>
                            
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <div class="clearfix"></div>
                        </div>
                    </div>
                </section>
                <!--End: Section Manga list-->
                <div class="clearfix"></div>
            </div>
            <!--/End: main-content-->
            <!--Begin: main-sidebar-->
            <div id="main-sidebar">
                <section class="block_area block_area_sidebar block_area-genres">
                    <div class="block_area-header">
                        <div class="bah-heading">
                            <h2 class="cat-heading">Genres</h2>
                        </div>
                        <div class="clearfix"></div>
                    </div>
                    <div class="block_area-content">
                        <div class="category_block mb-0">
                            <div class="c_b-wrap">
                                <div class="c_b-list active">
                                    <div class="cbl-row">
                                        <div class="item item-focus focus-01"><a href="/manga/page/1/update" title=""><i
                                                    class="mr-1">⚡</i>
                                                Latest Updated</a></div>
                                        <div class="item item-focus focus-02"><a href="/manga/page/1/latest" title=""><i
                                                    class="mr-1">✌</i> New Release</a></div>
                                        <div class="item item-focus focus-04"><a href="/manga/page/1/popular"
                                                title=""><i class="mr-1">🔥</i>
                                                Most Viewed</a></div>
                                        
                                    </div>
                                    <div class="cbl-row">
                                        
                                    </div>
                                    <div class="clearfix"></div>
                                </div>
                            </div>
                        </div>
                    </div>
                </section>
            </div>
            <!--/End: main-sidebar-->
            <div class="clearfix"></div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\manga-scraper\resources\views/manga_list_text.blade.php ENDPATH**/ ?>