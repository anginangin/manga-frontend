
<?php $__env->startSection('content'); ?>
<div class="prebreadcrumb">
    <div class="container">
        <nav aria-label="breadcrumb">
            <ol class="breadcrumb">
                <li class="breadcrumb-item"><a href="/">Home</a></li>
                <li class="breadcrumb-item active">A-Z List</li>
            </ol>
        </nav>
    </div>
</div>
<div id="main-wrapper" class="page-layout page-category">
    <div class="container">
        <div id="mw-2col">
            <!--Begin: main-content-->
            <div id="main-content">
                <!--Begin: Section Manga list-->
                <section class="block_area block_area_category">
                    <div class="block_area-header">
                        <div class="bah-heading float-left">
                            <h2 class="cat-heading">A-Z List</h2>
                        </div>
                        <div class="clearfix"></div>
                    </div>
                    <div class="category_block">
                        <div class="c_b-wrap">
                            <div class="c_b-list active alphabet-list">
                                <div class="cbl-row">
                                    <div class="item"><a href="#">#</a></div>
                                    <div class="item"><a href="#">0-9</a></div>
                                    <div class="item"><a href="#">A</a></div>
                                    <div class="item"><a href="#">B</a></div>
                                    <div class="item"><a href="#">C</a></div>
                                    <div class="item"><a href="#">D</a></div>
                                    <div class="item"><a href="#">E</a></div>
                                    <div class="item"><a href="#">F</a></div>
                                    <div class="item"><a href="#">G</a></div>
                                    <div class="item"><a href="#">H</a></div>
                                    <div class="item"><a href="#">I</a></div>
                                    <div class="item"><a href="#">J</a></div>
                                    <div class="item"><a href="#">K</a></div>
                                    <div class="item"><a href="#">L</a></div>
                                    <div class="item"><a href="#">M</a></div>
                                    <div class="item"><a href="#">N</a></div>
                                    <div class="item"><a href="#">O</a></div>
                                    <div class="item"><a href="#">P</a></div>
                                    <div class="item"><a href="#">Q</a></div>
                                    <div class="item"><a href="#">R</a></div>
                                    <div class="item"><a href="#">S</a></div>
                                    <div class="item"><a href="#">T</a></div>
                                    <div class="item"><a href="#">U</a></div>
                                    <div class="item"><a href="#">V</a></div>
                                    <div class="item"><a href="#">W</a></div>
                                    <div class="item"><a href="#">X</a></div>
                                    <div class="item"><a href="#">Y</a></div>
                                    <div class="item"><a href="#">Z</a></div>
                                </div>
                                <div class="clearfix"></div>
                            </div>
                        </div>
                    </div>
                    <div class="manga_list-sbs">
                        <div class="mls-wrap">
                            <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $azlist): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="item item-spc">
                                <a class="manga-poster" href="<?php echo e(route('detail', $azlist['slug'])); ?>">
                                    <img src="<?php echo e(str_replace('https://', 'https://i2.wp.com/', $azlist['poster'])); ?>"
                                        class="manga-poster-img lazyload" alt="<?php echo e($azlist['title']); ?>">
                                </a>
                                <div class="manga-detail">
                                    <h3 class="manga-name">
                                        <a href="<?php echo e(route('detail', $azlist['slug'])); ?>"
                                            title="<?php echo e($azlist['title']); ?>"><?php echo e($azlist['title']); ?></a>
                                    </h3>
                                    <div class="fd-infor">
                                        <?php $data = json_decode($azlist['genre']) ?>
                                        <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $genre): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <a href="#"><?php echo e($genre->genre); ?></a>,
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </div>
                                    <div class="fd-infor">
                                        <span class="fdi-item fdi-cate">
                                            <strong>
                                                <style>
                                                    .ratings {
                                                        position: relative;
                                                        vertical-align: middle;
                                                        display: inline-block;
                                                        color: #b1b1b1;
                                                        overflow: hidden;
                                                    }

                                                    .full-stars {
                                                        position: absolute;
                                                        left: 0;
                                                        top: 0;
                                                        white-space: nowrap;
                                                        overflow: hidden;
                                                        color: #ffc700;
                                                    }

                                                    .empty-stars:before,
                                                    .full-stars:before {
                                                        content: "\2605\2605\2605\2605\2605";
                                                        font-size: 12pt;
                                                    }

                                                    .empty-stars:before {
                                                        -webkit-text-stroke: 1px #848484;
                                                    }

                                                    .full-stars:before {
                                                        -webkit-text-stroke: 1px #ffc700;
                                                    }

                                                    /* Webkit-text-stroke is not supported on firefox or IE */
                                                    /* Firefox */
                                                    @-moz-document url-prefix() {
                                                        .full-stars {
                                                            color: #ECBE24;
                                                        }
                                                    }
                                                </style>
                                                <div class="ratings">
                                                    <div class="empty-stars"></div>
                                                    <div class="full-stars" style="width:10%">
                                                    </div>
                                                </div>
                                            </strong>
                                            <span class="text-white ml-1">10</span>
                                        </span>
                                        <div class="clearfix"></div>
                                    </div>

                                    <div class="fd-list">

                                    </div>

                                </div>
                                <div class="clearfix"></div>
                            </div>
                            <?php
                            $list_count = $key++
                            ?>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <div class="clearfix"></div>
                        </div>
                        <div class="pre-pagination mt-4">

                        </div>
                    </div>
                </section>
                <!--End: Section Manga list-->
                <div class="clearfix"></div>
            </div>
            <!--/End: main-content-->
            <!--Begin: main-sidebar-->
            <?php echo $__env->make('includes.main_sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <!--/End: main-sidebar-->
            <div class="clearfix"></div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\manga-scraper\resources\views/az_list.blade.php ENDPATH**/ ?>