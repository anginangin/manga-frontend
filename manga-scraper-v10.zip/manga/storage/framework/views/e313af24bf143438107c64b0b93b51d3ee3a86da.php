<!-- SUB HEADER -->
<div id="sub-header" class="home-sub-header">
    <div class="container">
        <div class="sh-left">
            <div class="float-left">
                <!-- <a href="https://mangareader.to/random" class="sh-item">
                <i class="fas fa-glasses mr-2"></i>Read Random
              </a>
              <div class="spacing"></div>
              <a href="https://zoro.to" target="_blank" class="sh-item">
                <i class="fas fa-play-circle mr-2"></i>Anime Online
              </a> -->
            </div>
            <div class="clearfix"></div>
        </div>
        <div class="sh-right">
            <div class="float-left">
                <!-- <div class="sh-item mr-3">
                <strong>Follow us :</strong>
              </div>
              <a
                target="_blank"
                href="https://www.reddit.com/r/MangaReaderOfficial"
                class="sh-item mr-3"
              >
                <i class="fab fa-reddit-alien mr-2"></i>Reddit
              </a>
              <a
                target="_blank"
                href="https://twitter.com/WeMangaReader"
                class="sh-item mr-3"
              >
                <i class="fab fa-twitter mr-2"></i>Twitter
              </a>
              <a
                target="_blank"
                href="https://discord.gg/Bvc5mVcUqE"
                class="sh-item"
              >
                <i class="fab fa-discord mr-2"></i>Discord
              </a>
              <div class="clearfix"></div> -->
            </div>
            <div class="spacing"></div>
            <div class="float-right">
                <a class="sh-item sb-uimode" id="toggle-mode">
                    <i class="fas fa-moon mr-2"></i><span class="text-dm">Dark Mode</span><span class="text-lm">Light
                        Mode</span>
                </a>
                <div class="clearfix"></div>
            </div>
            <div class="clearfix"></div>
        </div>
        <div class="clearfix"></div>
    </div>
</div>
<!-- SUB HEADER -->

<!-- MAIN HEADER -->
<div id="header" class="home-header">
    <div class="container">
        <div id="mobile_menu"><i class="fa fa-bars"></i></div>
        <div id="mobile_search"><i class="fa fa-search"></i></div>
        <a href="<?php echo e(route('homepage')); ?>" id="logo">
            <img src="http://mareceh.com/wp-content/uploads/2022/03/Ma_receh.png" alt="logo" />
            <div class="clearfix"></div>
        </a>
        <div id="header_menu">
            <ul class="nav header_menu-list">
                <li class="nav-item">
                    <a href="https://mangareader.to/completed" title="Completed">Completed</a>
                </li>
                <li class="nav-item">
                    <a href="javascript:;" title="Types">Types<i class="fas fa-angle-down ml-2"></i></a>
                    <div class="header_menu-sub" style="display: none">
                        <ul class="sub-menu">
                            <li>
                                <a href="https://mangareader.to/type/manga">Manga</a>
                            </li>

                            <li>
                                <a href="https://mangareader.to/type/one-shot">One-shot</a>
                            </li>

                            <li>
                                <a href="https://mangareader.to/type/doujinshi">Doujinshi</a>
                            </li>

                            <li>
                                <a href="https://mangareader.to/type/light-novel">Light Novel</a>
                            </li>

                            <li>
                                <a href="https://mangareader.to/type/manhwa">Manhwa</a>
                            </li>

                            <li>
                                <a href="https://mangareader.to/type/manhua">Manhua</a>
                            </li>

                            <li>
                                <a href="https://mangareader.to/type/comic">Comic</a>
                            </li>
                        </ul>
                        <div class="clearfix"></div>
                    </div>
                </li>
                <li class="nav-item">
                    <a href="https://mangareader.to/az-list" title="A-Z List">A-Z List</a>
                </li>
                <li class="nav-item">
                    <a href="#" target="_blank" title="News">News</a>
                </li>
            </ul>
            <div class="clearfix"></div>
        </div>
        <div id="header_right">
            <div id="search">
                <div class="search-content">
                    <form action="/search" autocomplete="off">
                        <a href="https://mangareader.to/filter" class="filter-icon">FILTER</a>
                        <input type="text" name="keyword" class="form-control search-input"
                            placeholder="Search manga..." />
                        <button type="submit" class="search-icon">
                            <i class="fas fa-search"></i>
                        </button>
                    </form>
                    <div class="nav search-result-pop" id="search-suggest">
                        <div class="loading-relative" id="search-loading" style="min-height: 60px; display: none">
                            <div class="loading">
                                <div class="span1"></div>
                                <div class="span2"></div>
                                <div class="span3"></div>
                            </div>
                        </div>
                        <div class="result" style="display: none"></div>
                    </div>
                </div>
            </div>

            <div id="login-state" style="float: left"></div>
            <div class="clearfix"></div>
        </div>
        <div class="clearfix"></div>
    </div>
</div>
<!-- MAIN HEADER --><?php /**PATH C:\laragon\www\laravel-scraper\resources\views/includes/navbar.blade.php ENDPATH**/ ?>