<!DOCTYPE html>
<html lang="en">
<head>
    <?php $web = App\Models\Web::first() ?>
    <title>Read <?php echo e(str_replace("/","",str_replace("-"," ",ucwords($chapter['path'])))); ?></title>
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
    <meta name="robots" content="index,follow" />
    <meta http-equiv="content-language" content="en" />
    <meta name="viewport" content="width=device-width, initial-scale=1, minimum-scale=1, maximum-scale=2" />
    <meta name="p:domain_verify" content="af0275499319c533df212167fc646dfb" />
    <link rel="shortcut icon" href="/<?php echo e($web['icon']); ?>" />
    <link rel="apple-touch-icon" sizes="180x180" href="/<?php echo e($web['icon']); ?>">
    <link rel="manifest" href="https://mangareader.to/manifest.json">
    <link rel="mask-icon" href="https://mangareader.to/images/safari-pinned-tab.svg" color="#5f25a6">
    <meta name="msapplication-TileColor" content="#5f25a6">
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.3.1/css/all.css">
    <link rel="stylesheet" href="https://mangareader.to/css/styles.min.css?v=1.7">
</head>

<body class="page-reader">
    <script>
        var uiMode = localStorage.getItem('uiMode');
        const body = document.body, btnMode = document.getElementById('toggle-mode'),
        sbBtnMode = document.getElementById('sb-toggle-mode');

        function activeUiMode() {
            if (uiMode === 'dark') {
                btnMode && btnMode.classList.add('active');
                sbBtnMode && sbBtnMode.classList.add('active');
                body.classList.add("darkmode");
            } else {
                btnMode && btnMode.classList.remove('active');
                sbBtnMode && sbBtnMode.classList.remove('active');
                body.classList.remove("darkmode");
            }
        }

        if (uiMode) {
            activeUiMode();
        } else {
            window.matchMedia('(prefers-color-scheme: dark)').matches ? uiMode = 'dark' : uiMode = 'light';
            activeUiMode();
        }
        [btnMode, sbBtnMode].forEach(item => {
            if (item) {
                item.addEventListener('click', function () {
                    this.classList.contains('active') ? uiMode = 'light' : uiMode = 'dark';
                    localStorage.setItem('uiMode', uiMode);
                    activeUiMode();
                });
            }
        })
    </script>
    <style>
        .headpost,
        #content.readercontent .bixbox,
        #content.readercontent .chdesc,
        .chnav,
        .kln,
        .scrollToTop,
        .chaptertags,
        #footer,
        .center,
        #histats_counter,
        #close-teaser,
        .socialts,
        #readerarea-loading,
        .th,
        .readingnav.rnavbot {
            display: none !important;
        }

        img.curdown {
            cursor: default !important;
        }

        #content {
            overflow: hidden;
            max-width: 1220px;
            margin: 0 auto;
            margin-top: 0 !important;
            position: relative;
            padding-bottom: 0 !important;
        }
    </style>
    <div id="wrapper" data-reading-id="545600" data-reading-by="chap" data-lang-code="en" data-manga-id="56074">
        <div id="header" class="header-reader">
            <div class="container">
                <div class="auto-div">
                    <a href="/" id="logo" class="mr-0">
                        <img src="/assets/img/logo-manga.svg" alt="logo">
                        <div class="clearfix"></div>
                    </a>
                    <div class="hr-line"></div>
                    <a href="#" class="hr-manga">
                        <h2 class="manga-name">
                            <?php echo e($chapter->manga['title']); ?>

                        </h2>
                    </a>
                    <div class="hr-navigation">
                        <div id="reading-list" style="display: initial">
                            <div class="rt-item rt-chap" id="dropdown-chapters">
                                <button type="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false" class="btn">
                                    <span id="current-chapter">
                                        Chapter <?php echo e($chapter['chapter']); ?>

                                    </span>
                                    <i class="fas fa-angle-down ml-2"></i>
                                </button>
                                <div class="dropdown-menu dropdown-menu-model dropdown-menu-fixed" aria-labelledby="ssc-list" x-placement="bottom-start" style="position: absolute; will-change: transform; top: 0px; left: 0px; transform: translate3d(15px, 317px, 0px);">
                                    <div class="chapter-list-read">
                                        <div class="chapter-section">
                                            <div class="chapter-s-search">
                                                <form class="preform search-reading-item-form">
                                                    <div class="css-icon">
                                                        <i class="fas fa-search"></i>
                                                    </div>
                                                    <input class="form-control search-reading-item w-100" type="text" placeholder="Number of Chapter" autofocus="autofocus" autocomplete="off" id="search">
                                                </form>
                                            </div>
                                            <div class="clearfix"></div>
                                        </div>
                                        <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
                                        <script>
                                            $("#search").on("keyup", function() {
                                            var value = $(this).val().toLowerCase().trim();
                                            var v = value.split("%");
                                            $(".ulclear li").each(function(j,k) {
                                            var s = true;
                                            $.each(v, function(i, x) {
                                            if (s) {
                                            s = $(k).text().toLowerCase().indexOf(x) > -1;
                                            }
                                            });
                                            $(this).toggle(s);
                                            });
                                            });
                                        </script>
                                        <div class="chapters-list-ul" style="z-index: 5">
                                            <ul class="ulclear reading-list lang-chapters active" style="">
                                                <?php $__currentLoopData = $chapters; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <?php $__currentLoopData = $item['chapters']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <li class="item chapter-item">
                                                    <a href="/read<?php echo e($value->path); ?>" class="item-link">
                                                        <span class="arrow mr-2">
                                                            <i class="fas fa-caret-right"></i>
                                                        </span>
                                                        <span class="name">Chapter <?php echo e($value->chapter); ?></span>
                                                    </a>
                                                    <div class="clearfix"></div>
                                                </li>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </ul>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="rt-item rt-navi d-block">
                            <?php if(isset($prevSlug)): ?>
                            <a href="/read<?php echo e($prevSlug['path']); ?>" class="btn btn-navi">
                                <i class="fas fa-arrow-left mr-2"></i>
                            </a>
                            <?php endif; ?>
                        </div>
                        <div class="rt-item rt-navi right d-block">
                            <?php if(isset($nextSlug)): ?>
                            <a href="/read<?php echo e($nextSlug['path']); ?>" class="btn btn-navi">
                                <i class="fas fa-arrow-right ml-2"></i>
                            </a>
                            <?php endif; ?>
                        </div>
                        <div class="clearfix"></div>
                    </div>
                    <div class="float-right hr-right">
                        <div class="hr-comment mr-2">
                            <a href="javascript:;" class="btn btn-sm hrr-btn">
                                <?php $komen = DB::table('comments')->where('commentable_id', $chapter['manga']['id'])->get() ?>
                                <i class="far fa-comment-alt"></i>
                                <span class="number"><?php echo e(count($komen)); ?></span>
                                <span class="hrr-name">Komentar</span>
                            </a>
                            <div class="clearfix"></div>
                        </div>
                        <div class="hr-info mr-2">
                            <a href="/manga/<?php echo e($chapter->manga['slug']); ?>" class="btn btn-sm hrr-btn"><i
                                    class="fas fa-info"></i><span class="hrr-name">Manga
                                    Detail</span></a>
                            <div class="clearfix"></div>
                        </div>
                        <div class="hr-fav" id="reading-list-info"></div>
                    </div>
                    <div class="clearfix"></div>
                </div>
                <div class="ad-toggle"><i class="fas fa-expand-arrows-alt"></i></div>
            </div>
        </div>
        <div class="clearfix"></div>
        <div id="images-content">
            <div class="text-center">
                <div class="container">
                    
                    <?php if($chapter['domain'] == config('constant.url.komiktap')): ?>
                    <?php $__currentLoopData = $image; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $image): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php if(strpos($image, '.jpg') == TRUE || strpos($image, '.png') == TRUE || strpos($image, '.jpeg') ==
                    TRUE || strpos($image, '.webp') == TRUE): ?> {
                    <img class="img-fluid" src="<?php echo e($image); ?>" />
                    <?php endif; ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php else: ?>
                    <?php $__currentLoopData = $image['image']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $image): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <img class="img-fluid" src="<?php echo e($image); ?>" />
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php endif; ?>
                </div>
            </div>
        </div>
        <div class="clearfix"></div>
        <div class="mr-tools mrt-bottom my-5">
            <div class="container">
                <div class="read_tool">
                    <div class="float-left" id="ver-prev-cv">
                        <div class="rt-item">
                            <?php if(isset($prevSlug)): ?>
                            <a href="/read<?php echo e($prevSlug['path']); ?>" class="btn btn-navi">
                                <i class="fas fa-arrow-left mr-2"></i>Prev Chapter
                            </a>
                            <?php endif; ?>
                        </div>
                        <div class="clearfix"></div>
                    </div>
                    <div class="float-right" id="ver-next-cv">
                        <div class="rt-item">
                            <?php if(isset($nextSlug)): ?>
                            <a href="/read<?php echo e($nextSlug['path']); ?>" class="btn btn-navi">
                                Next Chapter<i class="fas fa-arrow-right ml-2"></i>
                            </a>
                            <?php endif; ?>
                        </div>
                    </div>
                    <div class="clearfix"></div>
                </div>
            </div>
        </div>
        <div id="read-comment">
            <div class="rc-close"><span aria-hidden="true">×</span></div>
            <div class="comments-wrap">
                <div class="sc-header">
                    <?php $komen = DB::table('comments')->where('commentable_id', $chapter['manga']['id'])->get() ?>
                    <div class="sc-h-title"><?php echo e(count($komen)); ?> Komentar</div>
                    
                    <div class="clearfix"></div>
                </div>
                <div id="content-comments">
                    <br>
                    <?php echo $__env->make('comments::components.comments', ['model' => $chapter['manga']], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                    
                </div>
            </div>
        </div>
    </div>
    <script>
        var recaptchaV3SiteKey = '6LfQbGQcAAAAAL1I4ef6T7XEuPi19tYPVtaotny9',
            recaptchaV2SiteKey = '6LfVbmQcAAAAAP8gL4mAxtJG0gU0bhuuDwgyBnnJ';
    </script>
    <script src="https://www.google.com/recaptcha/api.js?render=6LfQbGQcAAAAAL1I4ef6T7XEuPi19tYPVtaotny9&hl=en"></script>

    <!-- Go to www.addthis.com/dashboard to customize your tools -->
    <script type="text/javascript"
        src="https://mangareader.to//s7.addthis.com/js/300/addthis_widget.js#pubid=ra-61310d692ddb96c6" defer async>
    </script>
    <script type="text/javascript" src="https://mangareader.to/js/app.min.js?v=2.1"></script>
    <script>
        if ('serviceWorker' in navigator) {
        window.addEventListener('load', function () {
            navigator.serviceWorker.register('/sw.js');
        });
    }
    </script>
    <script src="https://mangareader.to/js/read.min.js?v=4.6" async defer></script>
</body>

</html><?php /**PATH C:\laragon\www\manga-scraper\resources\views/read.blade.php ENDPATH**/ ?>