
<?php $__env->startSection('content'); ?>
<div id="ani_detail">
    <div class="ani_detail-stage">
        <div class="container">
            <div class="detail-breadcrumb">
                <nav aria-label="breadcrumb">
                    <ol class="breadcrumb">
                        <li class="breadcrumb-item">
                            <a href="/">Home</a>
                        </li>
                        <li class="breadcrumb-item active">
                            <?php echo e($detail['title']); ?>

                        </li>
                    </ol>
                </nav>
            </div>
            <div class="anis-content">
                <div class="anisc-poster">
                    <div class="manga-poster">
                        <img 
                            src="<?php echo e((!$detail['thumbnail'])
                                ? $detail['poster']
                                : config('constant.url.api_image').$detail['thumbnail']); ?>"
                            class="manga-poster-img" 
                            alt="<?php echo e($detail['title']); ?>

                        ">
                    </div>
                </div>
                <div class="anisc-detail">
                    <h2 class="manga-name mb-2">
                        <?php echo e($detail['title']); ?>

                    </h2>
                    <div id="mal-sync"></div>
                    <div class="manga-buttons">
                        <i class="fas fa-star text-warning mr-2"></i>
                        <strong>
                            <?php echo e($rating); ?>

                        </strong>
                        <small class="text-muted ml-2">
                            (<?php echo e(App\Models\Rating::where('manga_id', $detail['id'])->count()); ?> vote)
                        </small>
                        <?php if(auth()->guard()->check()): ?>
                        <div id="reading-list-info" class="dr-fav ml-3">
                            <?php if(App\Models\Bookmark::where(['manga_id' => $detail['id'], 'user_id' => auth()->user()->id])->exists()): ?>     
                            <form>
                                <?php echo csrf_field(); ?>
                                <input type="hidden" id="manga_id" name="manga_id" value="<?php echo e($detail['id']); ?>">
                                <input type="hidden" id="user_id" name="user_id" value="<?php echo e(auth()->user()->id); ?>">
                                <button type="button" class="btn btn-primary btn-sm" style="line-height: 30px" id="unbookmark">
                                    <i class="fas fa-bookmark"></i>
                                    Bookmarked
                                </button>
                            </form>
                            <?php else: ?>
                            <form>
                                <?php echo csrf_field(); ?>
                                <input type="hidden" id="manga_id" name="manga_id" value="<?php echo e($detail['id']); ?>">
                                <input type="hidden" id="user_id" name="user_id" value="<?php echo e(auth()->user()->id); ?>">
                                <button type="submit" class="btn btn-primary btn-sm" style="line-height: 30px" id="bookmark">
                                    <i class="far fa-bookmark"></i>
                                    Bookmark
                                </button>
                            </form>
                            <?php endif; ?>
                            <div class="clearfix"></div>
                        </div>
                        <?php endif; ?>
                    </div>
                    <div class="sort-desc">
                        <div class="genres">
                            <?php $genres = json_decode($detail['genre']) ?>
                            <?php $__currentLoopData = $genres; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $genre): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <a href="/genre/<?php echo e($genre->genre); ?>">
                                <?php echo e($genre->genre); ?>

                            </a>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
                        <div class="description">
                            <?php echo e($detail['description']); ?>

                        </div>

                        <div class="description-more">
                            <button type="button" data-toggle="modal" data-target="#modaldesc" class="btn btn-xs text-white">
                                + Read full
                            </button>
                            <div class="modal fade premodal" id="modaldesc" tabindex="-1" role="dialog" aria-labelledby="modalldesctitle" aria-hidden="true">
                                <div class="modal-dialog modal-dialog-centered" role="document">
                                    <div class="modal-content">
                                        <div class="modal-header">
                                            <h5 class="modal-title" id="modalldesctitle">
                                                <?php echo e($detail['title']); ?>

                                            </h5>
                                            <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                                <span aria-hidden="true">&times;</span>
                                            </button>
                                        </div>
                                        <div class="modal-body">
                                            <div class="description-modal">
                                                <?php echo e($detail['description']); ?>

                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <div class="anisc-info-wrap">
                            <div class="anisc-info">
                                <?php $tables = json_decode($detail['information']) ?>
                                <?php $__currentLoopData = $tables; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $table): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <div class="item item-title">
                                    <span>
                                        <?php if($detail->chapters[0]->domain == config('constant.url.komikstation')): ?>
                                        <?php echo e(($table->value != 'Posted By') ? $table->value : ''); ?>

                                        <?php else: ?>
                                        <?php if($table->key != 'Posted By'): ?>
                                        <?php echo e($table->key); ?>: <?php echo e($table->value); ?>

                                        <?php endif; ?>
                                        <?php endif; ?>
                                    </span>
                                </div>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <div class="detail-toggle">
                                    <button type="button" class="btn btn-sm btn-light">
                                        <i class="fas fa-angle-down mr-2"></i>
                                    </button>
                                </div>
                                <div class="dt-rate" id="vote-info">
                                    <div class="block-rating ">
                                        <div class="description pt-3">
                                            Berikan penilaian tentang manga ini.
                                        </div>
                                        <?php if(Auth::check()): ?>
                                            <?php $rate = \App\Models\Rating::where('manga_id', $detail['id'])->where('user_id',auth()->user()->id)->first() ?>
                                            <?php if($rate): ?>
                                                <div class="description">
                                                    <?php if($rate['rating'] == 5): ?>
                                                    <div class="form-group" id="rating-ability-wrapper">
                                                        <span class="btnrating btn btn-default btn-sm p-0 mr-2" style="cursor: default">
                                                            <i class="fa fa-star text-warning" aria-hidden="true"></i>
                                                        </span>
                                                        <span class="btnrating btn btn-default btn-sm p-0 mr-2" style="cursor: default">
                                                            <i class="fa fa-star text-warning" aria-hidden="true"></i>
                                                        </span>
                                                        <span class="btnrating btn btn-default btn-sm p-0 mr-2" style="cursor: default">
                                                            <i class="fa fa-star text-warning" aria-hidden="true"></i>
                                                        </span>
                                                        <span class="btnrating btn btn-default btn-sm p-0 mr-2" style="cursor: default">
                                                            <i class="fa fa-star text-warning" aria-hidden="true"></i>
                                                        </span>
                                                        <span class="btnrating btn btn-default btn-sm p-0" style="cursor: default">
                                                            <i class="fa fa-star text-warning" aria-hidden="true"></i>
                                                        </span>
                                                    </div>
                                                    <?php elseif($rate['rating'] == 4): ?>
                                                    <div class="form-group" id="rating-ability-wrapper">
                                                        <span class="btnrating btn btn-default btn-sm p-0 mr-2" style="cursor: default">
                                                            <i class="fa fa-star text-warning" aria-hidden="true"></i>
                                                        </span>
                                                        <span class="btnrating btn btn-default btn-sm p-0 mr-2" style="cursor: default">
                                                            <i class="fa fa-star text-warning" aria-hidden="true"></i>
                                                        </span>
                                                        <span class="btnrating btn btn-default btn-sm p-0 mr-2" style="cursor: default">
                                                            <i class="fa fa-star text-warning" aria-hidden="true"></i>
                                                        </span>
                                                        <span class="btnrating btn btn-default btn-sm p-0 mr-2" style="cursor: default">
                                                            <i class="fa fa-star text-warning" aria-hidden="true"></i>
                                                        </span>
                                                        <span class="btnrating btn btn-default btn-sm p-0" style="cursor: default">
                                                            <i class="fa fa-star" aria-hidden="true"></i>
                                                        </span>
                                                    </div>
                                                    <?php elseif($rate['rating'] == 3): ?>
                                                    <div class="form-group" id="rating-ability-wrapper">
                                                        <span class="btnrating btn btn-default btn-sm p-0 mr-2" style="cursor: default">
                                                            <i class="fa fa-star text-warning" aria-hidden="true"></i>
                                                        </span>
                                                        <span class="btnrating btn btn-default btn-sm p-0 mr-2" style="cursor: default">
                                                            <i class="fa fa-star text-warning" aria-hidden="true"></i>
                                                        </span>
                                                        <span class="btnrating btn btn-default btn-sm p-0 mr-2" style="cursor: default">
                                                            <i class="fa fa-star text-warning" aria-hidden="true"></i>
                                                        </span>
                                                        <span class="btnrating btn btn-default btn-sm p-0 mr-2" style="cursor: default">
                                                            <i class="fa fa-star" aria-hidden="true"></i>
                                                        </span>
                                                        <span class="btnrating btn btn-default btn-sm p-0" style="cursor: default">
                                                            <i class="fa fa-star" aria-hidden="true"></i>
                                                        </span>
                                                    </div>
                                                    <?php elseif($rate['rating'] == 2): ?>
                                                    <div class="form-group" id="rating-ability-wrapper">
                                                        <span class="btnrating btn btn-default btn-sm p-0 mr-2" style="cursor: default">
                                                            <i class="fa fa-star text-warning" aria-hidden="true"></i>
                                                        </span>
                                                        <span class="btnrating btn btn-default btn-sm p-0 mr-2" style="cursor: default">
                                                            <i class="fa fa-star text-warning" aria-hidden="true"></i>
                                                        </span>
                                                        <span class="btnrating btn btn-default btn-sm p-0 mr-2" style="cursor: default">
                                                            <i class="fa fa-star" aria-hidden="true"></i>
                                                        </span>
                                                        <span class="btnrating btn btn-default btn-sm p-0 mr-2" style="cursor: default">
                                                            <i class="fa fa-star" aria-hidden="true"></i>
                                                        </span>
                                                        <span class="btnrating btn btn-default btn-sm p-0" style="cursor: default">
                                                            <i class="fa fa-star" aria-hidden="true"></i>
                                                        </span>
                                                    </div>
                                                    <?php else: ?>
                                                    <div class="form-group" id="rating-ability-wrapper">          
                                                        <span class="btnrating btn btn-default btn-sm p-0 mr-2" style="cursor: default">
                                                            <i class="fa fa-star text-warning" aria-hidden="true"></i>
                                                        </span>
                                                        <span class="btnrating btn btn-default btn-sm p-0 mr-2" style="cursor: default">
                                                            <i class="fa fa-star" aria-hidden="true"></i>
                                                        </span>
                                                        <span class="btnrating btn btn-default btn-sm p-0 mr-2" style="cursor: default">
                                                            <i class="fa fa-star" aria-hidden="true"></i>
                                                        </span>
                                                        <span class="btnrating btn btn-default btn-sm p-0 mr-2" style="cursor: default">
                                                            <i class="fa fa-star" aria-hidden="true"></i>
                                                        </span>
                                                        <span class="btnrating btn btn-default btn-sm p-0" style="cursor: default">
                                                            <i class="fa fa-star" aria-hidden="true"></i>
                                                        </span>
                                                    </div>
                                                <?php endif; ?>
                                            <?php else: ?>    
                                                    <form>
                                                        <div class="form-group" id="rating-ability-wrapper">
                                                            <input type="hidden" id="manga_id" name="manga_id" value="<?php echo e($detail['id']); ?>">
                                                            <input type="hidden" id="user_id" name="user_id" value="<?php echo e(auth()->user()->id); ?>">
                                                            <input type="hidden" id="selected_rating" name="selected_rating" value="" required="required">
                                                            <button type="button" class="btnrating btn btn-default btn-sm p-0 mr-2" data-attr="1" id="rating-star-1">
                                                                <i class="fa fa-star" aria-hidden="true"></i>
                                                            </button>
                                                            <button type="button" class="btnrating btn btn-default btn-sm p-0 mr-2" data-attr="2" id="rating-star-2">
                                                                <i class="fa fa-star" aria-hidden="true"></i>
                                                            </button>
                                                            <button type="button" class="btnrating btn btn-default btn-sm p-0 mr-2" data-attr="3" id="rating-star-3">
                                                                <i class="fa fa-star" aria-hidden="true"></i>
                                                            </button>
                                                            <button type="button" class="btnrating btn btn-default btn-sm p-0 mr-2" data-attr="4" id="rating-star-4">
                                                                <i class="fa fa-star" aria-hidden="true"></i>
                                                            </button>
                                                            <button type="button" class="btnrating btn btn-default btn-sm p-0" data-attr="5" id="rating-star-5">
                                                                <i class="fa fa-star" aria-hidden="true"></i>
                                                            </button>
                                                        </div>
                                                    </form>
                                                </div>
                                            <?php endif; ?>    
                                        <?php else: ?>
                                        <div class="form-group" id="rating-ability-wrapper">
                                            <a href="<?php echo e(route('sign-in')); ?>" class="btnrating btn btn-default btn-sm" data-attr="1" id="rating-star-1" disabled>
                                                <i class="fa fa-star" aria-hidden="true"></i>
                                            </a>
                                            <a href="<?php echo e(route('sign-in')); ?>" class="btnrating btn btn-default btn-sm" data-attr="2" id="rating-star-2" disabled>
                                                <i class="fa fa-star" aria-hidden="true"></i>
                                            </a>
                                            <a href="<?php echo e(route('sign-in')); ?>" class="btnrating btn btn-default btn-sm" data-attr="3" id="rating-star-3" disabled>
                                                <i class="fa fa-star" aria-hidden="true"></i>
                                            </a>
                                            <a href="<?php echo e(route('sign-in')); ?>" class="btnrating btn btn-default btn-sm" data-attr="4" id="rating-star-4" disabled>
                                                <i class="fa fa-star" aria-hidden="true"></i>
                                            </a>
                                            <a href="<?php echo e(route('sign-in')); ?>" class="btnrating btn btn-default btn-sm" data-attr="5" id="rating-star-5" disabled>
                                                <i class="fa fa-star" aria-hidden="true"></i>
                                            </a>
                                        </div>
                                        <?php endif; ?>
                                            <div class="clearfix"></div>
                                        <div class="clearfix"></div>
                                    </div>
                                </div>
                            </div>
                            <div class="clearfix"></div>
                        </div>
                    </div>
                </div>
                <div class="clearfix"></div>
            </div>
        </div>
    </div>
</div>
<div id="main-wrapper" class="page-layout page-detail">
    <div class="container">
        <div id="mw-2col">
            <div id="main-content">
                <section id="chapters-list" class="block_area block_area_category block_area_chapters">
                    <div class="block_area-header mb-0">
                        <div class="bah-heading bah-heading-tabs">
                            <ul class="nav nav-tabs chap-tabs">
                                <li class="nav-item">
                                    <a data-toggle="tab" href="#list-chapter" class="nav-link active show">
                                        List Chapter
                                    </a>
                                </li>
                            </ul>
                        </div>
                        <div class="clearfix"></div>
                    </div>
                    <div class="tab-content">
                        <div id="list-chapter" class="tab-pane active show">
                            <div class="chapter-section">
                                <div class="chapter-s-search">
                                    <form class="preform search-reading-item-form">
                                        <div class="css-icon">
                                            <i class="fas fa-search"></i>
                                        </div>
                                        <input class="form-control search-reading-item w-100" id="searchDetail" type="text" placeholder="Cari Chapter..." autofocus>
                                    </form>
                                </div>
                                <div class="clearfix"></div>
                            </div>
                            <script>
                                $("#searchDetail").on("keyup", function() {
                                    var value = $(this).val().toLowerCase().trim();
                                    var v = value.split("%");
                                    $(".lang-chapters li").each(function(j,k) {
                                        var s = true;
                                        $.each(v, function(i, x) {
                                            if (s) { s = $(k).text().toLowerCase().indexOf(x) > -1; }
                                        });
                                        $(this).toggle(s);
                                        console.log(s)
                                    });
                                });
                            </script>
                            <div class="chapters-list-ul">
                                <ul class="ulclear reading-list lang-chapters" id="en-chapters">
                                    <?php $__currentLoopData = $detail->chapters->sortByDesc('chapter'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $chapter): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <li class="item reading-item chapter-item" data-number="<?php echo e($chapter->chapter); ?>">
                                        <a href="/read<?php echo e($chapter->path); ?>" class="item-link">
                                            <span class="arrow mr-2">
                                                <i class="far fa-file-alt"></i>
                                            </span>
                                            <span class="name">
                                                Chapter <?php echo e($chapter->chapter); ?>

                                            </span>
                                            <span class="item-read">
                                                <i class="fas fa-glasses mr-1"></i>
                                                Read
                                            </span>
                                        </a>
                                        <div class="clearfix"></div>
                                    </li>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </ul>
                            </div>
                            <div class="clearfix"></div>
                        </div>
                    </div>
                </section>

                <section class="block_area block_area_category block_area_authors-other">
                    <div class="block_area-header">
                        <div class="bah-heading">
                            <h2 class="cat-heading">
                                Related Series
                            </h2>
                        </div>
                        <div class="clearfix"></div>
                    </div>
                    <div class="manga_list-sbs">
                        <div class="mls-wrap">
                            <?php $__currentLoopData = $related; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $manga): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="item item-spc">
                                <a class="manga-poster" href="<?php echo e(route('detail', $manga['slug'])); ?>">
                                    <img 
                                        src="<?php echo e((!$manga['thumbnail'])
                                            ? $manga['poster']
                                            : config('constant.url.api_image').$manga['thumbnail']); ?>"
                                        class="manga-poster-img lazyload" 
                                        alt="<?php echo e($manga['title']); ?>" 
                                    />
                                </a>
                                <div class="manga-detail">
                                    <h3 class="manga-name">
                                        <a href="<?php echo e(route('detail', $manga['slug'])); ?>" title="<?php echo e($manga['title']); ?>">
                                            <?php echo e($manga['title']); ?>

                                        </a>
                                    </h3>
                                    <div class="fd-infor">
                                        <span class="fdi-item fdi-cate">
                                            <?php $genres = json_decode($manga['genre']) ?>
                                            <?php $__currentLoopData = $genres; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $genre): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <a href="/genre/<?php echo e($genre->genre); ?>">
                                                <?php echo e($genre->genre); ?>

                                            </a>,
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </span>
                                        <div class="clearfix"></div>
                                    </div>
                                    <div class="fd-list">
                                        <?php $i = 0 ?>
                                        <?php $__currentLoopData = $manga['chapters']->sortByDesc('chapter'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $k => $chapter): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <div class="fdl-item">
                                            <div class="chapter">
                                                <a href="/read<?php echo e($chapter['path']); ?>" class="d-inline">
                                                    <i class="far fa-file-alt mr-2"></i>
                                                    Chapter <?php echo e($chapter['chapter']); ?>

                                                </a>
                                            </div>
                                            <div class="release-time">
                                                <span class="text-muted"></span>
                                            </div>
                                            <div class="clearfix"></div>
                                        </div>
                                        <?php if(++$i == 3): ?>
                                        <?php break; ?>
                                        <?php endif; ?>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </div>
                                </div>
                                <div class="clearfix"></div>
                            </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <div class="clearfix"></div>
                        </div>
                        <div class="clearfix"></div>
                    </div>
                    <div class="card" style="background: #2F2F2F !important;color:fff">
                        <div class="card-header">
                            <?php $komen = DB::table('comments')->where('commentable_id', $detail['id'])->get() ?>
                            <h5><?php echo e(count($komen)); ?> Komentar</h5>
                        </div>
                        <div class="card-body">
                            <?php echo $__env->make('comments::components.comments', ['model' => $detail], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                        </div>
                    </div>
                </section>
                <div class="clearfix"></div>
            </div>
            <?php echo $__env->make('includes.main_sidebar', [
                'daily_views' => $daily_views,
                'weekly_views' => $weekly_views,
                'monthly_views' => $monthly_views
            ], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <div class="clearfix"></div>
        </div>
    </div>
</div>
<script>
    $(document).ready(function(){
        $('#unbookmark').click(function(e) {
            e.preventDefault();
        
            var manga_id = $('#manga_id').val();
            var user_id = $('#user_id').val();
            let token = $("meta[name='csrf-token']").attr("content");
        
            $.ajax({
                url: `/user/unbookmark`,
                type: "POST",
                cache: false,
                data: {
                    manga_id: manga_id,
                    user_id: user_id,
                    _token: token
                },
                success:function(response){
                    toastr.options = {
                    "closeButton" : true,
                    "progressBar" : true,
                    "positionClass": "toast-bottom-right",
                    }
                    toastr.success(`${response.message}`);
                    $('#reading-list-info').load(document.URL + ' #reading-list-info');
                },
            });
        });

        $('#bookmark').click(function(e) {
            e.preventDefault();
        
            var manga_id = $('#manga_id').val();
            var user_id = $('#user_id').val();
            let token = $("meta[name='csrf-token']").attr("content");
        
            $.ajax({
                url: `/user/bookmark`,
                type: "POST",
                cache: false,
                data: {
                    manga_id: manga_id,
                    user_id: user_id,
                    _token: token
                },
                success:function(response){
                    toastr.options = {
                        "closeButton" : true,
                        "progressBar" : true,
                        "positionClass": "toast-bottom-right",
                    }
                    toastr.success(`${response.message}`);
                    $('#reading-list-info').load(document.URL + ' #reading-list-info');
                },
            });
        });

        $(".btnrating").on('click',(function(e) {
            e.preventDefault();
            var previous_value = $("#selected_rating").val();
            var selected_value = $(this).attr("data-attr");
            var manga_id = $('#manga_id').val();
            var user_id = $('#user_id').val();
            let token = $("meta[name='csrf-token']").attr("content");

            $.ajax({
            url: `/rate`,
            type: "POST",
            cache: false,
            data: {
            manga_id: manga_id,
            rating: selected_value,
            user_id: user_id,
            _token: token
            },
            success:function(response){
            toastr.options = {
            "closeButton" : true,
            "progressBar" : true,
            "positionClass": "toast-bottom-right",
            }
            toastr.success(`${response.message}`);
            $('#vote-info').load(document.URL + ' #vote-info');
            },
            });

            $("#selected_rating").val(selected_value);
            $(".selected-rating").empty();
            $(".selected-rating").html(selected_value);
            for (i = 1; i <= selected_value; ++i) { 
                $("#rating-star-"+i).toggleClass('text-warning');
                $("#rating-star-"+i).toggleClass('btn-default'); 
            }
            for (ix=1; ix <=previous_value; ++ix) {
                $("#rating-star-"+ix).toggleClass('text-warning'); $("#rating-star-"+ix).toggleClass('btn-default'); 
            } 
        })); 
    });
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.web', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\manga-scraper\resources\views/detail.blade.php ENDPATH**/ ?>