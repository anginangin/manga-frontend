
<?php $__env->startSection('content'); ?>
<div id="main-wrapper">
    <div class="container">
        <div id="mw-2col">
            <div id="main-content">
                <section class="block_area block_area_profile">
                    <div class="block_area-header">
                        <div class="bah-heading">
                            <h2 class="cat-heading">
                                Profile Manager
                            </h2>
                        </div>
                        <div class="clearfix"></div>
                    </div>
                    <div class="block_area-content">
                        <form class="preform preform-center" method="post" action="<?php echo e(route('change_password')); ?>" enctype="multipart/form-data">
                            <?php echo method_field('PUT'); ?>
                            <?php echo csrf_field(); ?>
                            <?php if($errors->all()): ?>    
                            <div class="alert alert-danger">
                                <ul>
                                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <li><?php echo e($error); ?></li>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </ul>
                            </div>
                            <?php endif; ?>
                            <input type="hidden" name="user_id" id="user_id" value="<?php echo e(auth()->user()->id); ?>">
                            <div class="profile-avatar">
                                <?php if(auth()->user()->avatar): ?>
                                <img class="img-fluid img-preview" src="<?php echo e(asset('storage/'.auth()->user()->avatar)); ?>">
                                <?php else: ?>
                                <img class="img-fluid img-preview" src="https://ui-avatars.com/api/?name=<?php echo e(auth()->user()->name); ?>">
                                <?php endif; ?>
                                <label for="upload-photo" style="cursor: pointer">Ubah Avatar</label>
                                <input type="file" name="avatar" id="upload-photo" style="opacity: 0;position: absolute; z-index: -1" />
                            </div>
                            <div class="form-group">
                                <label class="prelabel" for="pro5-email">Email address</label>
                                <input type="email" class="form-control" disabled="" id="pro5-email" value="<?php echo e(auth()->user()->email); ?>">
                            </div>
                            <div class="form-group">
                                <label class="prelabel" for="pro5-name">Display name</label>
                                <input type="text" class="form-control" id="pro5-name" disabled="" name="name" value="<?php echo e(auth()->user()->name); ?>">
                            </div>
                            <div class="block">
                                <a class="btn btn-xs btn-blank" data-toggle="collapse" href="#show-changepass">
                                    <i class="fas fa-key mr-2"></i>
                                    Ubah Password
                                </a>
                            </div>
                            <div id="show-changepass" class="collapse mt-3">
                                <div class="form-group">
                                    <label class="prelabel" for="pro5-currentpass">Password Saat Ini</label>
                                    <input type="password" class="form-control" name="current_password">
                                </div>
                                <div class="form-group">
                                    <label class="prelabel" for="pro5-pass">Password Baru</label>
                                    <input type="password" class="form-control" name="new_password">
                                </div>
                                <div class="form-group">
                                    <label class="prelabel" for="pro5-confirm">Konfirmasi Password Baru</label>
                                    <input type="password" class="form-control" name="confirm_new_password">
                                </div>
                            </div>
                            <div class="form-group">
                                <div class="mt-4">&nbsp;</div>
                                <button class="btn btn-block btn-primary btn-sm">Submit</button>
                            </div>
                        </form>
                    </div>
                </section>
                <div class="clearfix"></div>
            </div>
            <div id="main-sidebar">
                <section class="block_area block_area_sidebar block_area-profile">
                    <div class="block_area-header">
                        <div class="float-left bah-heading">
                            <h2 class="cat-heading">Profile Menu</h2>
                        </div>
                        <div class="clearfix"></div>
                    </div>
                    <div class="block_area-content">
                        <div class="menu-profiles">
                            <ul class="ulclear">
                                <li class="active">
                                    <a href="/user/profile" class="mp-item">
                                        <i class="fas fa-user mr-3"></i>
                                        Profil
                                    </a>
                                </li>
                                <li class="">
                                    <a href="/user/reading-list" class="mp-item">
                                        <i class="fas fa-bookmark mr-3"></i>
                                        Bookmark
                                    </a>
                                </li>
                                <li class="">
                                    <a href="/user/notifications" class="mp-item">
                                        <i class="fas fa-bell mr-3"></i>
                                        Notifikasi
                                    </a>
                                </li>
                            </ul>
                        </div>
                    </div>
                </section>
            </div>
            <div class="clearfix"></div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php $__env->startPush('addon-script'); ?>
    <script>
        $(document).ready(function(){
            $('#upload-photo').on('change', function(e) {
                e.preventDefault();
            
                let token = $("meta[name='csrf-token']").attr("content");
                var avatar = $("#upload-photo").val();
                var user_id = $("#user_id").val();
                
                $.ajax({
                    url: `/user/change-avatar`,
                    type: "PUT",
                    cache: false,
                    data: {
                        user_id: user_id,
                        avatar: avatar,
                        _token: token
                    },
                    success: function(response){
                        const image = document.querySelector('#upload-photo');
                        const imagePreview = document.querySelector('.img-preview');
                        
                        const oFReader = new FileReader();
                        oFReader.readAsDataURL(image.files[0]);
                        oFReader.onload = function(oFREvent) {
                            imagePreview.src = oFREvent.target.result;
                        }
                    },
                    error: function(error){
                    
                    }
                });
            });
        });
    </script>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('layouts.web', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\manga-scraper\resources\views/pages/user/profile.blade.php ENDPATH**/ ?>