<?php
    if (isset($approved) and $approved == true) {
        $comments = $model->approvedComments;
    } else {
        $comments = $model->comments;
    }
?>

<?php if(auth()->guard()->check()): ?>
<?php echo $__env->make('comments::_form', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php elseif(Config::get('comments.guest_commenting') == true): ?>
<?php echo $__env->make('comments::_form', [
'guest_commenting' => true
], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php else: ?>
<p class="text-center">Anda harus <a href="<?php echo e(route('sign-in')); ?>" style="color:#c49bff!important">Login</a> untuk mengirim komentar.</p>
<hr>
<?php endif; ?>

<?php if($comments->count() < 1): ?>
    <div class="text-center"><h6>Belum ada komentar.</h6></div>
<?php endif; ?>

<?php if(isset($perPage)): ?>
    <?php echo e($grouped_comments->links()); ?>

<?php endif; ?>
<div>
    <?php
    $comments = $comments->sortByDesc('created_at');

    if (isset($perPage)) {
    $page = request()->query('page', 1) - 1;

    $parentComments = $comments->where('child_id', '');

    $slicedParentComments = $parentComments->slice($page * $perPage, $perPage);

    $m = Config::get('comments.model'); // This has to be done like this, otherwise it will complain.
    $modelKeyName = (new $m)->getKeyName(); // This defaults to 'id' if not changed.

    $slicedParentCommentsIds = $slicedParentComments->pluck($modelKeyName)->toArray();

    // Remove parent Comments from comments.
    $comments = $comments->where('child_id', '!=', '');

    $grouped_comments = new \Illuminate\Pagination\LengthAwarePaginator(
    $slicedParentComments->merge($comments)->groupBy('child_id'),
    $parentComments->count(),
    $perPage
    );

    $grouped_comments->withPath(request()->url());
    } else {
    $grouped_comments = $comments->groupBy('child_id');
    }
    ?>
    <?php $__currentLoopData = $grouped_comments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $comment_id => $comments): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    
    <?php if($comment_id == ''): ?>
    <?php $__currentLoopData = $comments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $comment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <?php echo $__env->make('comments::_comment', [
    'comment' => $comment,
    'grouped_comments' => $grouped_comments,
    'maxIndentationLevel' => $maxIndentationLevel ?? 3
    ], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    <?php endif; ?>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</div>
<?php /**PATH C:\laragon\www\manga-scraper\resources\views/vendor/comments/components/comments.blade.php ENDPATH**/ ?>