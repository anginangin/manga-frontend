<div id="sidebar_menu_bg"></div>
<div id="sidebar_menu">
    
    <button class="btn toggle-sidebar">
        <i class="fas fa-angle-left"></i>
    </button>
    <ul class="nav sidebar_menu-list">
        <li class="nav-item">
            <a class="nav-link" href="/">Home</a>
        </li>
        <li class="nav-item">
            <a class="nav-link" href="/manga/text-mode">Manga List</a>
        </li>
        <li class="nav-item">
            <a class="nav-link" href="/az-list">A-Z List</a>
        </li>
        
        
    </ul>
    <div class="clearfix"></div>
</div><?php /**PATH C:\laragon\www\manga-scraper\resources\views/includes/sidebar.blade.php ENDPATH**/ ?>