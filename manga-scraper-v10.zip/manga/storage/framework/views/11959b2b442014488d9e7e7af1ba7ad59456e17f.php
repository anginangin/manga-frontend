<div id="sidebar_menu_bg"></div>
<div id="sidebar_menu">
    <a class="sb-uimode" href="javascript:;" id="sb-toggle-mode"
        ><i class="fas fa-moon mr-2"></i><span class="text-dm">Dark Mode</span
        ><span class="text-lm">Light Mode</span></a
    >
    <button class="btn toggle-sidebar">
        <i class="fas fa-angle-left"></i>
    </button>
    <ul class="nav sidebar_menu-list">
        <li class="nav-item">
            <a class="nav-link" href="https://mangareader.to/home">Home</a>
        </li>
        <li class="nav-item">
            <a class="nav-link" href="javascript:;" title="Types">Types</a>
            <div class="types-sub">
                <a class="ts-item" href="https://mangareader.to/type/manga"
                    >Manga</a
                >

                <a class="ts-item" href="https://mangareader.to/type/one-shot"
                    >One-shot</a
                >

                <a class="ts-item" href="https://mangareader.to/type/doujinshi"
                    >Doujinshi</a
                >

                <a
                    class="ts-item"
                    href="https://mangareader.to/type/light-novel"
                    >Light Novel</a
                >

                <a class="ts-item" href="https://mangareader.to/type/manhwa"
                    >Manhwa</a
                >

                <a class="ts-item" href="https://mangareader.to/type/manhua"
                    >Manhua</a
                >

                <a class="ts-item" href="https://mangareader.to/type/comic"
                    >Comic</a
                >
            </div>
        </li>
        <li class="nav-item">
            <a
                class="nav-link"
                href="https://mangareader.to/completed"
                title="Completed"
                >Completed</a
            >
        </li>
        <li class="nav-item">
            <a
                class="nav-link"
                href="https://mangareader.to/az-list"
                title="A-Z List"
                >A-Z List</a
            >
        </li>
        <li class="nav-item">
            <a
                class="nav-link"
                href="https://mangareader.to/random"
                title="Random"
                >Random</a
            >
        </li>
        <li class="nav-item">
            <a class="nav-link" href="#" target="_blank" title="News">News</a>
        </li>
        <li class="nav-item">
            <div class="nav-link"><strong>Genres</strong></div>
            <div class="sidebar_menu-sub">
                <ul class="nav sub-menu">
                    <li class="nav-item">
                        <a
                            class="nav-link"
                            href="https://mangareader.to/genre/action"
                            >Action</a
                        >
                    </li>

                    <li class="nav-item">
                        <a
                            class="nav-link"
                            href="https://mangareader.to/genre/adventure"
                            >Adventure</a
                        >
                    </li>

                    <li class="nav-item">
                        <a
                            class="nav-link"
                            href="https://mangareader.to/genre/cars"
                            >Cars</a
                        >
                    </li>

                    <li class="nav-item">
                        <a
                            class="nav-link"
                            href="https://mangareader.to/genre/comedy"
                            >Comedy</a
                        >
                    </li>

                    <li class="nav-item">
                        <a
                            class="nav-link"
                            href="https://mangareader.to/genre/dementia"
                            >Dementia</a
                        >
                    </li>

                    <li class="nav-item">
                        <a
                            class="nav-link"
                            href="https://mangareader.to/genre/demons"
                            >Demons</a
                        >
                    </li>

                    <li class="nav-item">
                        <a
                            class="nav-link"
                            href="https://mangareader.to/genre/doujinshi"
                            >Doujinshi</a
                        >
                    </li>

                    <li class="nav-item">
                        <a
                            class="nav-link"
                            href="https://mangareader.to/genre/drama"
                            >Drama</a
                        >
                    </li>

                    <li class="nav-item">
                        <a
                            class="nav-link"
                            href="https://mangareader.to/genre/ecchi"
                            >Ecchi</a
                        >
                    </li>

                    <li class="nav-item">
                        <a
                            class="nav-link"
                            href="https://mangareader.to/genre/fantasy"
                            >Fantasy</a
                        >
                    </li>

                    <li class="nav-item">
                        <a
                            class="nav-link"
                            href="https://mangareader.to/genre/game"
                            >Game</a
                        >
                    </li>

                    <li class="nav-item">
                        <a
                            class="nav-link"
                            href="https://mangareader.to/genre/gender-bender"
                            >Gender Bender</a
                        >
                    </li>

                    <li class="nav-item">
                        <a
                            class="nav-link"
                            href="https://mangareader.to/genre/harem"
                            >Harem</a
                        >
                    </li>

                    <li class="nav-item">
                        <a
                            class="nav-link"
                            href="https://mangareader.to/genre/hentai"
                            >Hentai</a
                        >
                    </li>

                    <li class="nav-item">
                        <a
                            class="nav-link"
                            href="https://mangareader.to/genre/historical"
                            >Historical</a
                        >
                    </li>

                    <li class="nav-item">
                        <a
                            class="nav-link"
                            href="https://mangareader.to/genre/horror"
                            >Horror</a
                        >
                    </li>

                    <li class="nav-item">
                        <a
                            class="nav-link"
                            href="https://mangareader.to/genre/josei"
                            >Josei</a
                        >
                    </li>

                    <li class="nav-item">
                        <a
                            class="nav-link"
                            href="https://mangareader.to/genre/kids"
                            >Kids</a
                        >
                    </li>

                    <li class="nav-item">
                        <a
                            class="nav-link"
                            href="https://mangareader.to/genre/magic"
                            >Magic</a
                        >
                    </li>

                    <li class="nav-item">
                        <a
                            class="nav-link"
                            href="https://mangareader.to/genre/martial-arts"
                            >Martial Arts</a
                        >
                    </li>

                    <li class="nav-item">
                        <a
                            class="nav-link"
                            href="https://mangareader.to/genre/mecha"
                            >Mecha</a
                        >
                    </li>

                    <li class="nav-item">
                        <a
                            class="nav-link"
                            href="https://mangareader.to/genre/military"
                            >Military</a
                        >
                    </li>

                    <li class="nav-item">
                        <a
                            class="nav-link"
                            href="https://mangareader.to/genre/music"
                            >Music</a
                        >
                    </li>

                    <li class="nav-item">
                        <a
                            class="nav-link"
                            href="https://mangareader.to/genre/mystery"
                            >Mystery</a
                        >
                    </li>

                    <li class="nav-item">
                        <a
                            class="nav-link"
                            href="https://mangareader.to/genre/parody"
                            >Parody</a
                        >
                    </li>

                    <li class="nav-item">
                        <a
                            class="nav-link"
                            href="https://mangareader.to/genre/police"
                            >Police</a
                        >
                    </li>

                    <li class="nav-item">
                        <a
                            class="nav-link"
                            href="https://mangareader.to/genre/psychological"
                            >Psychological</a
                        >
                    </li>

                    <li class="nav-item">
                        <a
                            class="nav-link"
                            href="https://mangareader.to/genre/romance"
                            >Romance</a
                        >
                    </li>

                    <li class="nav-item">
                        <a
                            class="nav-link"
                            href="https://mangareader.to/genre/samurai"
                            >Samurai</a
                        >
                    </li>

                    <li class="nav-item">
                        <a
                            class="nav-link"
                            href="https://mangareader.to/genre/school"
                            >School</a
                        >
                    </li>

                    <li class="nav-item">
                        <a
                            class="nav-link"
                            href="https://mangareader.to/genre/scifi"
                            >Sci-Fi</a
                        >
                    </li>

                    <li class="nav-item">
                        <a
                            class="nav-link"
                            href="https://mangareader.to/genre/seinen"
                            >Seinen</a
                        >
                    </li>

                    <li class="nav-item">
                        <a
                            class="nav-link"
                            href="https://mangareader.to/genre/shoujo"
                            >Shoujo</a
                        >
                    </li>

                    <li class="nav-item">
                        <a
                            class="nav-link"
                            href="https://mangareader.to/genre/shoujo-ai"
                            >Shoujo Ai</a
                        >
                    </li>

                    <li class="nav-item">
                        <a
                            class="nav-link"
                            href="https://mangareader.to/genre/shounen"
                            >Shounen</a
                        >
                    </li>

                    <li class="nav-item">
                        <a
                            class="nav-link"
                            href="https://mangareader.to/genre/shounen-ai"
                            >Shounen Ai</a
                        >
                    </li>

                    <li class="nav-item">
                        <a
                            class="nav-link"
                            href="https://mangareader.to/genre/slice-of-life"
                            >Slice of Life</a
                        >
                    </li>

                    <li class="nav-item">
                        <a
                            class="nav-link"
                            href="https://mangareader.to/genre/space"
                            >Space</a
                        >
                    </li>

                    <li class="nav-item">
                        <a
                            class="nav-link"
                            href="https://mangareader.to/genre/sports"
                            >Sports</a
                        >
                    </li>

                    <li class="nav-item">
                        <a
                            class="nav-link"
                            href="https://mangareader.to/genre/super-power"
                            >Super Power</a
                        >
                    </li>

                    <li class="nav-item">
                        <a
                            class="nav-link"
                            href="https://mangareader.to/genre/supernatural"
                            >Supernatural</a
                        >
                    </li>

                    <li class="nav-item">
                        <a
                            class="nav-link"
                            href="https://mangareader.to/genre/thriller"
                            >Thriller</a
                        >
                    </li>

                    <li class="nav-item">
                        <a
                            class="nav-link"
                            href="https://mangareader.to/genre/vampire"
                            >Vampire</a
                        >
                    </li>

                    <li class="nav-item">
                        <a
                            class="nav-link"
                            href="https://mangareader.to/genre/yaoi"
                            >Yaoi</a
                        >
                    </li>

                    <li class="nav-item">
                        <a
                            class="nav-link"
                            href="https://mangareader.to/genre/yuri"
                            >Yuri</a
                        >
                    </li>

                    <li class="nav-item nav-more">
                        <a class="nav-link"
                            ><i class="fas fa-plus mr-2"></i>More</a
                        >
                    </li>
                </ul>
                <div class="clearfix"></div>
            </div>
        </li>
    </ul>
    <div class="clearfix"></div>
</div>
<?php /**PATH C:\laragon\www\laravel-scraper\resources\views/includes/sidebar.blade.php ENDPATH**/ ?>