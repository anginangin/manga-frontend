
<?php $__env->startSection('content'); ?>
<div class="deslide-wrap">
    <div class="container">
        <div id="slider">
            <div class="swiper-wrapper">
                <?php $__currentLoopData = $mangas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $slider): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="swiper-slide">
                    <div class="deslide-item">
                        <a href="<?php echo e(route('detail', $slider['slug'])); ?>" class="deslide-cover">
                            <img 
                                class="manga-poster-img" 
                                src="<?php echo e((!$slider['thumbnail']) 
                                    ? $slider['poster'] 
                                    : config('constant.url.api_image').$slider['thumbnail']); ?>"
                                alt="<?php echo e($slider['title']); ?>" 
                            />
                        </a>
                        <div class="deslide-poster">
                            <a href="<?php echo e(route('detail', $slider['slug'])); ?>" class="manga-poster">
                                <img 
                                    src="<?php echo e((!$slider['thumbnail']) 
                                        ? $slider['poster'] 
                                        : config('constant.url.api_image').$slider['thumbnail']); ?>"
                                    class="manga-poster-img" 
                                    alt="<?php echo e($slider['title']); ?>" 
                                />
                            </a>
                        </div>
                        <div class="deslide-item-content">
                            <div class="desi-head-title">
                                <a title="<?php echo e($slider['title']); ?>" href="<?php echo e(route('detail', $slider['slug'])); ?>">
                                    <?php echo e($slider['title']); ?>

                                </a>
                            </div>
                            <div class="sc-detail">
                                <div class="scd-item mb-3 text-justify">
                                    <?php echo e(substr($slider['description'],0,300).'...'); ?>

                                </div>
                                <div class="clearfix"></div>
                            </div>
                            <div class="desi-buttons">
                                
                                <a href="<?php echo e(route('detail', $slider['slug'])); ?>" class="btn btn-slide-info">
                                    View Info
                                </a>
                            </div>
                        </div>
                        <div class="clearfix"></div>
                    </div>
                </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
            <div class="swiper-pagination"></div>
            <div class="swiper-navigation">
                <div class="swiper-button swiper-button-next">
                    <i class="fas fa-angle-right"></i>
                </div>
                <div class="swiper-button swiper-button-prev">
                    <i class="fas fa-angle-left"></i>
                </div>
            </div>
            <div class="clearfix"></div>
        </div>
    </div>
</div>
<div id="text-home">
    <div class="container">
        <!--Begin: text home-->
        <div class="text-home d-sm-block d-none">
            <div class="text-home-main">
                <?php echo e($web['description']); ?>

            </div>
            
        </div>
        <!--/End: text home-->
    </div>
</div>

<div id="manga-trending">
    <div class="container">
        <section class="block_area block_area_trending mb-0 mt-3">
            <div class="block_area-header">
                <div class="bah-heading">
                    <h2 class="cat-heading">Terpopuler Hari Ini</h2>
                </div>
                <div class="clearfix"></div>
            </div>
            <div class="block_area-content">
                <div class="trending-list" id="trending-home" style="display: none">
                    <div class="swiper-container">
                        <div class="swiper-wrapper">
                            <?php $__currentLoopData = $daily_views; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $trending): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php if($trending->today_count != 0): ?>
                            <div class="swiper-slide">
                                <div class="item">
                                    <div class="manga-poster">
                                        <a class="link-mask" href="<?php echo e(route('detail', str_replace('/manga/','',$trending->slug))); ?>"></a>
                                            <img 
                                                src="<?php echo e((!$trending->thumbnail) 
                                                    ? $trending->poster
                                                    : config('constant.url.api_image').$trending->thumbnail); ?>"
                                                class="manga-poster-img lazyload" 
                                                alt="<?php echo e($trending->title); ?>" 
                                            />
                                    </div>
                                    <div class="number">
                                        <span><?php echo e($loop->iteration); ?></span>
                                        <div class="anime-name"><?php echo e(substr($trending->title,0,25). '...'); ?></div>
                                    </div>
                                    <div class="clearfix"></div>
                                </div>
                            </div>
                            <?php endif; ?>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
                        <div class="clearfix"></div>
                    </div>
                    <div class="trending-navi">
                        <div class="navi-next">
                            <i class="fas fa-angle-right"></i>
                        </div>
                        <div class="navi-prev"><i class="fas fa-angle-left"></i></div>
                    </div>
                </div>
            </div>
        </section>
    </div>
</div>

<!-- GENRE -->
<br>
<div class="category_block category_block-home">
    <div class="container">
        <div class="c_b-wrap">
            <div class="c_b-list">
                <div class="cbl-row">
                    <?php $__currentLoopData = $arr_genre; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $genre): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="item">
                        <a href="/genre/<?php echo e($genre); ?>" title="<?php echo e($genre); ?>">
                            <?php echo e($genre); ?>

                        </a>
                    </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
                <div class="clearfix"></div>
            </div>
        </div>
    </div>
</div>
<!-- GENRE -->

<div id="manga-continue"></div>

<div id="main-wrapper">
    <div class="container">
        <div id="mw-2col">
            <!-- LATEST UPDATES -->
            <div id="main-content">
                
                
                <div class="clearfix"></div>

                
                <section class="block_area block_area_home">
                    <div class="block_area-header block_area-header-tabs">
                        <div class="float-left bah-heading">
                            <h2 class="cat-heading">Rilisan Terbaru</h2>
                        </div>
                        <div class="clearfix"></div>
                    </div>
                    <div class="tab-content">
                        <div id="latest-chap">
                            <div class="manga_list-sbs">
                                <div class="mls-wrap">
                                    <?php $__empty_1 = true; $__currentLoopData = $mangas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $manga): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                    <div class="item item-spc">
                                        <a class="manga-poster" href="<?php echo e(route('detail', $manga['slug'])); ?>">
                                            <?php if($manga['created_at'] == now()): ?>
                                                <span class="tick tick-item tick-lang">NEW</span>
                                            <?php endif; ?>
                                            <img 
                                                src="<?php echo e((!$manga['thumbnail'])
                                                    ? $manga['poster']
                                                    : config('constant.url.api_image').$manga['thumbnail']); ?>"
                                                class="manga-poster-img lazyload" 
                                                alt="<?php echo e($manga['title']); ?>" 
                                            />
                                        </a>
                                        <div class="manga-detail">
                                            <h3 class="manga-name">
                                                <a  href="<?php echo e(route('detail', $manga['slug'])); ?>" title="<?php echo e($manga['title']); ?>">
                                                    <?php echo e($manga['title']); ?>

                                                </a>
                                            </h3>
                                            <div class="fd-infor">
                                                <span class="fdi-item fdi-cate">
                                                    <?php $genres = json_decode($manga['genre']) ?>
                                                    <?php $__currentLoopData = $genres; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $genre): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <a href="/genre/<?php echo e($genre->genre); ?>">
                                                        <?php echo e($genre->genre); ?>

                                                    </a>,
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                </span>
                                                <div class="clearfix"></div>
                                            </div>
                                            <div class="fd-list">
                                                <?php $i = 0 ?>
                                                <?php $__currentLoopData = $manga['chapters']->sortByDesc('chapter'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $k => $chapter): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <div class="fdl-item">
                                                    <div class="chapter">
                                                        <a href="/read<?php echo e($chapter['path']); ?>" class="d-inline">
                                                            <i class="far fa-file-alt mr-2"></i>
                                                            Chapter <?php echo e($chapter['chapter']); ?>

                                                        </a>
                                                    </div>
                                                    <div class="release-time">
                                                        <span class="text-muted"></span>
                                                    </div>
                                                    <div class="clearfix"></div>
                                                </div>
                                                <?php if(++$i == 3): ?>
                                                <?php break; ?>
                                                <?php endif; ?>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </div>
                                        </div>
                                        <div class="clearfix"></div>
                                    </div>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                    Data tidak ditemukan.
                                    <?php endif; ?>
                                    <div class="clearfix"></div>
                                </div>
                                <div class="pre-pagination mt-4">
                                    <?php echo e($mangas->onEachSide(1)->links()); ?>

                                </div>
                            </div>
                        </div>
                    </div>
                </section>
                <div class="clearfix"></div>
            </div>
            <!-- LATEST UPDATES -->

            <!-- MOST VIEWED -->
            <?php echo $__env->make('includes.main_sidebar', [
            'daily_views' => $daily_views,
            'weekly_views' => $weekly_views,
            'monthly_views' => $monthly_views
            ], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <!-- MOST VIEWED -->

            <div class="clearfix"></div>

            <section class="block_area block_area_featured">
                <div class="block_area-header">
                    <div class="bah-heading">
                        <h2 class="cat-heading">Rekomendasi</h2>
                    </div>
                    <div class="clearfix"></div>
                </div>
                <div class="block_area-content">
                    <div class="featured-list" id="featured-04" style="display: none">
                        <div class="swiper-container">
                            <div class="swiper-wrapper">
                                <?php $__currentLoopData = $rekomendasi; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $rekomendasi): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <div class="swiper-slide">
                                    <div class="mg-item-basic">
                                        <div class="manga-poster">
                                            <a class="link-mask" href="<?php echo e(route('detail', str_replace('/manga/','',$rekomendasi['slug']))); ?>"></a>
                                            <span class="tick tick-item tick-lang"></span>
                                            <img 
                                                src="<?php echo e((!$rekomendasi['thumbnail'])
                                                    ? $rekomendasi['poster']
                                                    : config('constant.url.api_image').$rekomendasi['thumbnail']); ?>"
                                                class="manga-poster-img lazyload" 
                                                alt="<?php echo e($rekomendasi['title']); ?>" 
                                            />
                                        </div>
                                        <div class="manga-detail">
                                            <h3 class="manga-name">
                                                <a href="<?php echo e(route('detail', str_replace('/manga/','',$rekomendasi['slug']))); ?>" title="<?php echo e($rekomendasi['title']); ?>">
                                                    <?php echo e($rekomendasi['title']); ?>

                                                </a>
                                            </h3>
                                            <div class="fd-infor">
                                                <?php $genres = json_decode($rekomendasi['genre']) ?>
                                                <?php $__currentLoopData = array_slice($genres,0,2); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $genre): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <a href="/genre/<?php echo e($genre->genre); ?>">
                                                    <?php echo e($genre->genre); ?>

                                                </a>,
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                <div class="clearfix"></div>
                                            </div>
                                        </div>
                                        <div class="clearfix"></div>
                                    </div>
                                </div>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </div>
                            <div class="clearfix"></div>
                        </div>
                        <div class="featured-navi">
                            <div class="navi-next">
                                <i class="fas fa-angle-right"></i>
                            </div>
                            <div class="navi-prev">
                                <i class="fas fa-angle-left"></i>
                            </div>
                        </div>
                    </div>
                </div>
            </section>

            <div class="clearfix"></div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.web', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\manga-scraper\resources\views/homepage.blade.php ENDPATH**/ ?>