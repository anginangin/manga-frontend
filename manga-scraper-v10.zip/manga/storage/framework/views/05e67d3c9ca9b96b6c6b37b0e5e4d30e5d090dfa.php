<div id="modal-tab-login" class="tab-pane active">
    <div class="modal-header">
        <h5 class="modal-title" id="modallogintitle">Welcome back!</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
            <span aria-hidden="true">&times;</span>
        </button>
    </div>
    <div class="modal-body">
        
        <form class="preform" method="POST" action="<?php echo e(route('login')); ?>">
            <?php echo csrf_field(); ?>
            <div class="form-group">
                <label class="prelabel" for="email">Email address</label>
                <input id="email" type="email" class="form-control <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="email"
                    value="<?php echo e(old('email')); ?>" required autocomplete="email" autofocus placeholder="name@email.com">
                <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <span class="invalid-feedback" role="alert">
                    <strong><?php echo e($message); ?></strong>
                </span>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>
            <div class="form-group">
                <label class="prelabel" for="password">Password</label>
                <input id="password" type="password" class="form-control <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                    name="password" required autocomplete="current-password" placeholder="Password">

                <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <span class="invalid-feedback" role="alert">
                    <strong><?php echo e($message); ?></strong>
                </span>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>
            <div class="form-check custom-control custom-checkbox">
                <div class="float-left">
                    <input class="form-check-input" type="checkbox" name="remember" id="remember" <?php echo e(old('remember')
                        ? 'checked' : ''); ?>>
                    <span class="text-white">Remember me</span>
                </div>
                <div class="float-right">
                    <a href="javascript:;" class="link-highlight text-forgot forgot-tab-link">Forgot
                        password?</a>
                </div>
                <div class="clearfix"></div>
            </div>
            <div class="form-group login-btn mt-4 mb-2">
                <button type="submit" class="btn btn-primary btn-block">Sign-in</button>
                
            </div>
        </form>
    </div>
    <div class="modal-footer text-center">
        Don't have an account? <a class="link-highlight register-tab-link">Register</a>
    </div>
</div>
<?php /**PATH C:\laragon\www\manga-scraper\resources\views/pages/user/login.blade.php ENDPATH**/ ?>