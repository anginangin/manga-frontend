
<?php $__env->startSection('content'); ?>
<div class="prebreadcrumb">
    <div class="container">
        <nav aria-label="breadcrumb">
            <ol class="breadcrumb">
                <li class="breadcrumb-item">
                    <a href="<?php echo e(route('homepage')); ?>">Home</a>
                </li>
                <li class="breadcrumb-item active">
                    Manga List
                </li>
            </ol>
        </nav>
    </div>
</div>
<div id="main-wrapper" class="page-layout page-category">
    <div class="container">
        <div id="mw-2col">
            <div id="main-content">
                <section class="block_area block_area_category">
                    <div class="block_area-header">
                        <div class="bah-heading float-left">
                            <h2 class="cat-heading">
                                Manga List
                            </h2>
                        </div>
                        <div class="cate-sort float-right">
                            <div class="cs-item">
                                <a href="/manga/text-mode" class="btn btn-sm btn-sort">
                                    Text Mode
                                </a>
                            </div>
                            <div class="clearfix"></div>
                        </div>
                        <div class="clearfix"></div>
                    </div>
                    <div class="manga_list-sbs">
                        <div class="mls-wrap">
                            <?php $__empty_1 = true; $__currentLoopData = $image_mode; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                            <div class="item item-spc">
                                <a class="manga-poster" href="<?php echo e(route('detail', $data['slug'])); ?>">
                                    <img 
                                        src="<?php echo e((!$data['thumbnail'])
                                            ? $data['poster']
                                            : config('constant.url.api_image').$data['thumbnail']); ?>"
                                        class="manga-poster-img lazyload" 
                                        alt="<?php echo e($data['title']); ?>"
                                    >
                                </a>
                                <div class="manga-detail">
                                    <h3 class="manga-name">
                                        <a href="<?php echo e(route('detail', $data['slug'])); ?>" title="<?php echo e($data['title']); ?>">
                                            <?php echo e($data['title']); ?>

                                        </a>
                                    </h3>
                                    <div class="fd-infor">
                                        <span class="fdi-item fdi-cate">
                                            <?php $asu = json_decode($data['genre']) ?>
                                            <?php $__currentLoopData = $asu; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $genre): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <a href="/genre/<?php echo e($genre->genre); ?>">
                                                <?php echo e($genre->genre); ?>

                                            </a>,
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </span>
                                        <div class="clearfix"></div>
                                    </div>
                                    <div class="fd-list">
                                        <?php $i = 0 ?>
                                        <?php $__currentLoopData = $data['chapters']->sortByDesc('chapter'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $k => $chapter): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <div class="fdl-item">
                                            <div class="chapter">
                                                <a href="/read<?php echo e($chapter['path']); ?>" class="d-inline">
                                                    <i class="far fa-file-alt mr-2"></i>
                                                    Chapter <?php echo e($chapter['chapter']); ?>

                                                </a>
                                            </div>
                                            <div class="release-time"></div>
                                            <div class="clearfix"></div>
                                        </div>
                                        <?php if(++$i == 3): ?>
                                        <?php break; ?>
                                        <?php endif; ?>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </div>
                                </div>
                                <div class="clearfix"></div>
                            </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                            <div class="text-center">
                                Manga tidak ditemukan.
                            </div>
                            <?php endif; ?>
                            <div class="clearfix"></div>
                        </div>
                        <div class="pre-pagination mt-4">
                            <?php echo e($image_mode->links()); ?>

                        </div>
                    </div>
                </section>
                <div class="clearfix"></div>
            </div>
           
            <div id="main-sidebar">
                <section class="block_area block_area_sidebar block_area-genres">
                    <div class="block_area-header">
                        <div class="bah-heading">
                            <h2 class="cat-heading">
                                Genres
                            </h2>
                        </div>
                        <div class="clearfix"></div>
                    </div>
                    <div class="block_area-content">
                        <div class="category_block mb-0">
                            <div class="c_b-wrap">
                                <div class="c_b-list active">
                                    <div class="cbl-row">
                                        <?php $__empty_1 = true; $__currentLoopData = $arr_unique; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $genre): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                        <div class="item">
                                            <a href="/genre/<?php echo e($genre); ?>" title="<?php echo e($genre); ?>">
                                                <?php echo e($genre); ?>

                                            </a>
                                        </div>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                        Genre tidak ditemukan.
                                        <?php endif; ?>
                                    </div>
                                    <div class="clearfix"></div>
                                </div>
                            </div>
                        </div>
                    </div>
                </section>
            </div>
            <div class="clearfix"></div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.web', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\manga-scraper\resources\views/pages/manga_list/image_mode.blade.php ENDPATH**/ ?>