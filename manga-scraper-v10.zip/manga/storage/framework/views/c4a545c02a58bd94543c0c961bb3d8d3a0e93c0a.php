<!DOCTYPE html>
<html lang="en">

<head>
    <title>Mareceh - Read Manga website</title>

    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
    <meta name="robots" content="index,follow" />
    <meta http-equiv="content-language" content="en" />
    <meta name="description"
        content="Best website to Read Manga online. We have the biggest library of over 200,000 manga available for Free download. Read Manga now!" />
    <meta name="keywords"
        content="read manga online, read manga, manga online, manga online free, free manga, manga reader, manga scans, manga raw" />
    <meta property="og:type" content="website" />
    <meta property="og:url" content="https://mangareader.to/home" />
    <meta property="og:title" content="MangaReader - Read Manga website" />
    <meta property="og:image:width" content="650" />
    <meta property="og:image:height" content="350" />
    <meta property="og:description"
        content="Best website to Read Manga online. We have the biggest library of over 200,000 manga available for Free download. Read Manga now!" />
    <meta name="viewport" content="width=device-width, initial-scale=1, minimum-scale=1, maximum-scale=2" />
    <meta name="p:domain_verify" content="af0275499319c533df212167fc646dfb" />
    <meta name="msapplication-TileColor" content="#5f25a6" />

    <?php echo $__env->make('includes.style', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</head>

<body>
    <?php echo $__env->make('includes.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <div id="wrapper">
        <?php echo $__env->make('includes.navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

        <div class="clearfix"></div>

        <?php echo $__env->yieldContent('content'); ?>

        <?php echo $__env->make('includes.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    </div>

    <?php echo $__env->make('includes.script', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</body>

</html><?php /**PATH C:\laragon\www\laravel-scraper\resources\views/layouts/app.blade.php ENDPATH**/ ?>