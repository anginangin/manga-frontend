<!DOCTYPE html>
<html lang="en">

<head>
    <title>Mareceh - Read Manga website</title>

    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
    <meta name="robots" content="index,follow" />
    <meta http-equiv="content-language" content="en" />
    <meta name="description"
        content="Best website to Read Manga online. We have the biggest library of over 200,000 manga available for Free download. Read Manga now!" />
    <meta name="keywords"
        content="read manga online, read manga, manga online, manga online free, free manga, manga reader, manga scans, manga raw" />
    <meta property="og:type" content="website" />
    <meta property="og:url" content="https://mangareader.to/home" />
    <meta property="og:title" content="MangaReader - Read Manga website" />
    <meta property="og:image:width" content="650" />
    <meta property="og:image:height" content="350" />
    <meta property="og:description"
        content="Best website to Read Manga online. We have the biggest library of over 200,000 manga available for Free download. Read Manga now!" />
    <meta name="viewport" content="width=device-width, initial-scale=1, minimum-scale=1, maximum-scale=2" />
    <meta name="p:domain_verify" content="af0275499319c533df212167fc646dfb" />
    <meta name="msapplication-TileColor" content="#5f25a6" />

    <link rel="shortcut icon"
        href="https://i0.wp.com/mareceh.com/wp-content/uploads/2022/03/cropped-Ma_receh2-32x32.png" />
    <link rel="apple-touch-icon" sizes="180x180" href="https://mangareader.to/images/apple-touch-icon.png" />
    
    <link rel="mask-icon" href="https://mangareader.to/images/safari-pinned-tab.svg" color="#5f25a6" />
    <link rel="stylesheet" href="/assets/css/bootstrap.min.css" />
    <link rel="stylesheet" href="/assets/css/bootstrap.min.css.map" />
    <link rel="stylesheet" href="/assets/css/bootstrap.css.map" />
    <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.3.1/css/all.css" />
    <link rel="stylesheet" href="/assets/css/custom.css" />
    <script async src="https://www.googletagmanager.com/gtag/js?id=UA-207641274-1"></script>
    <script type="text/javascript"
        src="https://mangareader.to//services.vlitag.com/adv1/?q=591701d038949ac7ff56b261301cad42" defer="" async="">
    </script>
    <script>
        window.dataLayer = window.dataLayer || [];

        function gtag() {
            dataLayer.push(arguments);
        }
        gtag("js", new Date());
        gtag("config", "UA-207641274-1");
        
        var vitag = vitag || {};
        vitag.outStreamConfig = { version: "v1" };
    </script>
</head>

<body>
    <!-- MOBILE MENU -->
    <div id="sidebar_menu_bg"></div>
    <div id="sidebar_menu">
        <a class="sb-uimode" href="javascript:;" id="sb-toggle-mode"><i class="fas fa-moon mr-2"></i><span
                class="text-dm">Dark Mode</span><span class="text-lm">Light Mode</span></a>
        <button class="btn toggle-sidebar">
            <i class="fas fa-angle-left"></i>
        </button>
        <ul class="nav sidebar_menu-list">
            <li class="nav-item">
                <a class="nav-link" href="https://mangareader.to/home">Home</a>
            </li>
            <li class="nav-item">
                <a class="nav-link" href="javascript:;" title="Types">Types</a>
                <div class="types-sub">
                    <a class="ts-item" href="https://mangareader.to/type/manga">Manga</a>

                    <a class="ts-item" href="https://mangareader.to/type/one-shot">One-shot</a>

                    <a class="ts-item" href="https://mangareader.to/type/doujinshi">Doujinshi</a>

                    <a class="ts-item" href="https://mangareader.to/type/light-novel">Light Novel</a>

                    <a class="ts-item" href="https://mangareader.to/type/manhwa">Manhwa</a>

                    <a class="ts-item" href="https://mangareader.to/type/manhua">Manhua</a>

                    <a class="ts-item" href="https://mangareader.to/type/comic">Comic</a>
                </div>
            </li>
            <li class="nav-item">
                <a class="nav-link" href="https://mangareader.to/completed" title="Completed">Completed</a>
            </li>
            <li class="nav-item">
                <a class="nav-link" href="https://mangareader.to/az-list" title="A-Z List">A-Z List</a>
            </li>
            <li class="nav-item">
                <a class="nav-link" href="https://mangareader.to/random" title="Random">Random</a>
            </li>
            <li class="nav-item">
                <a class="nav-link" href="#" target="_blank" title="News">News</a>
            </li>
            <li class="nav-item">
                <div class="nav-link"><strong>Genres</strong></div>
                <div class="sidebar_menu-sub">
                    <ul class="nav sub-menu">
                        <li class="nav-item">
                            <a class="nav-link" href="https://mangareader.to/genre/action">Action</a>
                        </li>

                        <li class="nav-item">
                            <a class="nav-link" href="https://mangareader.to/genre/adventure">Adventure</a>
                        </li>

                        <li class="nav-item">
                            <a class="nav-link" href="https://mangareader.to/genre/cars">Cars</a>
                        </li>

                        <li class="nav-item">
                            <a class="nav-link" href="https://mangareader.to/genre/comedy">Comedy</a>
                        </li>

                        <li class="nav-item">
                            <a class="nav-link" href="https://mangareader.to/genre/dementia">Dementia</a>
                        </li>

                        <li class="nav-item">
                            <a class="nav-link" href="https://mangareader.to/genre/demons">Demons</a>
                        </li>

                        <li class="nav-item">
                            <a class="nav-link" href="https://mangareader.to/genre/doujinshi">Doujinshi</a>
                        </li>

                        <li class="nav-item">
                            <a class="nav-link" href="https://mangareader.to/genre/drama">Drama</a>
                        </li>

                        <li class="nav-item">
                            <a class="nav-link" href="https://mangareader.to/genre/ecchi">Ecchi</a>
                        </li>

                        <li class="nav-item">
                            <a class="nav-link" href="https://mangareader.to/genre/fantasy">Fantasy</a>
                        </li>

                        <li class="nav-item">
                            <a class="nav-link" href="https://mangareader.to/genre/game">Game</a>
                        </li>

                        <li class="nav-item">
                            <a class="nav-link" href="https://mangareader.to/genre/gender-bender">Gender Bender</a>
                        </li>

                        <li class="nav-item">
                            <a class="nav-link" href="https://mangareader.to/genre/harem">Harem</a>
                        </li>

                        <li class="nav-item">
                            <a class="nav-link" href="https://mangareader.to/genre/hentai">Hentai</a>
                        </li>

                        <li class="nav-item">
                            <a class="nav-link" href="https://mangareader.to/genre/historical">Historical</a>
                        </li>

                        <li class="nav-item">
                            <a class="nav-link" href="https://mangareader.to/genre/horror">Horror</a>
                        </li>

                        <li class="nav-item">
                            <a class="nav-link" href="https://mangareader.to/genre/josei">Josei</a>
                        </li>

                        <li class="nav-item">
                            <a class="nav-link" href="https://mangareader.to/genre/kids">Kids</a>
                        </li>

                        <li class="nav-item">
                            <a class="nav-link" href="https://mangareader.to/genre/magic">Magic</a>
                        </li>

                        <li class="nav-item">
                            <a class="nav-link" href="https://mangareader.to/genre/martial-arts">Martial Arts</a>
                        </li>

                        <li class="nav-item">
                            <a class="nav-link" href="https://mangareader.to/genre/mecha">Mecha</a>
                        </li>

                        <li class="nav-item">
                            <a class="nav-link" href="https://mangareader.to/genre/military">Military</a>
                        </li>

                        <li class="nav-item">
                            <a class="nav-link" href="https://mangareader.to/genre/music">Music</a>
                        </li>

                        <li class="nav-item">
                            <a class="nav-link" href="https://mangareader.to/genre/mystery">Mystery</a>
                        </li>

                        <li class="nav-item">
                            <a class="nav-link" href="https://mangareader.to/genre/parody">Parody</a>
                        </li>

                        <li class="nav-item">
                            <a class="nav-link" href="https://mangareader.to/genre/police">Police</a>
                        </li>

                        <li class="nav-item">
                            <a class="nav-link" href="https://mangareader.to/genre/psychological">Psychological</a>
                        </li>

                        <li class="nav-item">
                            <a class="nav-link" href="https://mangareader.to/genre/romance">Romance</a>
                        </li>

                        <li class="nav-item">
                            <a class="nav-link" href="https://mangareader.to/genre/samurai">Samurai</a>
                        </li>

                        <li class="nav-item">
                            <a class="nav-link" href="https://mangareader.to/genre/school">School</a>
                        </li>

                        <li class="nav-item">
                            <a class="nav-link" href="https://mangareader.to/genre/scifi">Sci-Fi</a>
                        </li>

                        <li class="nav-item">
                            <a class="nav-link" href="https://mangareader.to/genre/seinen">Seinen</a>
                        </li>

                        <li class="nav-item">
                            <a class="nav-link" href="https://mangareader.to/genre/shoujo">Shoujo</a>
                        </li>

                        <li class="nav-item">
                            <a class="nav-link" href="https://mangareader.to/genre/shoujo-ai">Shoujo Ai</a>
                        </li>

                        <li class="nav-item">
                            <a class="nav-link" href="https://mangareader.to/genre/shounen">Shounen</a>
                        </li>

                        <li class="nav-item">
                            <a class="nav-link" href="https://mangareader.to/genre/shounen-ai">Shounen Ai</a>
                        </li>

                        <li class="nav-item">
                            <a class="nav-link" href="https://mangareader.to/genre/slice-of-life">Slice of Life</a>
                        </li>

                        <li class="nav-item">
                            <a class="nav-link" href="https://mangareader.to/genre/space">Space</a>
                        </li>

                        <li class="nav-item">
                            <a class="nav-link" href="https://mangareader.to/genre/sports">Sports</a>
                        </li>

                        <li class="nav-item">
                            <a class="nav-link" href="https://mangareader.to/genre/super-power">Super Power</a>
                        </li>

                        <li class="nav-item">
                            <a class="nav-link" href="https://mangareader.to/genre/supernatural">Supernatural</a>
                        </li>

                        <li class="nav-item">
                            <a class="nav-link" href="https://mangareader.to/genre/thriller">Thriller</a>
                        </li>

                        <li class="nav-item">
                            <a class="nav-link" href="https://mangareader.to/genre/vampire">Vampire</a>
                        </li>

                        <li class="nav-item">
                            <a class="nav-link" href="https://mangareader.to/genre/yaoi">Yaoi</a>
                        </li>

                        <li class="nav-item">
                            <a class="nav-link" href="https://mangareader.to/genre/yuri">Yuri</a>
                        </li>

                        <li class="nav-item nav-more">
                            <a class="nav-link"><i class="fas fa-plus mr-2"></i>More</a>
                        </li>
                    </ul>
                    <div class="clearfix"></div>
                </div>
            </li>
        </ul>
        <div class="clearfix"></div>
    </div>
    <!-- MOBILE MENU -->

    <div id="wrapper">
        <!-- SUB HEADER -->
        <div id="sub-header" class="home-sub-header">
            <div class="container">
                <div class="sh-left">
                    <div class="float-left">
                        <!-- <a href="https://mangareader.to/random" class="sh-item">
                <i class="fas fa-glasses mr-2"></i>Read Random
              </a>
              <div class="spacing"></div>
              <a href="https://zoro.to" target="_blank" class="sh-item">
                <i class="fas fa-play-circle mr-2"></i>Anime Online
              </a> -->
                    </div>
                    <div class="clearfix"></div>
                </div>
                <div class="sh-right">
                    <div class="float-left">
                        <!-- <div class="sh-item mr-3">
                <strong>Follow us :</strong>
              </div>
              <a
                target="_blank"
                href="https://www.reddit.com/r/MangaReaderOfficial"
                class="sh-item mr-3"
              >
                <i class="fab fa-reddit-alien mr-2"></i>Reddit
              </a>
              <a
                target="_blank"
                href="https://twitter.com/WeMangaReader"
                class="sh-item mr-3"
              >
                <i class="fab fa-twitter mr-2"></i>Twitter
              </a>
              <a
                target="_blank"
                href="https://discord.gg/Bvc5mVcUqE"
                class="sh-item"
              >
                <i class="fab fa-discord mr-2"></i>Discord
              </a>
              <div class="clearfix"></div> -->
                    </div>
                    <div class="spacing"></div>
                    <div class="float-right">
                        <a class="sh-item sb-uimode" id="toggle-mode">
                            <i class="fas fa-moon mr-2"></i><span class="text-dm">Dark Mode</span><span
                                class="text-lm">Light Mode</span>
                        </a>
                        <div class="clearfix"></div>
                    </div>
                    <div class="clearfix"></div>
                </div>
                <div class="clearfix"></div>
            </div>
        </div>
        <!-- SUB HEADER -->

        <!-- MAIN HEADER -->
        <div id="header" class="home-header">
            <div class="container">
                <div id="mobile_menu"><i class="fa fa-bars"></i></div>
                <div id="mobile_search"><i class="fa fa-search"></i></div>
                <a href="<?php echo e(route('homepage')); ?>" id="logo">
                    <img src="http://mareceh.com/wp-content/uploads/2022/03/Ma_receh.png" alt="logo" />
                    <div class="clearfix"></div>
                </a>
                <div id="header_menu">
                    <ul class="nav header_menu-list">
                        <li class="nav-item">
                            <a href="https://mangareader.to/completed" title="Completed">Completed</a>
                        </li>
                        <li class="nav-item">
                            <a href="javascript:;" title="Types">Types<i class="fas fa-angle-down ml-2"></i></a>
                            <div class="header_menu-sub" style="display: none">
                                <ul class="sub-menu">
                                    <li>
                                        <a href="https://mangareader.to/type/manga">Manga</a>
                                    </li>

                                    <li>
                                        <a href="https://mangareader.to/type/one-shot">One-shot</a>
                                    </li>

                                    <li>
                                        <a href="https://mangareader.to/type/doujinshi">Doujinshi</a>
                                    </li>

                                    <li>
                                        <a href="https://mangareader.to/type/light-novel">Light Novel</a>
                                    </li>

                                    <li>
                                        <a href="https://mangareader.to/type/manhwa">Manhwa</a>
                                    </li>

                                    <li>
                                        <a href="https://mangareader.to/type/manhua">Manhua</a>
                                    </li>

                                    <li>
                                        <a href="https://mangareader.to/type/comic">Comic</a>
                                    </li>
                                </ul>
                                <div class="clearfix"></div>
                            </div>
                        </li>
                        <li class="nav-item">
                            <a href="https://mangareader.to/az-list" title="A-Z List">A-Z List</a>
                        </li>
                        <li class="nav-item">
                            <a href="#" target="_blank" title="News">News</a>
                        </li>
                    </ul>
                    <div class="clearfix"></div>
                </div>
                <div id="header_right">
                    <div id="search">
                        <div class="search-content">
                            <form action="/search" autocomplete="off">
                                <a href="https://mangareader.to/filter" class="filter-icon">FILTER</a>
                                <input type="text" name="keyword" class="form-control search-input"
                                    placeholder="Search manga..." />
                                <button type="submit" class="search-icon">
                                    <i class="fas fa-search"></i>
                                </button>
                            </form>
                            <div class="nav search-result-pop" id="search-suggest">
                                <div class="loading-relative" id="search-loading"
                                    style="min-height: 60px; display: none">
                                    <div class="loading">
                                        <div class="span1"></div>
                                        <div class="span2"></div>
                                        <div class="span3"></div>
                                    </div>
                                </div>
                                <div class="result" style="display: none"></div>
                            </div>
                        </div>
                    </div>

                    <div id="login-state" style="float: left"></div>
                    <div class="clearfix"></div>
                </div>
                <div class="clearfix"></div>
            </div>
        </div>
        <!-- MAIN HEADER -->

        <div class="clearfix"></div>
        <script>
            var uiMode = localStorage.getItem("uiMode");
        const body = document.body,
          btnMode = document.getElementById("toggle-mode"),
          sbBtnMode = document.getElementById("sb-toggle-mode");

        function activeUiMode() {
          if (uiMode === "dark") {
            btnMode && btnMode.classList.add("active");
            sbBtnMode && sbBtnMode.classList.add("active");
            body.classList.add("darkmode");
          } else {
            btnMode && btnMode.classList.remove("active");
            sbBtnMode && sbBtnMode.classList.remove("active");
            body.classList.remove("darkmode");
          }
        }

        if (uiMode) {
          activeUiMode();
        } else {
          window.matchMedia("(prefers-color-scheme: dark)").matches
            ? (uiMode = "dark")
            : (uiMode = "light");
          activeUiMode();
        }
        [btnMode, sbBtnMode].forEach((item) => {
          if (item) {
            item.addEventListener("click", function () {
              this.classList.contains("active")
                ? (uiMode = "light")
                : (uiMode = "dark");
              localStorage.setItem("uiMode", uiMode);
              activeUiMode();
            });
          }
        });
        </script>

        <!-- SLIDER -->
        <div class="deslide-wrap">
            <div class="container">
                <div id="slider">
                    <div class="swiper-wrapper">
                        <?php $__currentLoopData = $slider; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $slider): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="swiper-slide">
                            <div class="deslide-item">
                                <a href="#" class="deslide-cover">
                                    <img class="manga-poster-img"
                                        src="<?php echo e(str_replace('https://','https://i2.wp.com/',substr($slider['poster'],23,-3))); ?>"
                                        alt="<?php echo e($slider['title']); ?>" /></a>
                                <div class="deslide-poster">
                                    <a href="#" class="manga-poster">
                                        <img src="<?php echo e(str_replace('https://','https://i2.wp.com/',substr($slider['poster'],23,-3))); ?>"
                                            class="manga-poster-img" alt="<?php echo e($slider['title']); ?>" />
                                    </a>
                                </div>
                                <div class="deslide-item-content">
                                    

                                    <div class="desi-head-title">
                                        <a title="<?php echo e($slider['title']); ?>"
                                            href="https://mangareader.to/hunter-x-hunter-51"><?php echo e($slider['title']); ?></a>
                                    </div>
                                    <div class="sc-detail">
                                        <div class="scd-item mb-3">
                                            <?php echo e($slider['description']); ?>

                                        </div>
                                        
                                        <div class="clearfix"></div>
                                    </div>
                                    <div class="desi-buttons">
                                        <a href="https://mangareader.to/read/hunter-x-hunter-51"
                                            class="btn btn-slide-read mr-2">Read Now</a>
                                        <a href="https://mangareader.to/hunter-x-hunter-51"
                                            class="btn btn-slide-info">View Info</a>
                                    </div>
                                </div>
                                <div class="clearfix"></div>
                            </div>
                        </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                    <div class="swiper-pagination"></div>
                    <div class="swiper-navigation">
                        <div class="swiper-button swiper-button-next">
                            <i class="fas fa-angle-right"></i>
                        </div>
                        <div class="swiper-button swiper-button-prev">
                            <i class="fas fa-angle-left"></i>
                        </div>
                    </div>
                    <div class="clearfix"></div>
                </div>
            </div>
        </div>
        <!-- SLIDER -->

        <!-- DESCRIPTION -->
        <div id="text-home">
            <div class="container">
                <!--Begin: text home-->
                <div class="text-home">
                    <div class="text-home-main">
                        MangaReader is a Free website to download and read manga online.
                        We have a big library of over 600,000 manga chapters in all genres
                        that are available to read or download for FREE without
                        registration. The manga is updated daily to make sure no one will
                        ever miss the latest chapter on their favorite manga. If you like
                        the website, please bookmark it and help us to spread the words.
                        Thank you!
                    </div>
                </div>
                <!--/End: text home-->
            </div>
        </div>
        <!-- DESCRIPTION -->

        <!-- TRENDING -->
        <div id="manga-trending">
            <div class="container">
                <section class="block_area block_area_trending mb-0">
                    <div class="block_area-header">
                        <div class="bah-heading">
                            <h2 class="cat-heading">Trending</h2>
                        </div>
                        <div class="clearfix"></div>
                    </div>
                    <div class="block_area-content">
                        <div class="trending-list" id="trending-home" style="display: none">
                            <div class="swiper-container">
                                <div class="swiper-wrapper">
                                    <?php $count = 0; ?>
                                    <?php $__currentLoopData = $popular; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $trending): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php if($count == 10) break; ?>
                                    <div class="swiper-slide">
                                        <div class="item">
                                            <div class="manga-poster">
                                                <a class="link-mask" href="https://mangareader.to/one-piece-3"></a>
                                                <div class="mp-desc">
                                                    <p class="alias-name mb-2">
                                                        <strong><?php echo e($trending['judul']); ?></strong>
                                                    </p>
                                                    <p><i class="fas fa-star mr-2"></i><?php echo e($trending['rating']); ?></p>
                                                    <p>
                                                        <a
                                                            href="https://mangareader.to/read/one-piece-3/en/chapter-1065"><i
                                                                class="far fa-file-alt mr-2"></i><strong><?php echo e($trending['chapter']); ?></strong></a>
                                                    </p>

                                                    <div class="mpd-buttons">
                                                        <a href="https://mangareader.to/read/one-piece-3"
                                                            class="btn btn-primary btn-sm btn-block"><i
                                                                class="fas fa-glasses mr-2"></i>Read Now</a>
                                                        <a href="https://mangareader.to/one-piece-3"
                                                            class="btn btn-light btn-sm btn-block"><i
                                                                class="fas fa-info-circle mr-2"></i>Info</a>
                                                    </div>
                                                </div>
                                                <img src="<?php echo e(str_replace('https://','https://i2.wp.com/',$trending['image'])); ?>"
                                                    class="manga-poster-img lazyload" alt="<?php echo e($trending['judul']); ?>" />
                                            </div>

                                            <div class="number">
                                                <span><?php echo e($count+1); ?></span>
                                                <div class="anime-name"><?php echo e($trending['judul']); ?></div>
                                            </div>

                                            <div class="clearfix"></div>
                                        </div>
                                    </div>
                                    <?php $count++; ?>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </div>
                                <div class="clearfix"></div>
                            </div>
                            <div class="trending-navi">
                                <div class="navi-next">
                                    <i class="fas fa-angle-right"></i>
                                </div>
                                <div class="navi-prev"><i class="fas fa-angle-left"></i></div>
                            </div>
                        </div>
                    </div>
                </section>
            </div>
        </div>
        <!-- TRENDING -->

        <!-- CATEGORY -->
        <div class="category_block category_block-home">
            <div class="container">
                <div class="c_b-wrap">
                    <div class="c_b-list">
                        <div class="cbl-row">
                            <div class="item item-focus focus-01">
                                <a href="https://mangareader.to/latest-updated" title=""><i class="mr-1">⚡</i> Latest
                                    Updated</a>
                            </div>
                            <div class="item item-focus focus-02">
                                <a href="https://mangareader.to/new-release" title=""><i class="mr-1">✌</i> New
                                    Release</a>
                            </div>
                            <div class="item item-focus focus-04">
                                <a href="https://mangareader.to/most-viewed" title=""><i class="mr-1">🔥</i> Most
                                    Viewed</a>
                            </div>
                            <div class="item item-focus focus-05">
                                <a href="https://mangareader.to/completed" title=""><i class="mr-1">✅</i> Completed</a>
                            </div>
                        </div>
                        <div class="cbl-row">
                            <?php $__currentLoopData = $genre; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $genre): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="item">
                                <a href="#" title="<?php echo e($genre['genre']); ?>"><?php echo e($genre['genre']); ?></a>
                            </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                            <div class="item item-more">
                                <a class="im-toggle">+ More</a>
                            </div>
                        </div>
                        <div class="clearfix"></div>
                    </div>
                </div>
            </div>
        </div>
        <!-- CATEGORY -->

        <div id="manga-continue"></div>

        <!-- RECOMMENDED -->
        <div id="manga-featured">
            <div class="container">
                <section class="block_area block_area_featured">
                    <div class="block_area-header">
                        <div class="bah-heading">
                            <h2 class="cat-heading">Serial Baru</h2>
                        </div>
                        <div class="clearfix"></div>
                    </div>
                    <div class="block_area-content">
                        <div class="featured-list" id="featured-03" style="display: none">
                            <div class="swiper-container">
                                <div class="swiper-wrapper">
                                    <?php $__currentLoopData = $series; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $series): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <div class="swiper-slide">
                                        <div class="mg-item-basic">
                                            <div class="manga-poster">
                                                <a class="link-mask" href="#"></a>

                                                <span class="tick tick-item tick-lang">EN/FR/JA</span>

                                                <div class="mp-desc">
                                                    <p class="alias-name mb-2">
                                                        <strong>Hunter x Hunter</strong>
                                                    </p>
                                                    <p><i class="fas fa-star mr-2"></i>8.68</p>
                                                    <p><i class="fas fa-globe mr-2"></i>EN/FR/JA</p>

                                                    <p>
                                                        <a
                                                            href="https://mangareader.to/read/hunter-x-hunter-51/en/chapter-392"><i
                                                                class="far fa-file-alt mr-2"></i><strong>Chap 392
                                                                [EN]</strong></a>
                                                    </p>

                                                    <p>
                                                        <a
                                                            href="https://mangareader.to/read/hunter-x-hunter-51/en/volume-36"><i
                                                                class="far fa-file-alt mr-2"></i><strong>Vol 36
                                                                [EN]</strong></a>
                                                    </p>

                                                    <div class="mpd-buttons">
                                                        <a href="https://mangareader.to/read/hunter-x-hunter-51"
                                                            class="btn btn-primary btn-sm btn-block"><i
                                                                class="fas fa-glasses mr-2"></i>Read Now</a>
                                                        <a href="https://mangareader.to/hunter-x-hunter-51"
                                                            class="btn btn-light btn-sm btn-block"><i
                                                                class="fas fa-info-circle mr-2"></i>Info</a>
                                                    </div>
                                                </div>
                                                <img src="https://img.mreadercdn.com/_r/300x400/100/40/43/4043a01c14c5f8186b84f04261fae5ef/4043a01c14c5f8186b84f04261fae5ef.jpg"
                                                    class="manga-poster-img lazyload" alt="Hunter x Hunter" />
                                            </div>

                                            <div class="manga-detail">
                                                <h3 class="manga-name">
                                                    <a href="https://mangareader.to/hunter-x-hunter-51"
                                                        title="Hunter x Hunter">Hunter x Hunter</a>
                                                </h3>
                                                <div class="fd-infor">
                                                    <a href="https://mangareader.to/genre/action">Action</a>,

                                                    <a href="https://mangareader.to/genre/adventure">Adventure</a>

                                                    <div class="clearfix"></div>
                                                </div>
                                            </div>

                                            <div class="clearfix"></div>
                                        </div>
                                    </div>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </div>
                                <div class="clearfix"></div>
                            </div>
                            <div class="featured-navi">
                                <div class="navi-next">
                                    <i class="fas fa-angle-right"></i>
                                </div>
                                <div class="navi-prev"><i class="fas fa-angle-left"></i></div>
                            </div>
                        </div>
                    </div>
                </section>
            </div>
        </div>
        <!-- RECOMMENDED -->

        <div id="main-wrapper">
            <div class="container">
                <div id="mw-2col">
                    <!-- LATEST UPDATES -->
                    <div id="main-content">
                        <section class="block_area block_area_home">
                            <div class="block_area-header block_area-header-tabs">
                                <div class="float-left bah-heading">
                                    <h2 class="cat-heading">Latest Updates</h2>
                                </div>
                                <div class="bah-tab">
                                    <ul class="nav nav-tabs pre-tabs pre-tabs-min">
                                        <li class="nav-item">
                                            <a data-toggle="tab" href="#latest-chap" class="nav-link active">Chapter</a>
                                        </li>
                                        <li class="nav-item">
                                            <a data-toggle="tab" href="#latest-vol" class="nav-link">Volume</a>
                                        </li>
                                    </ul>
                                </div>
                                <div class="clearfix"></div>
                            </div>
                            <div class="tab-content">
                                <div id="latest-chap" class="tab-pane active show">
                                    <div class="manga_list-sbs">
                                        <div class="mls-wrap">
                                            <div class="item item-spc">
                                                <a class="manga-poster"
                                                    href="https://mangareader.to/my-apprentices-are-all-female-devils-61172">
                                                    <span class="tick tick-item tick-lang">EN</span>

                                                    <img src="https://img.mreadercdn.com/_r/300x400/100/f9/f4/f9f4dea3af0d0b2e5733760541eda0f6/f9f4dea3af0d0b2e5733760541eda0f6.jpg"
                                                        class="manga-poster-img lazyload"
                                                        alt="My Apprentices are all Female Devils" />
                                                </a>
                                                <div class="manga-detail">
                                                    <h3 class="manga-name">
                                                        <a href="https://mangareader.to/my-apprentices-are-all-female-devils-61172"
                                                            title="My Apprentices are all Female Devils">My Apprentices
                                                            are all Female Devils</a>
                                                    </h3>
                                                    <div class="fd-infor">
                                                        <span class="fdi-item fdi-cate">
                                                            <a href="https://mangareader.to/genre/action">Action</a>,

                                                            <a
                                                                href="https://mangareader.to/genre/adventure">Adventure</a>,

                                                            <a href="https://mangareader.to/genre/comedy">Comedy</a>
                                                        </span>

                                                        <div class="clearfix"></div>
                                                    </div>

                                                    <div class="fd-list">
                                                        <div class="fdl-item">
                                                            <div class="chapter">
                                                                <a
                                                                    href="https://mangareader.to/read/my-apprentices-are-all-female-devils-61172/en/chapter-165">
                                                                    <i class="far fa-file-alt mr-2"></i>Chap 165
                                                                    [EN]
                                                                </a>
                                                            </div>
                                                            <div class="release-time"></div>
                                                            <div class="clearfix"></div>
                                                        </div>

                                                        <div class="fdl-item">
                                                            <div class="chapter">
                                                                <a
                                                                    href="https://mangareader.to/read/my-apprentices-are-all-female-devils-61172/en/chapter-164">
                                                                    <i class="far fa-file-alt mr-2"></i>Chap 164
                                                                    [EN]
                                                                </a>
                                                            </div>
                                                            <div class="release-time"></div>
                                                            <div class="clearfix"></div>
                                                        </div>

                                                        <div class="fdl-item">
                                                            <div class="chapter">
                                                                <a
                                                                    href="https://mangareader.to/read/my-apprentices-are-all-female-devils-61172/en/chapter-163">
                                                                    <i class="far fa-file-alt mr-2"></i>Chap 163
                                                                    [EN]
                                                                </a>
                                                            </div>
                                                            <div class="release-time"></div>
                                                            <div class="clearfix"></div>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="clearfix"></div>
                                            </div>
                                            <div class="clearfix"></div>
                                        </div>
                                    </div>
                                </div>
                                <div id="latest-vol" class="tab-pane">
                                    <div class="manga_list-sbs">
                                        <div class="mls-wrap">
                                            <div class="item item-spc">
                                                <a class="manga-poster" href="https://mangareader.to/spy-x-family-86">
                                                    <span class="tick tick-item tick-lang">EN/FR/JA</span>

                                                    <img src="https://img.mreadercdn.com/_r/300x400/100/0c/64/0c64e3287e85df82f6add8b09ff38714/0c64e3287e85df82f6add8b09ff38714.jpg"
                                                        class="manga-poster-img lazyload" alt="Spy x Family" />
                                                </a>
                                                <div class="manga-detail">
                                                    <h3 class="manga-name">
                                                        <a href="https://mangareader.to/spy-x-family-86"
                                                            title="Spy x Family">Spy x Family</a>
                                                    </h3>
                                                    <div class="fd-infor">
                                                        <span class="fdi-item fdi-cate">
                                                            <a href="https://mangareader.to/genre/action">Action</a>,

                                                            <a href="https://mangareader.to/genre/comedy">Comedy</a>,

                                                            <a href="https://mangareader.to/genre/shounen">Shounen</a>
                                                        </span>

                                                        <div class="clearfix"></div>
                                                    </div>

                                                    <div class="fd-list">
                                                        <div class="fdl-item">
                                                            <div class="chapter">
                                                                <a
                                                                    href="https://mangareader.to/read/spy-x-family-86/en/volume-10">
                                                                    <i class="far fa-file-alt mr-2"></i>

                                                                    Vol 10 [EN]
                                                                </a>
                                                            </div>
                                                            <div class="release-time"></div>
                                                            <div class="clearfix"></div>
                                                        </div>

                                                        <div class="fdl-item">
                                                            <div class="chapter">
                                                                <a
                                                                    href="https://mangareader.to/read/spy-x-family-86/en/volume-9">
                                                                    <i class="far fa-file-alt mr-2"></i>

                                                                    Vol 9 [EN]
                                                                </a>
                                                            </div>
                                                            <div class="release-time"></div>
                                                            <div class="clearfix"></div>
                                                        </div>

                                                        <div class="fdl-item">
                                                            <div class="chapter">
                                                                <a
                                                                    href="https://mangareader.to/read/spy-x-family-86/en/volume-8">
                                                                    <i class="far fa-file-alt mr-2"></i>

                                                                    Vol 8 [EN]
                                                                </a>
                                                            </div>
                                                            <div class="release-time"></div>
                                                            <div class="clearfix"></div>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="clearfix"></div>
                                            </div>
                                            <div class="clearfix"></div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </section>
                        <div class="clearfix"></div>
                    </div>
                    <!-- LATEST UPDATES -->

                    <!-- MOST VIEWED -->
                    <div id="main-sidebar">
                        <section class="block_area block_area_sidebar block_area-realtime">
                            <div class="block_area-header">
                                <div class="float-left bah-heading">
                                    <h2 class="cat-heading">Most Viewed</h2>
                                </div>
                                <div class="clearfix"></div>
                            </div>
                            <div class="block_area-content">
                                <div class="cbox cbox-list cbox-realtime">
                                    <div class="cbox-content">
                                        <ul class="nav nav-pills nav-fill nav-tabs anw-tabs">
                                            <li class="nav-item">
                                                <a data-toggle="tab" href="#chart-today"
                                                    class="nav-link active">Today</a>
                                            </li>
                                            <li class="nav-item">
                                                <a data-toggle="tab" href="#chart-week" class="nav-link">Week</a>
                                            </li>
                                            <li class="nav-item">
                                                <a data-toggle="tab" href="#chart-month" class="nav-link">Month</a>
                                            </li>
                                        </ul>
                                        <div class="tab-content">
                                            <div id="chart-today" class="tab-pane show active">
                                                <div class="featured-block-ul featured-block-chart">
                                                    <ul class="ulclear">
                                                        <li class="item-top">
                                                            <div class="ranking-number">
                                                                <span>01</span>
                                                            </div>
                                                            <a href="https://mangareader.to/one-piece-3"
                                                                class="manga-poster">
                                                                <img src="https://img.mreadercdn.com/_r/200x300/100/cb/28/cb2828d5cd6929b3c8d1a2b25590a51b/cb2828d5cd6929b3c8d1a2b25590a51b.jpg"
                                                                    class="manga-poster-img lazyload" alt="One Piece" />
                                                            </a>
                                                            <div class="manga-detail">
                                                                <h3 class="manga-name">
                                                                    <a href="https://mangareader.to/one-piece-3"
                                                                        title="One Piece">One Piece</a>
                                                                </h3>
                                                                <div class="fd-infor">
                                                                    <span class="fdi-item">EN/FR/JA</span>
                                                                    <span class="dot"></span>
                                                                    <span class="fdi-item fdi-cate">
                                                                        <a
                                                                            href="https://mangareader.to/genre/action">Action</a>,

                                                                        <a
                                                                            href="https://mangareader.to/genre/adventure">Adventure</a>
                                                                    </span>
                                                                    <span class="fdi-item fdi-view">17,453 views</span>
                                                                    <div class="d-block">
                                                                        <span class="fdi-item fdi-chapter">
                                                                            <a
                                                                                href="https://mangareader.to/read/one-piece-3/en/chapter-1065"><i
                                                                                    class="far fa-file-alt mr-2"></i>Chap
                                                                                1065</a>
                                                                        </span>

                                                                        <span class="fdi-item fdi-chapter">
                                                                            <a
                                                                                href="https://mangareader.to/read/one-piece-3/en/volume-100"><i
                                                                                    class="far fa-file-alt mr-2"></i>Vol
                                                                                100</a>
                                                                        </span>
                                                                    </div>
                                                                    <div class="clearfix"></div>
                                                                </div>
                                                            </div>
                                                            <div class="clearfix"></div>
                                                        </li>
                                                    </ul>
                                                    <div class="clearfix"></div>
                                                </div>
                                            </div>
                                            <div id="chart-week" class="tab-pane">
                                                <div class="featured-block-ul featured-block-chart">
                                                    <ul class="ulclear">
                                                        <li class="item-top">
                                                            <div class="ranking-number">
                                                                <span>01</span>
                                                            </div>
                                                            <a href="https://mangareader.to/one-piece-3"
                                                                class="manga-poster">
                                                                <img src="https://img.mreadercdn.com/_r/200x300/100/cb/28/cb2828d5cd6929b3c8d1a2b25590a51b/cb2828d5cd6929b3c8d1a2b25590a51b.jpg"
                                                                    class="manga-poster-img lazyload" alt="One Piece" />
                                                            </a>
                                                            <div class="manga-detail">
                                                                <h3 class="manga-name">
                                                                    <a href="https://mangareader.to/one-piece-3"
                                                                        title="One Piece">One Piece</a>
                                                                </h3>
                                                                <div class="fd-infor">
                                                                    <span class="fdi-item">EN/FR/JA</span>
                                                                    <span class="dot"></span>
                                                                    <span class="fdi-item fdi-cate">
                                                                        <a
                                                                            href="https://mangareader.to/genre/action">Action</a>,

                                                                        <a
                                                                            href="https://mangareader.to/genre/adventure">Adventure</a>
                                                                    </span>
                                                                    <span class="fdi-item fdi-view">122,814 views</span>
                                                                    <div class="d-block">
                                                                        <span class="fdi-item fdi-chapter">
                                                                            <a
                                                                                href="https://mangareader.to/read/one-piece-3/en/chapter-1065"><i
                                                                                    class="far fa-file-alt mr-2"></i>Chap
                                                                                1065</a>
                                                                        </span>

                                                                        <span class="fdi-item fdi-chapter">
                                                                            <a
                                                                                href="https://mangareader.to/read/one-piece-3/en/volume-100"><i
                                                                                    class="far fa-file-alt mr-2"></i>Vol
                                                                                100</a>
                                                                        </span>
                                                                    </div>
                                                                    <div class="clearfix"></div>
                                                                </div>
                                                            </div>
                                                            <div class="clearfix"></div>
                                                        </li>
                                                    </ul>
                                                    <div class="clearfix"></div>
                                                </div>
                                            </div>
                                            <div id="chart-month" class="tab-pane">
                                                <div class="featured-block-ul featured-block-chart">
                                                    <ul class="ulclear">
                                                        <li class="item-top">
                                                            <div class="ranking-number">
                                                                <span>01</span>
                                                            </div>
                                                            <a href="https://mangareader.to/one-piece-3"
                                                                class="manga-poster">
                                                                <img src="https://img.mreadercdn.com/_r/200x300/100/cb/28/cb2828d5cd6929b3c8d1a2b25590a51b/cb2828d5cd6929b3c8d1a2b25590a51b.jpg"
                                                                    class="manga-poster-img lazyload" alt="One Piece" />
                                                            </a>
                                                            <div class="manga-detail">
                                                                <h3 class="manga-name">
                                                                    <a href="https://mangareader.to/one-piece-3"
                                                                        title="One Piece">One Piece</a>
                                                                </h3>
                                                                <div class="fd-infor">
                                                                    <span class="fdi-item">EN/FR/JA</span>
                                                                    <span class="dot"></span>
                                                                    <span class="fdi-item fdi-cate">
                                                                        <a
                                                                            href="https://mangareader.to/genre/action">Action</a>,

                                                                        <a
                                                                            href="https://mangareader.to/genre/adventure">Adventure</a>
                                                                    </span>
                                                                    <span class="fdi-item fdi-view">586,096 views</span>
                                                                    <div class="d-block">
                                                                        <span class="fdi-item fdi-chapter">
                                                                            <a
                                                                                href="https://mangareader.to/read/one-piece-3/en/chapter-1065"><i
                                                                                    class="far fa-file-alt mr-2"></i>Chap
                                                                                1065</a>
                                                                        </span>

                                                                        <span class="fdi-item fdi-chapter">
                                                                            <a
                                                                                href="https://mangareader.to/read/one-piece-3/en/volume-100"><i
                                                                                    class="far fa-file-alt mr-2"></i>Vol
                                                                                100</a>
                                                                        </span>
                                                                    </div>
                                                                    <div class="clearfix"></div>
                                                                </div>
                                                            </div>
                                                            <div class="clearfix"></div>
                                                        </li>
                                                    </ul>
                                                    <div class="clearfix"></div>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="clearfix"></div>
                                    </div>
                                </div>
                            </div>
                        </section>
                    </div>
                    <!-- MOST VIEWED -->

                    <div class="clearfix"></div>

                    <!-- COMPLETED -->
                    <section class="block_area block_area_featured">
                        <div class="block_area-header">
                            <div class="bah-heading">
                                <h2 class="cat-heading">Completed</h2>
                            </div>
                            <div class="clearfix"></div>
                        </div>
                        <div class="block_area-content">
                            <div class="featured-list" id="featured-04" style="display: none">
                                <div class="swiper-container">
                                    <div class="swiper-wrapper">
                                        <div class="swiper-slide">
                                            <div class="mg-item-basic">
                                                <div class="manga-poster">
                                                    <a class="link-mask"
                                                        href="https://mangareader.to/shark-girl-8009"></a>

                                                    <span class="tick tick-item tick-lang">EN/JA</span>

                                                    <div class="mp-desc">
                                                        <p class="alias-name mb-2">
                                                            <strong>Shark Girl</strong>
                                                        </p>
                                                        <p><i class="fas fa-star mr-2"></i>6.9</p>
                                                        <p><i class="fas fa-globe mr-2"></i>EN/JA</p>

                                                        <p>
                                                            <a
                                                                href="https://mangareader.to/read/shark-girl-8009/en/chapter-31"><i
                                                                    class="far fa-file-alt mr-2"></i><strong>Chap 31
                                                                    [EN]</strong></a>
                                                        </p>

                                                        <p>
                                                            <a
                                                                href="https://mangareader.to/read/shark-girl-8009/en/volume-3"><i
                                                                    class="far fa-file-alt mr-2"></i><strong>Vol 3
                                                                    [EN]</strong></a>
                                                        </p>

                                                        <div class="mpd-buttons">
                                                            <a href="https://mangareader.to/read/shark-girl-8009"
                                                                class="btn btn-primary btn-sm btn-block"><i
                                                                    class="fas fa-glasses mr-2"></i>Read
                                                                Now</a>
                                                            <a href="https://mangareader.to/shark-girl-8009"
                                                                class="btn btn-light btn-sm btn-block"><i
                                                                    class="fas fa-info-circle mr-2"></i>Info</a>
                                                        </div>
                                                    </div>
                                                    <img src="https://img.mreadercdn.com/_r/300x400/100/c5/10/c5101a86ab27356cf362306b17763339/c5101a86ab27356cf362306b17763339.jpg"
                                                        class="manga-poster-img lazyload" alt="Shark Girl" />
                                                </div>

                                                <div class="manga-detail">
                                                    <h3 class="manga-name">
                                                        <a href="https://mangareader.to/shark-girl-8009"
                                                            title="Shark Girl">Shark Girl</a>
                                                    </h3>
                                                    <div class="fd-infor">
                                                        <a href="https://mangareader.to/genre/action">Action</a>,

                                                        <a href="https://mangareader.to/genre/comedy">Comedy</a>

                                                        <div class="clearfix"></div>
                                                    </div>
                                                </div>

                                                <div class="clearfix"></div>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="clearfix"></div>
                                </div>
                                <div class="featured-navi">
                                    <div class="navi-next">
                                        <i class="fas fa-angle-right"></i>
                                    </div>
                                    <div class="navi-prev">
                                        <i class="fas fa-angle-left"></i>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </section>
                    <!-- COMPLETED -->

                    <div class="clearfix"></div>
                </div>
            </div>
        </div>

        <!-- FOOTER -->
        <div id="footer">
            <div id="footer-about">
                <div class="container">
                    <div class="footer-top">
                        <a href="https://mangareader.to/" class="footer-logo">
                            <img src="http://mareceh.com/wp-content/uploads/2022/03/Ma_receh.png" alt="Logo" />
                            <div class="clearfix"></div>
                        </a>
                    </div>

                    <div class="footer-links">
                        <ul class="ulclear">
                            <li>
                                <a href="https://mangareader.to/terms" title="Terms of service">Terms of service</a>
                            </li>
                            <li>
                                <a href="https://mangareader.to/dmca" title="DMCA">DMCA</a>
                            </li>
                            <li>
                                <a href="https://mangareader.to/contact" title="Contact">Contact</a>
                            </li>
                            <li>
                                <a href="https://mangareader.to/sitemap.xml" title="Sitemap">Sitemap</a>
                            </li>
                        </ul>
                        <div class="clearfix"></div>
                    </div>
                    <div class="about-text">
                        Mangareader does not store any files on our server, we only linked
                        to the media which is hosted on 3rd party services.
                    </div>
                    <p class="copyright">© Mangareader.to</p>
                </div>
            </div>
        </div>
        <!-- FOOTER -->
    </div>

    <script src="https://www.google.com/recaptcha/api.js?render=6LfQbGQcAAAAAL1I4ef6T7XEuPi19tYPVtaotny9&hl=en">
    </script>
    <script type="text/javascript" src="https://mangareader.to/js/app.min.js?v=2.1"></script>
    <script>
        var recaptchaV3SiteKey = "6LfQbGQcAAAAAL1I4ef6T7XEuPi19tYPVtaotny9",
        recaptchaV2SiteKey = "6LfVbmQcAAAAAP8gL4mAxtJG0gU0bhuuDwgyBnnJ";

        if ("serviceWorker" in navigator) {
        window.addEventListener("load", function () {
          navigator.serviceWorker.register("/sw.js");
        });
      }
    </script>
</body>

</html><?php /**PATH C:\laragon\www\laravel-scraper\resources\views/scraper.blade.php ENDPATH**/ ?>