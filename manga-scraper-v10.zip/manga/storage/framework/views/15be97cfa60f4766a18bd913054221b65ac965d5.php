<!-- FOOTER -->
<div id="footer">
    <div id="footer-about">
        <div class="container">
            <div class="footer-top">
                <div class="desc px-md-5 text-justify">
                    <?php $seo = App\Models\SEO::get() ?>
                    <?php $__currentLoopData = $seo; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $artikel): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php echo $artikel->artikel; ?>

                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
                <br><br><br>
                <a href="/" class="footer-logo">
                    <img src="<?php echo e(config('constant.url.backend').'/logo/'.$web['logo']); ?>" alt="Logo">
                    <div class="clearfix"></div>
                </a>
            </div>

            <div class="footer-links">
                <ul class="ulclear">
                    <li>
                        <a href="#" title="Terms of service">Terms of service</a>
                    </li>
                    <li>
                        <a href="#" title="DMCA">DMCA</a>
                    </li>
                    <li>
                        <a href="#" title="Contact">Contact</a>
                    </li>
                    <li>
                        <a href="#" title="Sitemap">Sitemap</a>
                    </li>
                </ul>
                <div class="clearfix"></div>
            </div>
            <p class="copyright">© <?php echo e(App\Models\SEO::select('title')->first()->title); ?></p>
        </div>
    </div>
</div>
<footer class="text-center fixed-bottom">
    <?php $bannerBawah = App\Models\Banner::where(['posisi' => 'Bawah', 'status' => 0])->get() ?>
    <?php $__currentLoopData = $bannerBawah; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $bannerBawah): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <a href="<?php echo e($bannerBawah->link); ?>" target="_blank">
            <img src="<?php echo e(config('constant.url.backend').'/banner/'.$bannerBawah->gambar); ?>" class="img-fluid" alt="">
        </a>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</footer>
<!-- FOOTER --><?php /**PATH C:\laragon\www\manga\resources\views/includes/footer.blade.php ENDPATH**/ ?>