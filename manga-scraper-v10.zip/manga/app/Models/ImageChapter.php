<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class ImageChapter extends Model
{
    protected $table = 'manga_chapter_image';
    use HasFactory;
}
